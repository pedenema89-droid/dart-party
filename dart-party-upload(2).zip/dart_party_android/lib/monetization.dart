import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Monetarisierung für Dart Party.
///
/// Die AdMob-IDs sind zunächst Googles offizielle Test-IDs. Vor einer
/// Veröffentlichung müssen sie durch die eigenen AdMob-IDs ersetzt werden.
class MonetizationService {
  MonetizationService._();

  static final MonetizationService instance = MonetizationService._();

  static const String monthlyProductId = 'dart_party_monthly_unlimited';
  static const String lifetimeProductId = 'dart_party_lifetime_unlimited';
  static const String removeAdsProductId = 'dart_party_remove_ads';

  static const String appOpenTestAdUnitId =
      'ca-app-pub-3940256099942544/9257395921';
  static const String interstitialTestAdUnitId =
      'ca-app-pub-3940256099942544/1033173712';

  static const String _noAdsKey = 'dp_purchase_no_ads';
  static const String _lifetimeKey = 'dp_purchase_lifetime_unlimited';
  static const String _monthlyKey = 'dp_purchase_monthly_unlimited';
  static const String _dailyDateKey = 'dp_daily_games_date';
  static const String _dailyCountKey = 'dp_daily_games_count';

  final InAppPurchase _billing = InAppPurchase.instance;
  final ValueNotifier<int> changes = ValueNotifier<int>(0);
  final Map<String, ProductDetails> products = <String, ProductDetails>{};

  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;
  AppOpenAd? _appOpenAd;
  InterstitialAd? _interstitialAd;
  Completer<bool>? _appOpenLoadCompleter;
  Completer<bool>? _interstitialLoadCompleter;

  bool _initialized = false;
  bool _canRequestAds = false;
  bool _isShowingAd = false;
  bool _interstitialLoading = false;
  bool _appOpenLoading = false;
  bool _privacyOptionsRequired = false;
  bool noAds = false;
  bool lifetimeUnlimited = false;
  bool monthlyUnlimited = false;

  bool get unlimitedGames => lifetimeUnlimited || monthlyUnlimited;
  bool get adsEnabled => !noAds && _canRequestAds;
  bool get privacyOptionsRequired => _privacyOptionsRequired;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    _purchaseSubscription = _billing.purchaseStream.listen(
      _onPurchaseUpdates,
      onError: (Object error) => debugPrint('Purchase stream error: $error'),
    );

    try {
      final prefs = await SharedPreferences.getInstance();
      noAds = prefs.getBool(_noAdsKey) ?? false;
      lifetimeUnlimited = prefs.getBool(_lifetimeKey) ?? false;
      monthlyUnlimited = prefs.getBool(_monthlyKey) ?? false;
      changes.value++;
    } catch (error) {
      debugPrint('Could not load saved purchase state: $error');
    }

    unawaited(_loadProducts());
    // Nicht-verbrauchte Käufe und aktive Abos werden beim Start erneut beim
    // Store angefragt, damit ein Gerätewechsel die Freischaltung wiederherstellt.
    try {
      await _restorePurchasesQuietly().timeout(const Duration(seconds: 2));
    } catch (_) {
      // Bei fehlender Store-Verbindung bleiben die lokal gespeicherten Käufe erhalten.
    }
    if (!noAds) {
      await _initializeAdsAndConsent();
      if (adsEnabled) _loadInterstitialAd();
    }
  }

  Future<void> _restorePurchasesQuietly() async {
    try {
      if (await _billing.isAvailable()) await _billing.restorePurchases();
    } catch (error) {
      debugPrint('Automatic purchase restoration failed: $error');
    }
  }

  Future<void> _loadProducts() async {
    try {
      if (!await _billing.isAvailable()) return;
      final response = await _billing.queryProductDetails(<String>{
        monthlyProductId,
        lifetimeProductId,
        removeAdsProductId,
      });
      products
        ..clear()
        ..addEntries(response.productDetails.map((p) => MapEntry(p.id, p)));
      if (response.error != null) {
        debugPrint('Product query error: ${response.error}');
      }
      changes.value++;
    } catch (error) {
      debugPrint('Could not query Play products: $error');
    }
  }

  Future<void> _initializeAdsAndConsent() async {
    try {
      await MobileAds.instance.initialize();
      final completed = Completer<void>();

      Future<void> finishConsentFlow() async {
        try {
          _canRequestAds = await ConsentInformation.instance.canRequestAds();
          _privacyOptionsRequired =
              await ConsentInformation.instance.getPrivacyOptionsRequirementStatus() ==
                  PrivacyOptionsRequirementStatus.required;
        } catch (error) {
          debugPrint('Could not read ad consent state: $error');
          _canRequestAds = false;
        }
        if (adsEnabled) {
          _loadAppOpenAd();
          _loadInterstitialAd();
        }
        changes.value++;
        if (!completed.isCompleted) completed.complete();
      }

      ConsentInformation.instance.requestConsentInfoUpdate(
        ConsentRequestParameters(),
        () {
          ConsentForm.loadAndShowConsentFormIfRequired((FormError? error) {
            if (error != null) debugPrint('UMP form error: $error');
            unawaited(finishConsentFlow());
          });
        },
        (FormError error) {
          debugPrint('UMP update error: $error');
          unawaited(finishConsentFlow());
        },
      );

      await completed.future.timeout(
        const Duration(seconds: 4),
        onTimeout: () {
          debugPrint('UMP consent flow timed out; ads remain disabled.');
        },
      );
    } catch (error) {
      // Bei einem Fehler werden keine Anzeigen angefordert.
      _canRequestAds = false;
      debugPrint('Ad SDK initialization failed: $error');
    }
  }

  void _loadAppOpenAd() {
    if (!adsEnabled || _appOpenAd != null || _appOpenLoading) return;
    _appOpenLoading = true;
    AppOpenAd.load(
      adUnitId: appOpenTestAdUnitId,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          _appOpenLoading = false;
          _appOpenAd = ad;
          _appOpenLoadCompleter?.complete(true);
          _appOpenLoadCompleter = null;
        },
        onAdFailedToLoad: (error) {
          _appOpenLoading = false;
          debugPrint('App-open ad failed to load: $error');
          _appOpenLoadCompleter?.complete(false);
          _appOpenLoadCompleter = null;
        },
      ),
    );
  }

  void _loadInterstitialAd() {
    if (!adsEnabled || _interstitialAd != null || _interstitialLoading) return;
    _interstitialLoading = true;
    _interstitialLoadCompleter = Completer<bool>();
    InterstitialAd.load(
      adUnitId: interstitialTestAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialLoading = false;
          _interstitialAd = ad;
          _interstitialLoadCompleter?.complete(true);
          _interstitialLoadCompleter = null;
        },
        onAdFailedToLoad: (error) {
          _interstitialLoading = false;
          debugPrint('Interstitial ad failed to load: $error');
          _interstitialLoadCompleter?.complete(false);
          _interstitialLoadCompleter = null;
        },
      ),
    );
  }

  /// Aufruf nur auf der Startansicht. Wartet kurz auf die App-Start-Anzeige,
  /// damit sie nicht verspätet über dem bereits benutzten Hauptmenü erscheint.
  Future<void> showAppOpenAdOnLaunch() async {
    if (!adsEnabled || _isShowingAd) return;
    if (_appOpenAd == null) {
      final waiter = Completer<bool>();
      _appOpenLoadCompleter = waiter;
      _loadAppOpenAd();
      try {
        await waiter.future.timeout(const Duration(milliseconds: 1800));
      } catch (_) {
        // Kein geladenes Werbemittel: App ohne Verzögerung öffnen.
      }
    }

    final ad = _appOpenAd;
    if (ad == null || !adsEnabled || _isShowingAd) return;
    _appOpenAd = null;
    final finished = Completer<void>();
    _isShowingAd = true;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _isShowingAd = false;
        if (!finished.isCompleted) finished.complete();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        debugPrint('App-open ad failed to show: $error');
        ad.dispose();
        _isShowingAd = false;
        if (!finished.isCompleted) finished.complete();
      },
    );
    ad.show();
    try {
      await finished.future.timeout(const Duration(minutes: 2));
    } catch (_) {
      _isShowingAd = false;
    }
  }

  /// Vollbildanzeige an natürlichen Übergängen (Spielstart/Spielende).
  /// Wenn keine Anzeige geladen ist oder keine Einwilligung vorliegt, läuft
  /// das Spiel ohne Werbeunterbrechung weiter.
  Future<void> showInterstitialIfAvailable() async {
    if (!adsEnabled || _isShowingAd) return;
    if (_interstitialAd == null && _interstitialLoading) {
      try {
        await _interstitialLoadCompleter?.future.timeout(
          const Duration(milliseconds: 900),
        );
      } catch (_) {}
    }
    final ad = _interstitialAd;
    if (ad == null || !adsEnabled || _isShowingAd) {
      _loadInterstitialAd();
      return;
    }

    _interstitialAd = null;
    final finished = Completer<void>();
    _isShowingAd = true;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _isShowingAd = false;
        _loadInterstitialAd();
        if (!finished.isCompleted) finished.complete();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        debugPrint('Interstitial ad failed to show: $error');
        ad.dispose();
        _isShowingAd = false;
        _loadInterstitialAd();
        if (!finished.isCompleted) finished.complete();
      },
    );
    ad.show();
    try {
      await finished.future.timeout(const Duration(minutes: 2));
    } catch (_) {
      _isShowingAd = false;
      _loadInterstitialAd();
    }
  }

  Future<int> gamesPlayedToday() async {
    final prefs = await SharedPreferences.getInstance();
    final today = _dateKey(DateTime.now());
    if (prefs.getString(_dailyDateKey) != today) return 0;
    return prefs.getInt(_dailyCountKey) ?? 0;
  }

  String _dateKey(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  Future<bool> _canStartFreeGame() async => await gamesPlayedToday() < 2;

  /// Prüft das Tageslimit, öffnet bei Bedarf die Angebotsseite, zeigt die
  /// Startwerbung und zählt anschließend genau eine Partie.
  Future<bool> authorizeGameStart(BuildContext context) async {
    if (!unlimitedGames && !await _canStartFreeGame()) {
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const MonetizationScreen()),
      );
      if (!context.mounted) return false;
      if (!unlimitedGames && !await _canStartFreeGame()) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Das Tageslimit von zwei Spielen ist erreicht.'),
          ),
        );
        return false;
      }
    }

    if (!noAds) await showInterstitialIfAvailable();
    if (!context.mounted) return false;

    if (!unlimitedGames) {
      final prefs = await SharedPreferences.getInstance();
      final today = _dateKey(DateTime.now());
      final oldCount = prefs.getString(_dailyDateKey) == today
          ? (prefs.getInt(_dailyCountKey) ?? 0)
          : 0;
      if (oldCount >= 2) return false;
      await prefs.setString(_dailyDateKey, today);
      await prefs.setInt(_dailyCountKey, oldCount + 1);
    }
    changes.value++;
    return true;
  }

  Future<void> _onPurchaseUpdates(List<PurchaseDetails> updates) async {
    for (final purchase in updates) {
      if (purchase.status == PurchaseStatus.pending) {
        debugPrint('Purchase pending: ${purchase.productID}');
      } else if (purchase.status == PurchaseStatus.error) {
        debugPrint('Purchase failed: ${purchase.error}');
      } else if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        // Die Google-Play-Rückmeldung bestätigt hier den Kaufstatus auf dem
        // Gerät. Für einen produktiven Release sollte zusätzlich eine
        // serverseitige Prüfung des Kauf-Tokens eingerichtet werden.
        await _grantProduct(purchase.productID);
      }

      if (purchase.pendingCompletePurchase) {
        try {
          await _billing.completePurchase(purchase);
        } catch (error) {
          debugPrint('Could not complete purchase: $error');
        }
      }
    }
  }

  Future<void> _grantProduct(String productId) async {
    final prefs = await SharedPreferences.getInstance();
    if (productId == monthlyProductId) {
      monthlyUnlimited = true;
      await prefs.setBool(_monthlyKey, true);
    } else if (productId == lifetimeProductId) {
      lifetimeUnlimited = true;
      await prefs.setBool(_lifetimeKey, true);
    } else if (productId == removeAdsProductId) {
      noAds = true;
      await prefs.setBool(_noAdsKey, true);
      _appOpenAd?.dispose();
      _appOpenAd = null;
      _interstitialAd?.dispose();
      _interstitialAd = null;
    }
    changes.value++;
  }

  Future<void> buyProduct(String productId) async {
    final product = products[productId];
    if (product == null) {
      throw StateError(
        'Dieses Angebot wurde noch nicht im Google Play Store angelegt oder ist dort noch nicht verfügbar.',
      );
    }
    final purchaseParam = PurchaseParam(productDetails: product);
    final launched = await _billing.buyNonConsumable(purchaseParam: purchaseParam);
    if (!launched) throw StateError('Google Play konnte den Kaufvorgang nicht starten.');
  }

  Future<void> restorePurchases() async {
    if (!await _billing.isAvailable()) {
      throw StateError('Google Play ist momentan nicht erreichbar.');
    }
    await _billing.restorePurchases();
  }

  Future<void> showPrivacyOptions() async {
    if (!_privacyOptionsRequired) return;
    ConsentForm.showPrivacyOptionsForm((FormError? error) {
      if (error != null) debugPrint('Privacy options error: $error');
    });
  }
}

/// Startansicht: Consent/AdMob initialisieren und die optionale App-Start-
/// Anzeige über einer neutralen Ladeansicht zeigen.
class MonetizationStartupGate extends StatefulWidget {
  final Widget child;
  const MonetizationStartupGate({super.key, required this.child});

  @override
  State<MonetizationStartupGate> createState() => _MonetizationStartupGateState();
}

class _MonetizationStartupGateState extends State<MonetizationStartupGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await MonetizationService.instance.initialize();
      await MonetizationService.instance.showAppOpenAdOnLaunch();
    } catch (error, stackTrace) {
      // Optionale Werbung oder Store-Dienste dürfen den App-Start nicht blockieren.
      debugPrint('Monetization startup failed; opening app without ads: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (mounted) setState(() => _ready = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return widget.child;
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports, size: 58, color: Color(0xFFB8A9FF)),
            SizedBox(height: 16),
            Text('DART PARTY', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(height: 18),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class MonetizationScreen extends StatefulWidget {
  const MonetizationScreen({super.key});

  @override
  State<MonetizationScreen> createState() => _MonetizationScreenState();
}

class _MonetizationScreenState extends State<MonetizationScreen> {
  bool _busy = false;
  String? _message;

  Future<void> _buy(String productId) async {
    setState(() {
      _busy = true;
      _message = null;
    });
    try {
      await MonetizationService.instance.buyProduct(productId);
      if (mounted) {
        setState(() => _message = 'Google Play hat den Kaufvorgang gestartet.');
      }
    } catch (error) {
      if (mounted) setState(() => _message = error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    setState(() {
      _busy = true;
      _message = null;
    });
    try {
      await MonetizationService.instance.restorePurchases();
      if (mounted) {
        setState(() => _message = 'Wiederherstellung wurde bei Google Play angefragt.');
      }
    } catch (error) {
      if (mounted) setState(() => _message = error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _offer({
    required String productId,
    required String title,
    required String fallbackPrice,
    required String description,
    required bool active,
    required String activeLabel,
  }) {
    final product = MonetizationService.instance.products[productId];
    final price = product?.price ?? fallbackPrice;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
                if (active) const Chip(label: Text('Aktiv')),
              ],
            ),
            const SizedBox(height: 5),
            Text(description, style: const TextStyle(color: Colors.white70, height: 1.35)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: Text(price, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFFB8A9FF)))),
                FilledButton(
                  onPressed: _busy || active || product == null ? null : () => _buy(productId),
                  child: Text(active ? activeLabel : product == null ? 'Noch nicht verfügbar' : 'Auswählen'),
                ),
              ],
            ),
            if (product == null && !active)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text('Wird freigeschaltet, sobald das Produkt in der Play Console angelegt und aktiviert ist.', style: TextStyle(color: Colors.white38, fontSize: 11)),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: MonetizationService.instance.changes,
        builder: (context, _, __) {
          final service = MonetizationService.instance;
          return Scaffold(
            appBar: AppBar(title: const Text('Premium & Werbung')),
            body: SafeArea(
              child: ListView(
                padding: const EdgeInsets.all(18),
                children: [
                  const Text('DART PARTY PREMIUM', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 7),
                  Text(
                    service.unlimitedGames
                        ? 'Unbegrenzte Spiele sind für dieses Konto freigeschaltet.'
                        : 'Kostenlos kannst du zwei Spiele pro Kalendertag starten.',
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 16),
                  _offer(
                    productId: MonetizationService.monthlyProductId,
                    title: 'Unbegrenzt spielen – monatlich',
                    fallbackPrice: '1,49 € / Monat',
                    description: 'Unbegrenzte Spiele, Werbung bleibt eingeblendet. Das Abo verlängert sich automatisch und kann jederzeit über Google Play gekündigt werden.',
                    active: service.monthlyUnlimited,
                    activeLabel: 'Aktiv',
                  ),
                  _offer(
                    productId: MonetizationService.lifetimeProductId,
                    title: 'Unbegrenzt spielen – lebenslang',
                    fallbackPrice: '14,99 € einmalig',
                    description: 'Einmal bezahlen und dauerhaft unbegrenzt viele Spiele starten. Werbung bleibt eingeblendet.',
                    active: service.lifetimeUnlimited,
                    activeLabel: 'Freigeschaltet',
                  ),
                  _offer(
                    productId: MonetizationService.removeAdsProductId,
                    title: 'Werbefrei spielen',
                    fallbackPrice: '6,99 € einmalig',
                    description: 'Alle Werbeanzeigen werden dauerhaft entfernt. Das kostenlose Limit von zwei Spielen pro Tag bleibt bestehen.',
                    active: service.noAds,
                    activeLabel: 'Werbefrei',
                  ),
                  if (_message != null) ...[
                    const SizedBox(height: 10),
                    Text(_message!, style: const TextStyle(color: Colors.white70)),
                  ],
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _restore,
                    icon: const Icon(Icons.restore),
                    label: const Text('Käufe wiederherstellen'),
                  ),
                  if (service.privacyOptionsRequired)
                    TextButton.icon(
                      onPressed: service.showPrivacyOptions,
                      icon: const Icon(Icons.privacy_tip_outlined),
                      label: const Text('Datenschutzeinstellungen'),
                    ),
                  const SizedBox(height: 8),
                  const Text(
                    'Die Preise und die Verfügbarkeit werden abschließend von Google Play festgelegt. Käufe gelten für das Google-Konto, mit dem sie abgeschlossen wurden.',
                    style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.35),
                  ),
                ],
              ),
            ),
          );
        },
      );
}
