import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const DartPartyApp());
const categories = ['Easy', 'Medium', 'Hard', 'Legende', 'Unsterblich'];
const categoryPoints = {'Easy': 1, 'Medium': 2, 'Hard': 3, 'Legende': 4, 'Unsterblich': 5};
const purple = Color(0xFFB8A9FF);

class ChallengeCard {
  final String id, text, category;
  const ChallengeCard(this.id, this.text, this.category);
}

enum CardState { open, completed, crossed }
class PlayerCard {
  final ChallengeCard card;
  CardState state = CardState.open;
  PlayerCard(this.card);
}
class Player {
  final String name;
  final List<PlayerCard> cards;
  int score = 0, turns = 0;
  Player(this.name, List<ChallengeCard> cards) : cards = cards.map(PlayerCard.new).toList();
  List<PlayerCard> get openCards => cards.where((c) => c.state == CardState.open).toList();
}

class DartThrow {
  final String label;
  final int score, number;
  final String multiplier;
  final bool bull, outerBull, miss;
  const DartThrow(this.label, this.score, {this.number = 0, this.multiplier = 'S', this.bull = false, this.outerBull = false, this.miss = false});
  bool get triple => multiplier == 'T' && !bull && !outerBull;
  bool get doubleHit => multiplier == 'D' && !bull && !outerBull;
  bool get single => multiplier == 'S' && number > 0;
  String get fieldKey => bull ? 'BULL' : outerBull ? 'OUTER' : miss ? 'MISS' : '$multiplier$number';
  String get numberKey => (bull || outerBull || miss) ? fieldKey : '$number';
}

class DartPartyApp extends StatelessWidget {
  const DartPartyApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'Dart Party', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF10131B), colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C5CFF), brightness: Brightness.dark),
      cardTheme: CardThemeData(color: const Color(0xFF1B2030), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF1B2030), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
    home: const HomeScreen());
}

Future<List<ChallengeCard>> loadCards() async {
  final raw = await rootBundle.loadString('assets/data/dart_challenges_master.csv');
  final lines = raw.split(RegExp(r'\r?\n')).where((e) => e.trim().isNotEmpty).toList();
  final result = <ChallengeCard>[];
  for (var i = 1; i < lines.length; i++) { final f = _parseCsv(lines[i]); if (f.length >= 3 && categories.contains(f[2].trim())) result.add(ChallengeCard(f[0].trim(), f[1].trim(), f[2].trim())); }
  return result;
}
List<String> _parseCsv(String line) { final out=<String>[]; final b=StringBuffer(); var q=false; for(var i=0;i<line.length;i++){final c=line[i]; if(c=='"'){if(q&&i+1<line.length&&line[i+1]=='"'){b.write('"');i++;}else{q=!q;}}else if(c==','&&!q){out.add(b.toString());b.clear();}else{b.write(c);}} out.add(b.toString()); return out; }

class HomeScreen extends StatelessWidget {
 const HomeScreen({super.key});
 @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Spacer(), const Icon(Icons.sports, size: 62, color: purple), const SizedBox(height:18), const Text('DART PARTY',style:TextStyle(fontSize:34,fontWeight:FontWeight.w900,letterSpacing:2)), const SizedBox(height:8), const Text('Dein Dartabend. Deine Regeln.',style:TextStyle(color:Colors.white60)), const SizedBox(height:36), Card(child: ListTile(leading:const Icon(Icons.style,color:purple,size:30),title:const Text('Kartenjagd',style:TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('10 Karten · 10 Runden · höchste Punktzahl gewinnt'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PlayerSetupScreen())))), const Spacer(), const Center(child:Text('VERSION 0.2',style:TextStyle(color:Colors.white38,letterSpacing:1.5)))]))));
}

class PlayerSetupScreen extends StatefulWidget { const PlayerSetupScreen({super.key}); @override State<PlayerSetupScreen> createState()=>_PlayerSetupScreenState(); }
class _PlayerSetupScreenState extends State<PlayerSetupScreen> {
 final names=[TextEditingController(text:'Spieler 1'),TextEditingController(text:'Spieler 2')]; bool loading=false;
 @override void dispose(){for(final n in names){n.dispose();}super.dispose();}
 Future<void> start() async {final valid=names.map((e)=>e.text.trim()).where((e)=>e.isNotEmpty).toList(); if(valid.length<2){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Bitte mindestens zwei Spieler eintragen.')));return;} setState(()=>loading=true); try{final all=await loadCards(); final rnd=Random(); final ps=<Player>[]; for(final name in valid){final chosen=<ChallengeCard>[];for(final cat in categories){final pool=all.where((c)=>c.category==cat).toList()..shuffle(rnd);if(pool.length<2)throw Exception('Nicht genügend Karten in $cat');chosen.addAll(pool.take(2));}chosen.shuffle(rnd);ps.add(Player(name,chosen));} if(!mounted)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>CardHuntScreen(players:ps)));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Fehler: $e')));}finally{if(mounted)setState(()=>loading=false);} }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Spieler festlegen')),body:SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[const Text('KARTENJAGD',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Jeder Spieler erhält 2 Karten aus jeder Kategorie.',style:TextStyle(color:Colors.white60)),const SizedBox(height:20),...List.generate(names.length,(i)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Row(children:[Expanded(child:TextField(controller:names[i],decoration:InputDecoration(labelText:'Spieler ${i+1}'))),if(names.length>2)IconButton(onPressed:()=>setState(()=>names.removeAt(i).dispose()),icon:const Icon(Icons.close))]))),OutlinedButton.icon(onPressed:names.length>=8?null:()=>setState(()=>names.add(TextEditingController(text:'Spieler ${names.length+1}'))),icon:const Icon(Icons.add),label:const Text('Spieler hinzufügen')),const SizedBox(height:24),FilledButton.icon(onPressed:loading?null:start,icon:const Icon(Icons.play_arrow),label:Text(loading?'Karten werden gemischt …':'Spiel starten'))])));
}

class CardHuntScreen extends StatefulWidget { final List<Player> players; const CardHuntScreen({super.key,required this.players}); @override State<CardHuntScreen> createState()=>_CardHuntScreenState(); }
class _CardHuntScreenState extends State<CardHuntScreen> {
 int playerIndex=0; final List<DartThrow> darts=[]; bool submitted=false; Player get player=>widget.players[playerIndex]; int get total=>darts.fold(0,(s,d)=>s+d.score); int get turn=>player.turns+1;
 List<PlayerCard> get fulfilled=>player.openCards.where((c)=>evaluateCard(c.card.text,darts)).toList();
 void setDart(int index,DartThrow dart){setState((){if(index<darts.length){darts[index]=dart;}else if(index==darts.length){darts.add(dart);} if(darts.length>3)darts.removeRange(3,darts.length); submitted=false;});}
 void submit(){if(darts.length!=3)return;setState(()=>submitted=true);}
 void finish(PlayerCard card,{required bool completed}){setState((){card.state=completed?CardState.completed:CardState.crossed;if(completed)player.score+=categoryPoints[card.card.category]??0;player.turns++;darts.clear();submitted=false;if(player.turns>=10){if(playerIndex<widget.players.length-1){playerIndex++;}else{Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ResultsScreen(players:widget.players)));}}});}
 @override Widget build(BuildContext context){final matches=submitted?fulfilled:<PlayerCard>[];return Scaffold(appBar:AppBar(title:const Text('Kartenjagd'),actions:[Padding(padding:const EdgeInsets.only(right:16),child:Center(child:Text('${player.score} P',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17))))]),body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(14,8,14,24),children:[Row(children:[Expanded(child:Text(player.name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w800))),Text('Runde $turn / 10',style:const TextStyle(color:Colors.white60))]),const SizedBox(height:4),Text('Spieler ${playerIndex+1} von ${widget.players.length} · ${player.openCards.length} Karten offen',style:const TextStyle(color:Colors.white54)),const SizedBox(height:14),if(!submitted)...[
 const Text('DART-EINGABE',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1)),const SizedBox(height:8),...List.generate(3,(i)=>DartEntry(index:i,value:i<darts.length?darts[i]:null,onChanged:(d)=>setDart(i,d))),const SizedBox(height:8),Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFF24283A),borderRadius:BorderRadius.circular(14)),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Aktueller Wurf',style:TextStyle(color:Colors.white70)),Text('$total Punkte',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900,color:purple))])),const SizedBox(height:10),FilledButton.icon(onPressed:darts.length==3?submit:null,icon:const Icon(Icons.check),label:const Text('Wurf prüfen')),const SizedBox(height:18),const Text('KARTENÜBERSICHT',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1)),const SizedBox(height:8),...player.cards.map((c)=>ChallengeTile(item:c)),
 ]else...[
 Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Deine drei Darts',style:TextStyle(color:Colors.white60)),const SizedBox(height:5),Text(darts.map((d)=>d.label).join('  ·  '),style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),const SizedBox(height:6),Text('Gesamt: $total Punkte',style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900,color:purple))]))),const SizedBox(height:12),if(matches.isNotEmpty)...[Text(matches.length==1?'KARTE ERFÜLLT':'${matches.length} KARTEN ERFÜLLT – WÄHLE EINE',style:const TextStyle(fontWeight:FontWeight.bold,color:Colors.greenAccent)),const SizedBox(height:8),...matches.map((c)=>ChallengeTile(item:c,actionLabel:'Erfüllt · +${categoryPoints[c.card.category]} P',action:()=>finish(c,completed:true))) ]else...[const Text('Keine Karte erfüllt',style:TextStyle(fontWeight:FontWeight.bold,color:Colors.orangeAccent)),const SizedBox(height:4),const Text('Tippe eine offene Karte an, um sie zu streichen. Sie bleibt danach sichtbar.',style:TextStyle(color:Colors.white60)),const SizedBox(height:8),...player.openCards.map((c)=>ChallengeTile(item:c,actionLabel:'Karte streichen',action:()=>finish(c,completed:false)))],const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>setState(()=>submitted=false),icon:const Icon(Icons.edit),label:const Text('Wurfeingabe korrigieren'))
 ]])));}
}

class DartEntry extends StatefulWidget {final int index;final DartThrow? value;final ValueChanged<DartThrow> onChanged;const DartEntry({super.key,required this.index,required this.value,required this.onChanged});@override State<DartEntry> createState()=>_DartEntryState();}
class _DartEntryState extends State<DartEntry>{String multiplier='S';@override Widget build(BuildContext context){final v=widget.value;return Card(child:Padding(padding:const EdgeInsets.all(11),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[CircleAvatar(radius:13,child:Text('${widget.index+1}')),const SizedBox(width:9),Expanded(child:Text(v?.label??'Dart ${widget.index+1} auswählen',style:const TextStyle(fontWeight:FontWeight.bold))),if(v!=null)Text('${v.score} P',style:const TextStyle(color:purple,fontWeight:FontWeight.bold))]),const SizedBox(height:9),Row(children:['S','D','T'].map((m)=>Expanded(child:Padding(padding:const EdgeInsets.only(right:5),child:ChoiceChip(label:Text(m=='S'?'Single':m=='D'?'Double':'Triple'),selected:multiplier==m,onSelected:(_)=>setState(()=>multiplier=m)))).toList()),const SizedBox(height:7),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:5,mainAxisSpacing:5,crossAxisSpacing:5,childAspectRatio:1.7,children:List.generate(20,(i){final n=i+1;return FilledButton.tonal(onPressed:()=>widget.onChanged(DartThrow('$multiplier $n',n*(multiplier=='S'?1:multiplier=='D'?2:3),number:n,multiplier:multiplier)),style:FilledButton.styleFrom(padding:EdgeInsets.zero),child:Text('$n'));})),const SizedBox(height:6),Row(children:[Expanded(child:OutlinedButton(onPressed:()=>widget.onChanged(const DartThrow('Fehlwurf',0,miss:true)),child:const Text('Fehlwurf · 0'))),const SizedBox(width:5),Expanded(child:OutlinedButton(onPressed:()=>widget.onChanged(const DartThrow('Outer Bull',25,outerBull:true)),child:const Text('Outer Bull · 25'))),const SizedBox(width:5),Expanded(child:OutlinedButton(onPressed:()=>widget.onChanged(const DartThrow('Bullseye',50,bull:true)),child:const Text('Bull · 50')))])])));}}

// Conservative rule engine: it evaluates the wording of the master cards. Unknown wording
// deliberately does not produce a false positive; the rule can be added without changing the UI.
bool evaluateCard(String raw,List<DartThrow> d){if(d.length!=3)return false;final t=raw.toLowerCase().replaceAll('ä','ae').replaceAll('ö','oe').replaceAll('ü','ue');final sum=d.fold<int>(0,(s,x)=>s+x.score);final triples=d.where((x)=>x.triple).length;final doubles=d.where((x)=>x.doubleHit).length;final bulls=d.where((x)=>x.bull).length;final outer=d.where((x)=>x.outerBull).length;final singles=d.where((x)=>x.single).length;final nums=d.map((x)=>x.numberKey).toSet();
 int? minScore=RegExp(r'mindestens\s+(\d+)\s+punkte').firstMatch(t)!=null?int.parse(RegExp(r'mindestens\s+(\d+)\s+punkte').firstMatch(t)!.group(1)!):null;
 int? exactScore=RegExp(r'genau\s+(\d+)(?:\s+punkte)?').firstMatch(t)!=null?int.parse(RegExp(r'genau\s+(\d+)(?:\s+punkte)?').firstMatch(t)!.group(1)!):null;
 if(minScore!=null&&sum<minScore)return false;if(exactScore!=null&&sum!=exactScore)return false;
 if(t.contains('ohne ein triple')||t.contains('ohne triple'))if(triples>0)return false;
 if(t.contains('ohne bullseye')||t.contains('ohne das bullseye'))if(bulls>0)return false;
 if(t.contains('ohne ein doppelfeld oder triple-feld')||t.contains('ohne ein doppelfeld oder triple'))if(doubles+triples>0)return false;
 if(t.contains('ausschliesslich einfache zahlenfelder')||t.contains('ausschliesslich einfache zahlenfelder treffen')||t.contains('nur einfache zahlenfelder'))if(d.any((x)=>!x.single))return false;
 if(t.contains('ausschliesslich single- und double-felder'))if(d.any((x)=>!(x.single||x.doubleHit)))return false;
 if(t.contains('ausschliesslich triple-felder oder bullseye'))if(d.any((x)=>!(x.triple||x.bull)))return false;
 final maxD=RegExp(r'hoechstens (\w+) doppelfeld').firstMatch(t);if(maxD!=null&&doubles>_wordNum(maxD.group(1)!))return false;
 final exactOneTriple=t.contains('genau einem triple');if(exactOneTriple&&triples!=1)return false;
 if(t.contains('mindestens drei unterschiedliche zahlenfelder')&&nums.length<3)return false;
 if(t.contains('mindestens drei unterschiedliche einfache zahlenfelder')&&d.where((x)=>x.single).map((x)=>x.number).toSet().length<3)return false;
 if(t.contains('jeder dart ein anderes zahlenfeld')&&nums.length<3)return false;
 if(t.contains('ohne dreimal dasselbe feld')&&d.map((x)=>x.fieldKey).toSet().length==1)return false;
 if(t.contains('ohne dreimal dasselbe zahlenfeld')&&nums.length==1)return false;
 if(t.contains('mindestens zwei unterschiedliche zahlenfelder')&&nums.length<2)return false;
 if(t.contains('mindestens zwei unterschiedliche doubles oder triples')){if(d.where((x)=>x.doubleHit||x.triple).map((x)=>x.fieldKey).toSet().length<2)return false;}
 if(t.contains('mindestens zwei verschiedene doubles oder triples')){if(d.where((x)=>x.doubleHit||x.triple).map((x)=>x.fieldKey).toSet().length<2)return false;}
 if(t.contains('zwei unterschiedliche doubles')||t.contains('zwei verschiedene doubles'))if(d.where((x)=>x.doubleHit).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('zwei unterschiedliche trip')||t.contains('zwei verschiedene trip'))if(d.where((x)=>x.triple).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('zwei unterschiedliche einfache zahlenfelder')||t.contains('zwei unterschiedliche einfache zahlen'))if(d.where((x)=>x.single).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('mindestens zwei darts triple-felder'))if(triples<2)return false;
 if(t.contains('mindestens zwei triple-felder'))if(triples<2)return false;
 if(t.contains('mindestens ein triple-feld'))if(triples<1)return false;
 if(t.contains('mindestens zweimal ein doppelfeld')){if(doubles<2)return false;}
 if(t.contains('mindestens zweimal ein triple-feld')){if(triples<2)return false;}
 if(t.contains('mindestens zweimal ein beliebiges single-feld')){if(singles<2)return false;}
 if(t.contains('mindestens zwei einfache zahlenfelder mit geraden zahlen'))if(d.where((x)=>x.single&&x.number.isEven).length<2)return false;
 if(t.contains('mindestens zwei einfache zahlenfelder mit ungeraden zahlen'))if(d.where((x)=>x.single&&x.number.isOdd).length<2)return false;
 if(t.contains('mindestens zweimal dasselbe zahlenfeld')){final counts=<String,int>{};for(final x in d){counts[x.numberKey]=(counts[x.numberKey]??0)+1;}if(counts.values.every((v)=>v<2))return false;}
 if(t.contains('mindestens zweimal die gleiche zahl als double oder triple')){final hits=d.where((x)=>x.doubleHit||x.triple).toList();if(hits.length<2||hits.map((x)=>x.number).toSet().length!=1)return false;}
 if(t.contains('shanghai')){if(d.map((x)=>x.number).toSet().length!=1||d.where((x)=>x.single).length!=1||d.where((x)=>x.doubleHit).length!=1||d.where((x)=>x.triple).length!=1)return false;}
 // Explicit hit requirements: count phrases are translated into exact field hits.
 // Parse named single/double/triple targets and required count from the text.
 final hitRe=RegExp(r'(mindestens\s+(zweimal|dreimal|einmal|zwei|drei)|mindestens\s+einmal|einmal)?\s*(?:das\s+)?(?:einfache\s+zahlenfeld|einfache\s+|single\s+|double\s+|triple\s+)(\d+)');
 final requiredHits=<String,int>{};
 for(final m in hitRe.allMatches(t)){final segment=m.group(0)!;final n=int.parse(m.group(3)!);final typ=segment.contains('triple')?'T':segment.contains('double')?'D':'S';var count=1;if(segment.contains('zweimal')||segment.contains('zwei '))count=2;if(segment.contains('dreimal')||segment.contains('drei '))count=3;final key='$typ$n';requiredHits[key]=(requiredHits[key]??0)+count;}
 for(final entry in requiredHits.entries){final typ=entry.key[0];final n=int.parse(entry.key.substring(1));if(d.where((x)=>x.number==n&&x.multiplier==typ).length<entry.value)return false;}
 // Generic bull and field requirements.
 if(t.contains('bullseye')&&bulls<1&&!(t.contains('mindestens zweimal bullseye')&&bulls>=2))return false;
 if(t.contains('mindestens zweimal bullseye')&&bulls<2)return false;
 if(t.contains('outer bull')&&outer<(t.contains('zweimal outer bull')||t.contains('mindestens zweimal outer bull')?2:1))return false;
 if(t.contains('mindestens einmal ein doppelfeld')||t.contains('mindestens ein doppelfeld')||t.contains('mindestens ein double'))if(doubles<1)return false;
 if(t.contains('mindestens einmal ein triple')||t.contains('mindestens ein triple'))if(triples<1)return false;
 if(t.contains('mindestens zweimal ein doppelfeld'))if(doubles<2)return false;
 if(t.contains('mindestens zweimal ein triple'))if(triples<2)return false;
 // Requirements for unnumbered categories and ranges.
 if(t.contains('zwei unterschiedliche doubles')&&d.where((x)=>x.doubleHit).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('zwei unterschiedliche trip')&&d.where((x)=>x.triple).map((x)=>x.number).toSet().length<2)return false;
 final range=RegExp(r'(?:bereich|zwischen)\s+(\d+)\s+bis\s+(\d+)').firstMatch(t);if(range!=null){final a=int.parse(range.group(1)!),b=int.parse(range.group(2)!);if(!d.any((x)=>x.single&&x.number>=a&&x.number<=b))return false;}
 // If text contains explicit field targets, every extracted requirement above is checked.
 // Unsupported special clauses remain unfulfilled rather than being guessed.
 final known=t.contains('punkt')||t.contains('triff')||t.contains('treff')||t.contains('wirf')||t.contains('erreich')||t.contains('shanghai');
 if(!known)return false;
 return true;
}
int _wordNum(String s)=>switch(s){'ein'=>1,'einen'=>1,'eine'=>1,'zwei'=>2,'drei'=>3,'vier'=>4,_=>int.tryParse(s)??0};

class ChallengeTile extends StatelessWidget {final PlayerCard item;final String? actionLabel;final VoidCallback? action;const ChallengeTile({super.key,required this.item,this.actionLabel,this.action});Color get color=>switch(item.card.category){'Easy'=>Colors.green,'Medium'=>Colors.blue,'Hard'=>Colors.orange,'Legende'=>Colors.deepPurpleAccent,_=>Colors.redAccent};
 @override Widget build(BuildContext context){final done=item.state!=CardState.open;return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Text('KARTE ${item.card.id}',style:const TextStyle(color:Colors.white54,fontSize:11,fontWeight:FontWeight.bold)),const Spacer(),Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:4),decoration:BoxDecoration(color:color.withOpacity(.18),borderRadius:BorderRadius.circular(20)),child:Text(item.card.category,style:TextStyle(color:color,fontSize:11,fontWeight:FontWeight.bold))),const SizedBox(width:8),Text('+${categoryPoints[item.card.category]} P',style:const TextStyle(fontWeight:FontWeight.bold))]),const SizedBox(height:7),Text(item.card.text,style:TextStyle(fontSize:14,height:1.3,color:done?Colors.white38:Colors.white,decoration:item.state==CardState.crossed?TextDecoration.lineThrough:null,decorationColor:Colors.white70,decorationThickness:2)),if(done)Padding(padding:const EdgeInsets.only(top:7),child:Row(children:[Icon(item.state==CardState.completed?Icons.check_circle:Icons.block,size:16,color:item.state==CardState.completed?Colors.greenAccent:Colors.orangeAccent),const SizedBox(width:6),Text(item.state==CardState.completed?'Erfüllt':'Gestrichen',style:TextStyle(color:item.state==CardState.completed?Colors.greenAccent:Colors.orangeAccent,fontWeight:FontWeight.bold))])),if(actionLabel!=null&&action!=null)Padding(padding:const EdgeInsets.only(top:9),child:SizedBox(width:double.infinity,child:FilledButton(onPressed:action,child:Text(actionLabel!))))])));}}

class ResultsScreen extends StatelessWidget {final List<Player> players;const ResultsScreen({super.key,required this.players});@override Widget build(BuildContext context){final sorted=[...players]..sort((a,b)=>b.score.compareTo(a.score));return Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Spacer(),const Icon(Icons.emoji_events,size:72,color:Color(0xFFFFD166)),const SizedBox(height:12),const Center(child:Text('SPIEL BEENDET',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900))),const SizedBox(height:8),Center(child:Text('Gewonnen hat ${sorted.first.name}',style:const TextStyle(fontSize:18,color:purple))),const SizedBox(height:24),...sorted.map((p)=>Card(child:ListTile(title:Text(p.name),trailing:Text('${p.score} Punkte',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17))))),const Spacer(),FilledButton(onPressed:()=>Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const HomeScreen()),(_)=>false),child:const Text('Zurück zum Hauptmenü'))]))));}}
