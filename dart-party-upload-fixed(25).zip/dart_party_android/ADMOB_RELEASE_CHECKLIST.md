# AdMob – Testintegration und Release-Schritte

Diese ZIP-Version verwendet ausschließlich offizielle Google-Testkennungen:

- Android Test App ID: `ca-app-pub-3940256099942544~3347511713`
- Android Interstitial Test Ad Unit: `ca-app-pub-3940256099942544/1033173712`
- Android App Open Test Ad Unit: `ca-app-pub-3940256099942544/9257395921`

Die Testanzeigen zeigen keine Einnahmen und dürfen nicht in einer öffentlichen Store-Version verbleiben.

## Vor Produktivfreigabe

1. Im AdMob-Konto Dart Party als Android-App registrieren und die echte AdMob-App-ID sowie eigene Anzeigenblock-IDs erzeugen.
2. Die echten IDs in `lib/monetization.dart` und im Build-Workflow einsetzen.
3. Im AdMob-Bereich „Datenschutz und Mitteilungen“ die erforderlichen EWR-/UK-Nachrichten konfigurieren.
4. Consent-Flows in Deutschland, Niederlande und Großbritannien testen; Anzeigen dürfen erst nach UMP-Freigabe geladen werden.
5. Werbefrei-Käufe serverseitig prüfen; diese App blendet reguläre Anzeigen aus, freiwillige Rewarded-Videos sind in diesem Build noch nicht eingebaut.
6. Testanzeigen und Test-App-ID vor dem Store-Release vollständig ersetzen.

Die App lädt Anzeigen nur, wenn UMP `canRequestAds()` erlaubt und der Nutzer nicht das Werbefrei-Produkt besitzt. Interstitials werden nur an vorhandenen Ergebnis-/Übergangspunkten gezeigt und im Client auf mindestens sieben Minuten Abstand begrenzt. App-Open-Anzeigen beginnen erst ab dem dritten App-Start.
