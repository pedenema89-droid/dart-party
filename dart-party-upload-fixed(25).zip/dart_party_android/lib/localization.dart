import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart' as m;
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Language selection and on-device German -> English/Dutch translation.
/// The source data stays German so game logic and saved scores are unchanged.
class AppLocalization {
  AppLocalization._();

  static const String _languageKey = 'dp_app_language';
  static const String _cachePrefix = 'dp_translation_cache_';
  static final m.ValueNotifier<String> language = m.ValueNotifier<String>('de');
  static bool hasSavedSelection = false;
  static SharedPreferences? _prefs;
  static final Map<String, Map<String, String>> _cache = <String, Map<String, String>>{};
  static final Map<String, OnDeviceTranslator> _translators = <String, OnDeviceTranslator>{};
  static final Map<String, Future<String>> _pending = <String, Future<String>>{};
  static final Map<String, Timer> _saveTimers = <String, Timer>{};

  static Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
    final saved = _prefs!.getString(_languageKey);
    if (saved == 'de' || saved == 'en' || saved == 'nl') {
      language.value = saved!;
      hasSavedSelection = true;
      final cached = _prefs!.getString('$_cachePrefix$saved');
      if (cached != null && cached.isNotEmpty) {
        try {
          final decoded = jsonDecode(cached);
          if (decoded is Map) {
            _cache[saved] = decoded.map((key, value) => MapEntry(key.toString(), value.toString()));
          }
        } catch (_) {
          // A damaged translation cache is disposable; the source text remains intact.
        }
      }
    }
  }

  static String languageName(String code) => switch (code) {
        'en' => 'English',
        'nl' => 'Nederlands',
        _ => 'Deutsch',
      };

  static String immediate(String source) {
    final current = language.value;
    const quick = <String, Map<String, String>>{
      'Konto': {'en': 'Account', 'nl': 'Account'},
      'Spielregeln': {'en': 'Game rules', 'nl': 'Spelregels'},
      'Dart Party': {'en': 'Dart Party', 'nl': 'Dart Party'},
    };
    return quick[source]?[current] ?? _cache[current]?[source] ?? source;
  }

  static String? cached(String source, String target) => _cache[target]?[source];

  static Future<void> setLanguage(String code) async {
    if (code != 'de' && code != 'en' && code != 'nl') {
      throw ArgumentError.value(code, 'code', 'Unsupported language');
    }
    if (code != 'de') {
      final target = code == 'en' ? TranslateLanguage.english : TranslateLanguage.dutch;
      final modelManager = OnDeviceTranslatorModelManager();
      // User explicitly selected a language. Permit the one-time model download
      // over the available connection; the models are retained for later offline use.
      final sourceReady = await modelManager.downloadModel(
        TranslateLanguage.german.bcpCode,
        isWifiRequired: true,
      );
      final targetReady = await modelManager.downloadModel(
        target.bcpCode,
        isWifiRequired: true,
      );
      if (!sourceReady || !targetReady) {
        throw StateError('Das Sprachpaket konnte nicht geladen werden. Bitte Verbindung prüfen und erneut versuchen.');
      }
      final translator = _translatorFor(code);
      final check = await translator.translateText('Sprache erfolgreich aktiviert.');
      if (check.trim().isEmpty) {
        throw StateError('Die Übersetzung konnte nicht gestartet werden.');
      }
    }
    _prefs ??= await SharedPreferences.getInstance();
    if (code != 'de' && !_cache.containsKey(code)) {
      final cached = _prefs!.getString('$_cachePrefix$code');
      if (cached != null && cached.isNotEmpty) {
        try {
          final decoded = jsonDecode(cached);
          if (decoded is Map) {
            _cache[code] = decoded.map((key, value) => MapEntry(key.toString(), value.toString()));
          }
        } catch (_) {
          // Ignore an unreadable cache and translate those strings again.
        }
      }
    }
    await _prefs!.setString(_languageKey, code);
    hasSavedSelection = true;
    language.value = code;
  }

  static OnDeviceTranslator _translatorFor(String target) {
    return _translators.putIfAbsent(target, () {
      final targetLanguage = target == 'en' ? TranslateLanguage.english : TranslateLanguage.dutch;
      return OnDeviceTranslator(
        sourceLanguage: TranslateLanguage.german,
        targetLanguage: targetLanguage,
      );
    });
  }

  static Future<String> translate(String source, String target) {
    if (target == 'de' || source.trim().isEmpty || !RegExp(r'[A-Za-zÀ-ÿ]').hasMatch(source)) {
      return Future<String>.value(source);
    }
    final cachedValue = cached(source, target);
    if (cachedValue != null) return Future<String>.value(cachedValue);
    final key = '$target\u0000$source';
    return _pending.putIfAbsent(key, () async {
      try {
        final prepared = _prepareSource(source, target);
        final translated = await _translatorFor(target).translateText(prepared.text);
        final restored = prepared.restore(translated);
        final clean = restored.trim().isEmpty ? source : restored;
        (_cache[target] ??= <String, String>{})[source] = clean;
        _scheduleCacheSave(target);
        return clean;
      } catch (error) {
        print('On-device translation failed ($target): $error');
        return source;
      } finally {
        _pending.remove(key);
      }
    });
  }

  static _ProtectedText _prepareSource(String input, String target) {
    var text = input;
    if (target == 'nl') {
      const categoryTerms = <String, String>{
        'Easy': 'Makkelijk',
        'Medium': 'Gemiddeld',
        'Hard': 'Moeilijk',
        'Legende': 'Legende',
        'Unsterblich': 'Onsterfelijk',
      };
      for (final entry in categoryTerms.entries) {
        text = text.replaceAll(entry.key, entry.value);
      }
    } else {
      const categoryTerms = <String, String>{
        'Legende': 'Legend',
        'Unsterblich': 'Immortal',
      };
      for (final entry in categoryTerms.entries) {
        text = text.replaceAll(entry.key, entry.value);
      }
    }

    // Keep established dart terms and the product name stable across languages.
    const protectedTerms = <String>[
      'Dart Party', 'DART PARTY', 'Bullseye', 'Outer Bull', 'Checkout',
      'Straight In', 'Straight Out', 'Double In', 'Double Out',
      'Master In', 'Master Out', 'Single', 'Double', 'Triple', 'Darts', 'Dart',
    ];
    final replacements = <String, String>{};
    for (var index = 0; index < protectedTerms.length; index++) {
      final term = protectedTerms[index];
      final token = 'ZXQDPTERM${index}QXZ';
      final pattern = RegExp(RegExp.escape(term), caseSensitive: false);
      if (pattern.hasMatch(text)) {
        text = text.replaceAll(pattern, token);
        replacements[token] = term;
      }
    }
    return _ProtectedText(text, replacements);
  }

  static void _scheduleCacheSave(String target) {
    _saveTimers[target]?.cancel();
    _saveTimers[target] = Timer(const Duration(seconds: 2), () async {
      try {
        _prefs ??= await SharedPreferences.getInstance();
        await _prefs!.setString('$_cachePrefix$target', jsonEncode(_cache[target] ?? <String, String>{}));
      } catch (error) {
        print('Translation cache save failed: $error');
      }
    });
  }
}

class _ProtectedText {
  final String text;
  final Map<String, String> replacements;
  const _ProtectedText(this.text, this.replacements);

  String restore(String translated) {
    var result = translated;
    for (final entry in replacements.entries) {
      result = result.replaceAll(entry.key, entry.value);
    }
    return result;
  }
}

/// Drop-in text widget used by the app. It keeps the original layout/styles,
/// but translates every displayed string when English or Dutch is selected.
class LocalizedText extends m.StatelessWidget {
  final String data;
  final m.TextStyle? style;
  final m.StrutStyle? strutStyle;
  final m.TextAlign? textAlign;
  final m.TextDirection? textDirection;
  final m.Locale? locale;
  final bool? softWrap;
  final m.TextOverflow? overflow;
  final int? maxLines;
  final String? semanticsLabel;
  final m.TextWidthBasis? textWidthBasis;
  final m.TextHeightBehavior? textHeightBehavior;
  final m.Color? selectionColor;
  final m.TextScaler? textScaler;

  const LocalizedText(
    this.data, {
    super.key,
    this.style,
    this.strutStyle,
    this.textAlign,
    this.textDirection,
    this.locale,
    this.softWrap,
    this.overflow,
    this.maxLines,
    this.semanticsLabel,
    this.textWidthBasis,
    this.textHeightBehavior,
    this.selectionColor,
    this.textScaler,
  });

  m.Text _plain(String value) => m.Text(
        value,
        style: style,
        strutStyle: strutStyle,
        textAlign: textAlign,
        textDirection: textDirection,
        locale: locale,
        softWrap: softWrap,
        overflow: overflow,
        maxLines: maxLines,
        semanticsLabel: semanticsLabel,
        textWidthBasis: textWidthBasis,
        textHeightBehavior: textHeightBehavior,
        selectionColor: selectionColor,
        textScaler: textScaler,
      );

  @override
  m.Widget build(m.BuildContext context) {
    return m.ValueListenableBuilder<String>(
      valueListenable: AppLocalization.language,
      builder: (context, selectedLanguage, _) {
        if (selectedLanguage == 'de') return _plain(data);
        final known = AppLocalization.cached(data, selectedLanguage);
        if (known != null) return _plain(known);
        return m.FutureBuilder<String>(
          future: AppLocalization.translate(data, selectedLanguage),
          initialData: data,
          builder: (context, snapshot) => _plain(snapshot.data ?? data),
        );
      },
    );
  }
}

class LanguageSelectionGate extends m.StatefulWidget {
  final m.Widget child;
  const LanguageSelectionGate({super.key, required this.child});

  @override
  m.State<LanguageSelectionGate> createState() => _LanguageSelectionGateState();
}

class _LanguageSelectionGateState extends m.State<LanguageSelectionGate> {
  @override
  m.Widget build(m.BuildContext context) {
    if (AppLocalization.hasSavedSelection) return widget.child;
    return LanguagePickerScreen(
      firstRun: true,
      onSelected: () {
        if (mounted) setState(() {});
      },
    );
  }
}

class LanguagePickerScreen extends m.StatefulWidget {
  final bool firstRun;
  final m.VoidCallback? onSelected;
  const LanguagePickerScreen({super.key, this.firstRun = false, this.onSelected});

  @override
  m.State<LanguagePickerScreen> createState() => _LanguagePickerScreenState();
}

class _LanguagePickerScreenState extends m.State<LanguagePickerScreen> {
  String _selected = AppLocalization.language.value;
  bool _busy = false;
  String? _error;

  Future<void> _apply() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await AppLocalization.setLanguage(_selected);
      if (!mounted) return;
      if (widget.firstRun) {
        widget.onSelected?.call();
      } else {
        m.Navigator.of(context).pop();
      }
    } catch (error) {
      if (mounted) setState(() => _error = error.toString().replaceFirst('Bad state: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  m.Widget build(m.BuildContext context) {
    return m.Scaffold(
      appBar: widget.firstRun ? null : m.AppBar(title: const m.Text('Language / Sprache / Taal')),
      body: m.SafeArea(
        child: m.Center(
          child: m.ConstrainedBox(
            constraints: const m.BoxConstraints(maxWidth: 520),
            child: m.ListView(
              shrinkWrap: true,
              padding: const m.EdgeInsets.all(24),
              children: [
                const m.Icon(m.Icons.language, size: 52, color: m.Color(0xFFD6B56D)),
                const m.SizedBox(height: 18),
                const m.Text(
                  'Wähle deine Sprache / Choose your language / Kies je taal',
                  textAlign: m.TextAlign.center,
                  style: m.TextStyle(fontSize: 21, fontWeight: m.FontWeight.w800),
                ),
                const m.SizedBox(height: 12),
                const m.Text(
                  'Für Englisch und Niederländisch werden die Sprachpakete einmalig über WLAN geladen. Danach funktioniert die Übersetzung auch offline. Automatische Übersetzungen können Fehler enthalten; die deutsche Fassung bleibt die Originalversion.',
                  textAlign: m.TextAlign.center,
                  style: m.TextStyle(color: m.Colors.white70, height: 1.4),
                ),
                const m.SizedBox(height: 24),
                for (final option in const <(String, String, String)>[
                  ('de', 'Deutsch', 'Deutsch'),
                  ('en', 'English', 'English'),
                  ('nl', 'Nederlands', 'Nederlands'),
                ])
                  m.Padding(
                    padding: const m.EdgeInsets.only(bottom: 10),
                    child: m.RadioListTile<String>(
                      value: option.$1,
                      groupValue: _selected,
                      onChanged: _busy ? null : (value) => setState(() => _selected = value ?? 'de'),
                      title: m.Text(option.$2, style: const m.TextStyle(fontWeight: m.FontWeight.w700)),
                      subtitle: m.Text(option.$3, style: const m.TextStyle(color: m.Colors.white54)),
                    ),
                  ),
                if (_busy) ...[
                  const m.SizedBox(height: 12),
                  const m.LinearProgressIndicator(),
                  const m.SizedBox(height: 10),
                  const m.Text('Sprachpaket wird vorbereitet … / Preparing language pack …', textAlign: m.TextAlign.center),
                ],
                if (_error != null) ...[
                  const m.SizedBox(height: 12),
                  m.Text(_error!, style: const m.TextStyle(color: m.Colors.redAccent), textAlign: m.TextAlign.center),
                ],
                const m.SizedBox(height: 18),
                m.FilledButton(
                  onPressed: _busy ? null : _apply,
                  child: m.Text(widget.firstRun ? 'Weiter / Continue / Verder' : 'Speichern / Save / Opslaan'),
                ),
                if (!widget.firstRun)
                  m.TextButton(
                    onPressed: _busy ? null : () => m.Navigator.of(context).pop(),
                    child: const m.Text('Abbrechen / Cancel / Annuleren'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
