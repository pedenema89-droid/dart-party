import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'localization.dart';

/// Handles the mandatory Google sign-in used by Dart Party.
/// The web OAuth client ID is used as the server client ID so Google Sign-In
/// can return an ID token that Firebase Authentication accepts.
class DartPartyAuth {
  DartPartyAuth._();

  static const String _serverClientId =
      '773111487498-sqeksb1q47db9lebn83mdflvi3p1njpo.apps.googleusercontent.com';

  static final GoogleSignIn _googleSignIn = GoogleSignIn.instance;
  static Future<void>? _googleInitialization;

  static Future<void> _initializeGoogleSignIn() {
    return _googleInitialization ??= _googleSignIn.initialize(
      serverClientId: _serverClientId,
    );
  }

  static Future<UserCredential> signInWithGoogle() async {
    await _initializeGoogleSignIn();
    final GoogleSignInAccount googleUser = await _googleSignIn.authenticate();
    final String? idToken = googleUser.authentication.idToken;
    if (idToken == null || idToken.isEmpty) {
      throw StateError(
        'Google hat kein Anmeldetoken geliefert. Bitte SHA-1 und OAuth-Konfiguration prüfen.',
      );
    }

    final OAuthCredential credential =
        GoogleAuthProvider.credential(idToken: idToken);
    return FirebaseAuth.instance.signInWithCredential(credential);
  }

  static Future<void> signOut() async {
    await FirebaseAuth.instance.signOut();
    await _initializeGoogleSignIn();
    await _googleSignIn.signOut();
  }

  /// A new match may only begin while the signed-in account can be refreshed
  /// against Firebase. An already started match is not interrupted if the
  /// connection drops afterwards.
  static Future<bool> verifyOnlineSession() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;
    try {
      final addresses = await InternetAddress.lookup('firebase.google.com')
          .timeout(const Duration(seconds: 6));
      if (addresses.isEmpty) return false;
      await user.getIdToken(true).timeout(const Duration(seconds: 10));
      return true;
    } catch (_) {
      return false;
    }
  }
}

class FirebaseAuthGate extends StatefulWidget {
  final Widget child;

  const FirebaseAuthGate({super.key, required this.child});

  @override
  State<FirebaseAuthGate> createState() => _FirebaseAuthGateState();
}

class _FirebaseAuthGateState extends State<FirebaseAuthGate> {
  bool _checkingConnection = true;
  bool _online = false;

  @override
  void initState() {
    super.initState();
    _checkStartupConnection();
  }

  Future<void> _checkStartupConnection() async {
    if (mounted) setState(() => _checkingConnection = true);
    bool online = false;
    try {
      final addresses = await InternetAddress.lookup('firebase.google.com')
          .timeout(const Duration(seconds: 8));
      online = addresses.isNotEmpty;
      final User? user = FirebaseAuth.instance.currentUser;
      if (online && user != null) {
        await user.getIdToken(true).timeout(const Duration(seconds: 10));
      }
    } catch (_) {
      online = false;
    }
    if (!mounted) return;
    setState(() {
      _online = online;
      _checkingConnection = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_checkingConnection) {
      return const _AuthLoadingScreen();
    }
    if (!_online) {
      return _ConnectionRequiredScreen(onRetry: _checkStartupConnection);
    }

    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _AuthLoadingScreen();
        }
        if (snapshot.hasError) {
          return _ConnectionRequiredScreen(onRetry: _checkStartupConnection);
        }
        if (snapshot.data == null) return const GoogleLoginScreen();
        return widget.child;
      },
    );
  }
}

class GoogleLoginScreen extends StatefulWidget {
  const GoogleLoginScreen({super.key});

  @override
  State<GoogleLoginScreen> createState() => _GoogleLoginScreenState();
}

class _GoogleLoginScreenState extends State<GoogleLoginScreen> {
  bool _busy = false;
  String? _error;

  Future<void> _signIn() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await DartPartyAuth.signInWithGoogle();
    } catch (error) {
      if (!mounted) return;
      final message = error.toString();
      setState(() {
        _error = message.contains('canceled') || message.contains('cancelled')
            ? 'Anmeldung abgebrochen.'
            : 'Die Google-Anmeldung hat nicht funktioniert. Bitte prüfe deine Internetverbindung und versuche es erneut.';
      });
      debugPrint('Google sign-in failed: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFD6B56D);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(26),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/brand/dart_party_logo.png',
                    height: 170,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(height: 24),
                  const LocalizedText(
                    'Willkommen bei Dart Party',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 10),
                  const LocalizedText(
                    'Melde dich mit deinem Google-Konto an, um zu spielen. Eine aktive Internetverbindung ist erforderlich.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, height: 1.45),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _signIn,
                      icon: _busy
                          ? const SizedBox(
                              width: 19,
                              height: 19,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.login),
                      label: LocalizedText(_busy ? 'Anmeldung läuft …' : 'Mit Google anmelden'),
                      style: FilledButton.styleFrom(
                        backgroundColor: gold,
                        foregroundColor: const Color(0xFF171717),
                        textStyle: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 18),
                    LocalizedText(
                      _error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.redAccent),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ConnectionRequiredScreen extends StatelessWidget {
  final Future<void> Function() onRetry;

  const _ConnectionRequiredScreen({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off, size: 58, color: Color(0xFFD6B56D)),
                const SizedBox(height: 18),
                const LocalizedText(
                  'Internetverbindung erforderlich',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 10),
                const LocalizedText(
                  'Dart Party benötigt eine aktive Internetverbindung. Sobald du wieder online bist, kannst du fortfahren.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, height: 1.45),
                ),
                const SizedBox(height: 22),
                FilledButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh),
                  label: const LocalizedText('Erneut versuchen'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AuthLoadingScreen extends StatelessWidget {
  const _AuthLoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports, size: 58, color: Color(0xFFD6B56D)),
            SizedBox(height: 16),
            LocalizedText(
              'DART PARTY',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            SizedBox(height: 18),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class FirebaseInitializationErrorScreen extends StatelessWidget {
  final String error;

  const FirebaseInitializationErrorScreen({super.key, required this.error});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, color: Colors.redAccent, size: 48),
              const SizedBox(height: 16),
              const LocalizedText(
                'Dart Party konnte Firebase nicht starten.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const LocalizedText(
                'Bitte prüfe die App-Konfiguration und installiere die korrigierte Version.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 12),
              SelectableText(
                error,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white38, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
