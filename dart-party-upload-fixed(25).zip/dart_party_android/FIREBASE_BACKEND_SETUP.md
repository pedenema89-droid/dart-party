# Dart Party – Firebase-Backend für Token

## Inhalt

- `functions/getWallet`: legt das Spielerkonto beim ersten Aufruf serverseitig an und vergibt einmalig 5 Starttoken plus 2 tägliche Gratis-Token.
- `functions/startMatch`: prüft die Anmeldung, setzt das tägliche Kontingent nach dem Kalenderdatum Europe/Berlin zurück und bucht genau einen Token pro neuer Partie ab.
- `functions/verifyPlayPurchase`: prüft Google-Play-Kauf-Tokens serverseitig über die Android Developer API; Einmalkäufe werden über `productsv2.getproductpurchasev2`, Abos über `subscriptionsv2.get` geprüft. Kauf-Token und gehashte Firebase-Konto-ID werden abgeglichen; Token-Pakete und Premium-Berechtigungen werden erst nach erfolgreicher Prüfung gutgeschrieben.
- Wiederholte Requests mit derselben `matchId` werden idempotent behandelt und buchen keinen zweiten Token ab.
- Firestore-Regeln verweigern alle direkten Client-Lese- und Schreibzugriffe. Nur Cloud Functions mit Firebase Admin SDK schreiben die Wallet-Dokumente.
- Cloud Functions laufen in `europe-west3` (Frankfurt), mit `maxInstances: 10`.

## Wichtige Einschränkung in diesem Zwischenstand

Die Kaufprüfung ist im Quellcode vorbereitet, aber `verifyPlayPurchase` muss noch deployt werden. Vor echten Käufen müssen Google Play Console, Android Developer API und die Berechtigungen des Firebase-Functions-Laufzeitkontos eingerichtet sein. Bis dahin bleiben die Kaufbuttons ohne verfügbare Play-Produkte deaktiviert.

## Deploy über Google Cloud Shell

Voraussetzung: Die ZIP mit diesem Ordner muss im GitHub-Repository `pedenema89-droid/dart-party` liegen. Danach in Google Cloud Console die Cloud Shell öffnen und diese Befehle nacheinander ausführen:

```bash
npm install -g firebase-tools
firebase login --no-localhost
 git clone https://github.com/pedenema89-droid/dart-party.git
cd dart-party
ZIP_FILE="$(ls -1 dart-party-upload-fixed*.zip | sort -V | tail -n 1)"
mkdir -p /tmp/dart-party-firebase
unzip -oq "$ZIP_FILE" -d /tmp/dart-party-firebase
cd /tmp/dart-party-firebase/dart_party_android
npm --prefix functions install
npm --prefix functions test
firebase deploy --only functions,firestore:rules --project darts-party-2871c
```

Falls `git clone` meldet, dass der Ordner schon existiert, zuerst `cd ~/dart-party && git pull` ausführen, dann mit `ZIP_FILE=...` fortfahren. Die Befehle zum Entpacken und Deployen werden danach erneut ausgeführt.

Beim ersten Deploy kann Google nach der Aktivierung benötigter APIs fragen. Für Cloud Functions kann Google zusätzlich die Einrichtung von Artifact Registry und Cloud Build aktivieren. Nur bestätigen, wenn das Projekt `darts-party-2871c` angezeigt wird.

## Danach

1. GitHub Actions baut die Android-App aus derselben ZIP.
2. Die neue APK installieren und mit Google anmelden.
3. Prüfen, ob das Konto 5 Starttoken und 2 Tages-Token vom Server erhält.
4. Eine Partie starten und prüfen, dass der Server ein Token abbucht.
5. Offline während derselben Partie weiter spielen; es erfolgt keine zweite Serveranfrage.
6. Vor echten Käufen die Schritte aus `MONETARISIERUNG_EINRICHTEN.md` durchführen und `verifyPlayPurchase` mit internen Play-Testkäufen prüfen.

## Sicherheitsmodell

Die Callable Functions verlangen Firebase-Authentifizierung. Das Guthaben befindet sich unter `users/{uid}`. Jede Partie erhält unter `users/{uid}/matchRequests/{matchId}` einen serverseitigen Idempotenz-Eintrag. Die App speichert eine noch nicht bestätigte `matchId` lokal, damit sie einen unklaren Netzwerk-Timeout sicher wiederholen kann.
