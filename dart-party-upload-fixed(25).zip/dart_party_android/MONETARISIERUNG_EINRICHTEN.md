# Dart Party – Token- und Premium-Modell (Version 1.5.0)

## In der App vorgesehene Regeln
- Bei der ersten Installation: 5 einmalige Starttoken.
- Pro Kalendertag: 2 kostenlose Token. Nicht verbrauchte Tages-Token werden nicht in den Folgetag übertragen; am neuen Tag stehen wieder 2 bereit.
- Pro gestarteter Partie wird genau 1 Token abgezogen. Mehrere Runden innerhalb derselben Partie verbrauchen keine weiteren Token.
- Verbrauchsreihenfolge: Starttoken, Tages-Token, gekaufte Token.
- Gekaufte Token verfallen nicht.
- Lifetime: 29,99 € einmalig, dauerhaft unbegrenzt spielen.
- Monatsabo: 2,99 € pro Monat, während eines aktiven Abos unbegrenzt spielen. Der Abo-Status wird beim Start über Google Play wiederhergestellt und nicht als dauerhaftes lokales Flag gespeichert.

## Vorgeschlagene Google-Play-Produkte
Die folgenden Produkt-IDs müssen in der Play Console exakt so angelegt werden. Die angezeigten Fallback-Preise sind Vorschläge; nach Produktabfrage zeigt die App den tatsächlichen Play-Preis.

| Produkt-ID | Typ | Preisvorschlag | Inhalt |
|---|---|---:|---:|
| `dart_party_token_1` | Verbrauchsprodukt | 0,49 € | 1 Token |
| `dart_party_token_10` | Verbrauchsprodukt | 2,99 € | 10 Token |
| `dart_party_token_30` | Verbrauchsprodukt | 5,99 € | 30 Token |
| `dart_party_token_100` | Verbrauchsprodukt | 12,99 € | 100 Token |
| `dart_party_monthly_unlimited` | Abo | 2,99 €/Monat | Unbegrenzt während aktiver Laufzeit |
| `dart_party_lifetime_unlimited` | Einmalkauf | 29,99 € | Dauerhaft unbegrenzt |
| `dart_party_ad_free_lifetime` | Einmalkauf | 7,99 € | Reguläre Werbung dauerhaft aus; Rewarded Videos für Token ausgenommen |

## Technische Kaufabwicklung (Code vorbereitet)
- Die App lädt Preise und Produktdetails direkt aus Google Play; die im Dokument genannten Preise sind nur die vorgesehenen Ausgangspreise.
- Token-Pakete werden als Verbrauchsprodukte gekauft; Premium monatlich, Lifetime und werbefrei werden als dauerhafte/Abonnement-Produkte behandelt.
- Nach einem Kauf sendet die App Produkt-ID und Kauf-Token an `verifyPlayPurchase`. Nur wenn die Google-Play-Developer-API den Kauf bestätigt, schreibt der Server Token oder Berechtigungen gut. Erst danach wird ein Token-Kauf im Play Store verbraucht bzw. ein dauerhaftes Produkt bestätigt.
- Kauf-Tokens werden serverseitig per SHA-256 eindeutig erfasst. Ein erneut zugestelltes Kaufereignis darf denselben Kauf nicht nochmals gutschreiben.
- Beim Kauf sendet die App eine SHA-256-Kennung des angemeldeten Firebase-Kontos an Google Play. Der Server vergleicht diese Kennung mit dem von Google zurückgegebenen `obfuscatedExternalAccountId`; damit wird ein Kauf fest an das auslösende App-Konto gebunden.
- Einmalkäufe werden mit Googles `purchases.productsv2.getproductpurchasev2` und Abos mit `purchases.subscriptionsv2.get` geprüft. Die Konto-Kennung wird entsprechend der jeweiligen Google-Antwortstruktur ausgelesen: bei Einmalkäufen direkt, bei Abos aus `externalAccountIdentifiers.obfuscatedExternalAccountId`.
- Der App-Status bleibt gesperrt, solange die Produkte nicht im Play Store verfügbar sind oder die Google-Play-API-Berechtigung fehlt.

### Noch erforderliche Einrichtung vor echten Käufen
1. In der Google Play Console später die sieben IDs aus der Tabelle exakt anlegen. Die vier Token-Produkte sind Verbrauchsprodukte; Monatsabo ist ein Abo; Lifetime und Werbefrei sind Einmalkäufe.
2. Die Google Play Android Developer API im mit der App verknüpften Google-Cloud-Projekt aktivieren.
3. Das Laufzeitdienstkonto der Firebase-Functions im Play-Console-Nutzer-/Berechtigungsbereich mit den erforderlichen Bestell- und Abonnement-Berechtigungen hinzufügen. Es wird kein privater Service-Account-Schlüssel in die App oder das Repository gelegt.
4. `verifyPlayPurchase` deployen und nach Einrichtung mit internen Testkäufen prüfen. Bis dahin bleiben echte Käufe deaktiviert.

## Werbung
Werbung ist in dieser Version absichtlich NICHT implementiert. Geplant sind später: (1) freiwilliges Rewarded Video für +1 Token, Token nur nach bestätigtem vollständigem Reward; (2) eine Werbeeinblendung nach einer Partie; (3) eine Werbeeinblendung beim Start einer Partie. Die genaue Frequenz und die beiden Interstitial-Platzierungen müssen vor der AdMob-Integration noch technisch festgelegt werden, damit nicht direkt vor und nach jeder Partie übermäßig Werbung erscheint.

## Noch offene Release-Voraussetzungen
- Die Produkt-IDs in der Play Console anlegen und aktivieren.
- Die Google Play Android Developer API und die Berechtigungen des Firebase-Functions-Laufzeitkontos einrichten.
- `verifyPlayPurchase` in Firebase deployen; erst danach interne Testkäufe ausführen.
- Einmalkäufe werden mit `productsv2.getproductpurchasev2`, Abos mit `subscriptionsv2.get` geprüft. Echtzeit-Benachrichtigungen (RTDN) für Verlängerungen, Erstattungen und Statuswechsel sind noch nicht eingerichtet; die App gleicht den Status beim Start und bei manueller Wiederherstellung ab.
- Werbung bleibt deaktiviert, bis AdMob eingerichtet und getestet ist.
