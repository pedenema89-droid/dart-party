
'use strict';

const crypto = require('node:crypto');

const KEY_URL = 'https://www.gstatic.com/admob/reward/verifier-keys.json';
let cachedKeys = null;
let cachedAt = 0;
const CACHE_MS = 24 * 60 * 60 * 1000;

function splitSignedQuery(rawQuery) {
  const signatureMarker = rawQuery.lastIndexOf('&signature=');
  const keyMarker = rawQuery.lastIndexOf('&key_id=');
  if (signatureMarker <= 0 || keyMarker <= signatureMarker) {
    throw new Error('Missing or misplaced AdMob SSV signature fields.');
  }
  const signatureRaw = rawQuery.slice(signatureMarker + '&signature='.length, keyMarker);
  const keyIdRaw = rawQuery.slice(keyMarker + '&key_id='.length);
  if (!signatureRaw || !/^\d+$/.test(keyIdRaw)) {
    throw new Error('Malformed AdMob SSV signature fields.');
  }
  return {
    signedPayload: rawQuery.slice(0, signatureMarker),
    signatureRaw,
    keyId: Number(keyIdRaw),
  };
}

function verifySsvQueryString(rawQuery, publicKeys) {
  const { signedPayload, signatureRaw, keyId } = splitSignedQuery(rawQuery);
  const key = publicKeys instanceof Map ? publicKeys.get(keyId) : publicKeys[String(keyId)];
  if (!key) return false;
  const signatureBase64 = decodeURIComponent(signatureRaw)
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  const signature = Buffer.from(signatureBase64, 'base64');
  if (signature.length < 32) return false;
  const publicKey = typeof key === 'string' ? crypto.createPublicKey(key) : key;
  return crypto.verify(
    'sha256',
    Buffer.from(signedPayload, 'utf8'),
    publicKey,
    signature,
  );
}

async function getAdMobPublicKeys() {
  if (cachedKeys && Date.now() - cachedAt < CACHE_MS) return cachedKeys;
  const response = await fetch(KEY_URL, { signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error(`AdMob key server responded ${response.status}`);
  const body = await response.json();
  if (!Array.isArray(body.keys) || body.keys.length === 0) {
    throw new Error('AdMob key server returned no public keys.');
  }
  const next = new Map();
  for (const entry of body.keys) {
    if (!Number.isSafeInteger(Number(entry.keyId)) || !entry.pem) continue;
    next.set(Number(entry.keyId), crypto.createPublicKey(entry.pem));
  }
  if (next.size === 0) throw new Error('No usable AdMob public keys received.');
  cachedKeys = next;
  cachedAt = Date.now();
  return cachedKeys;
}

async function verifyAdMobSsv(rawQuery) {
  const keys = await getAdMobPublicKeys();
  return verifySsvQueryString(rawQuery, keys);
}

module.exports = {
  splitSignedQuery,
  verifySsvQueryString,
  verifyAdMobSsv,
};
