const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue, Timestamp } = require('firebase-admin/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const { google } = require('googleapis');
const { createHash, randomBytes } = require('node:crypto');
const { onCall, onRequest, HttpsError } = require('firebase-functions/v2/https');
const { verifyAdMobSsv } = require('./ssv_verifier');
const {
  berlinDateKey,
  initialWallet,
  normalizeWallet,
  refreshDailyTokens,
  isUnlimited,
  consumeOneToken,
  publicWallet,
} = require('./wallet_logic');

initializeApp();
setGlobalOptions({
  region: 'europe-west3',
  maxInstances: 10,
});

const db = getFirestore();

function requireUid(request) {
  const uid = request.auth && request.auth.uid;
  if (!uid) {
    throw new HttpsError('unauthenticated', 'Bitte melde dich mit Google an.');
  }
  return uid;
}

function validateMatchId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{12,100}$/.test(value);
}

function walletDocument(uid) {
  return db.collection('users').doc(uid);
}

exports.getWallet = onCall(async (request) => {
  const uid = requireUid(request);
  const userRef = walletDocument(uid);
  const today = berlinDateKey();

  const wallet = await db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(userRef);
    const current = snapshot.exists
      ? normalizeWallet(snapshot.data(), today)
      : initialWallet(today);
    const refreshed = refreshDailyTokens(current, today);
    const needsWrite = !snapshot.exists || current.dailyDate !== today;
    if (needsWrite) {
      const writeData = {
        ...refreshed,
        updatedAt: FieldValue.serverTimestamp(),
      };
      if (!snapshot.exists) writeData.createdAt = FieldValue.serverTimestamp();
      transaction.set(userRef, writeData, { merge: true });
    }
    return refreshed;
  });

  return publicWallet(wallet);
});

exports.startMatch = onCall(async (request) => {
  const uid = requireUid(request);
  const matchId = request.data && request.data.matchId;
  if (!validateMatchId(matchId)) {
    throw new HttpsError('invalid-argument', 'Ungültige Spielkennung.');
  }

  const userRef = walletDocument(uid);
  const matchRef = userRef.collection('matchRequests').doc(matchId);
  const today = berlinDateKey();

  const result = await db.runTransaction(async (transaction) => {
    const [userSnapshot, matchSnapshot] = await Promise.all([
      transaction.get(userRef),
      transaction.get(matchRef),
    ]);

    const current = userSnapshot.exists
      ? normalizeWallet(userSnapshot.data(), today)
      : initialWallet(today);
    let wallet = refreshDailyTokens(current, today);

    if (matchSnapshot.exists) {
      // Idempotency: lost responses/retries for the same attempted game do not
      // consume a second token.
      return {
        allowed: true,
        alreadyStarted: true,
        ...publicWallet(wallet),
      };
    }

    let tokenCharged = false;
    let tokenSource = 'unlimited';
    if (!isUnlimited(wallet)) {
      const spend = consumeOneToken(wallet);
      wallet = spend.wallet;
      if (!spend.consumed) {
        const noTokensWrite = {
          ...wallet,
          updatedAt: FieldValue.serverTimestamp(),
        };
        if (!userSnapshot.exists) noTokensWrite.createdAt = FieldValue.serverTimestamp();
        transaction.set(userRef, noTokensWrite, { merge: true });
        return {
          allowed: false,
          reason: 'NO_TOKENS',
          ...publicWallet(wallet),
        };
      }
      tokenCharged = true;
      tokenSource = spend.source;
    }

    const walletWrite = {
      ...wallet,
      updatedAt: FieldValue.serverTimestamp(),
    };
    if (!userSnapshot.exists) walletWrite.createdAt = FieldValue.serverTimestamp();
    transaction.set(userRef, walletWrite, { merge: true });
    transaction.create(matchRef, {
      matchId,
      uid,
      status: 'started',
      tokenCharged,
      tokenSource,
      startedAt: FieldValue.serverTimestamp(),
    });

    return {
      allowed: true,
      alreadyStarted: false,
      ...publicWallet(wallet),
    };
  });

  return result;
});

const PLAY_PACKAGE_NAME = 'de.dartsparty.app';
const PLAY_ANDROID_PUBLISHER_SCOPE = 'https://www.googleapis.com/auth/androidpublisher';
const { PLAY_PRODUCTS } = require('./purchase_catalog');
const { extractObfuscatedAccountId } = require('./purchase_helpers');

async function getAndroidPublisher() {
  const auth = new google.auth.GoogleAuth({
    scopes: [PLAY_ANDROID_PUBLISHER_SCOPE],
  });
  return google.androidpublisher({ version: 'v3', auth });
}

function purchaseTokenHash(token) {
  return createHash('sha256').update(token).digest('hex');
}

function toMillis(value) {
  if (!value) return null;
  if (typeof value.toMillis === 'function') return value.toMillis();
  if (value instanceof Date) return value.getTime();
  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : null;
}

exports.verifyPlayPurchase = onCall(async (request) => {
  const uid = requireUid(request);
  const productId = request.data && request.data.productId;
  const purchaseToken = request.data && request.data.purchaseToken;
  const product = Object.prototype.hasOwnProperty.call(PLAY_PRODUCTS, productId)
    ? PLAY_PRODUCTS[productId]
    : null;

  if (!product || typeof purchaseToken !== 'string' ||
      purchaseToken.length < 10 || purchaseToken.length > 4096) {
    throw new HttpsError('invalid-argument', 'Ungültige Kaufdaten.');
  }

  let verifiedSubscription = null;
  let verifiedPurchaseQuantity = 1;
  let verifiedAccountId = null;
  const expectedAccountId = purchaseTokenHash(uid);
  const publisher = await getAndroidPublisher();
  try {
    if (product.kind === 'subscription') {
      const response = await publisher.purchases.subscriptionsv2.get({
        packageName: PLAY_PACKAGE_NAME,
        token: purchaseToken,
      });
      const subscription = response.data;
      const lineItem = (subscription.lineItems || []).find(
        (item) => item.productId === productId,
      );
      if (!lineItem) {
        throw new HttpsError('failed-precondition', 'Das Google-Play-Abo passt nicht zum Produkt.');
      }
      const expiryMillis = toMillis(lineItem.expiryTime);
      const validStates = new Set([
        'SUBSCRIPTION_STATE_ACTIVE',
        'SUBSCRIPTION_STATE_IN_GRACE_PERIOD',
        'SUBSCRIPTION_STATE_CANCELED',
      ]);
      const entitled = validStates.has(subscription.subscriptionState) &&
        expiryMillis !== null && expiryMillis > Date.now();
      verifiedAccountId = extractObfuscatedAccountId(subscription, 'subscription');
      verifiedSubscription = {
        entitled,
        expiryMillis,
        state: subscription.subscriptionState || 'UNKNOWN',
      };
      if (!entitled && subscription.subscriptionState === 'SUBSCRIPTION_STATE_PENDING') {
        throw new HttpsError('failed-precondition', 'Die Abo-Zahlung ist noch nicht abgeschlossen.');
      }
    } else {
      const response = await publisher.purchases.productsv2.getproductpurchasev2({
        packageName: PLAY_PACKAGE_NAME,
        token: purchaseToken,
      });
      const purchase = response.data;
      const lineItem = (purchase.productLineItem || []).find(
        (item) => item.productId === productId,
      );
      if (!lineItem || purchase.purchaseStateContext?.purchaseState !== 'PURCHASED') {
        throw new HttpsError('failed-precondition', 'Google Play bestätigt diesen Kauf nicht als bezahlt.');
      }
      verifiedAccountId = extractObfuscatedAccountId(purchase, 'product');
      if (product.kind === 'consumable') {
        const quantity = lineItem.productOfferDetails?.quantity ?? 1;
        if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 100) {
          throw new HttpsError('failed-precondition', 'Ungültige Kaufmenge.');
        }
        verifiedPurchaseQuantity = quantity;
      }
    }
  } catch (error) {
    if (error instanceof HttpsError) throw error;
    console.error('Google Play purchase lookup failed:', error);
    throw new HttpsError('failed-precondition', 'Google Play konnte den Kauf nicht bestätigen.');
  }

  if (verifiedAccountId !== expectedAccountId) {
    throw new HttpsError('permission-denied', 'Dieser Kauf gehört nicht zum angemeldeten Dart-Party-Konto.');
  }

  const today = berlinDateKey();
  const receiptId = purchaseTokenHash(purchaseToken);
  const receiptRef = db.collection('playPurchaseReceipts').doc(receiptId);
  const userRef = walletDocument(uid);

  const wallet = await db.runTransaction(async (transaction) => {
    const [receiptSnapshot, userSnapshot] = await Promise.all([
      transaction.get(receiptRef),
      transaction.get(userRef),
    ]);

    if (receiptSnapshot.exists) {
      const receipt = receiptSnapshot.data();
      if (receipt.uid !== uid || receipt.productId !== productId) {
        throw new HttpsError('already-exists', 'Dieser Google-Play-Kauf ist bereits einem anderen Konto zugeordnet.');
      }
    }

    let current = userSnapshot.exists
      ? normalizeWallet(userSnapshot.data(), today)
      : initialWallet(today);
    current = refreshDailyTokens(current, today);

    if (product.kind === 'subscription') {
      if (!receiptSnapshot.exists && !verifiedSubscription.entitled) {
        throw new HttpsError('failed-precondition', 'Das Google-Play-Abo ist nicht aktiv.');
      }
      // Bei jeder erneuten Prüfung wird die tatsächliche Play-Laufzeit übernommen.
      // So werden Verlängerungen und abgelaufene/pausierte Abos korrekt abgebildet.
      if (verifiedSubscription.entitled) {
        const currentExpiry = toMillis(current.monthlyUntil);
        if (current.monthlyPurchaseHash === receiptId || currentExpiry === null ||
            verifiedSubscription.expiryMillis > currentExpiry) {
          current.monthlyUntil = Timestamp.fromMillis(verifiedSubscription.expiryMillis);
          current.monthlyPurchaseHash = receiptId;
        }
      } else if (current.monthlyPurchaseHash === receiptId) {
        current.monthlyUntil = null;
        current.monthlyPurchaseHash = null;
      }
    } else if (!receiptSnapshot.exists) {
      if (product.kind === 'consumable') {
        current.purchasedTokens += product.tokens * verifiedPurchaseQuantity;
      } else if (product.kind === 'lifetime') {
        current.lifetimeUnlimited = true;
      } else if (product.kind === 'adFree') {
        current.adFree = true;
      }
    }

    const walletWrite = {
      ...current,
      updatedAt: FieldValue.serverTimestamp(),
    };
    if (!userSnapshot.exists) walletWrite.createdAt = FieldValue.serverTimestamp();
    transaction.set(userRef, walletWrite, { merge: true });

    const receiptWrite = {
      uid,
      productId,
      kind: product.kind,
      tokensGranted: product.kind === 'consumable' && !receiptSnapshot.exists
        ? product.tokens * verifiedPurchaseQuantity
        : 0,
      tokenHash: receiptId,
      lastVerifiedAt: FieldValue.serverTimestamp(),
    };
    if (!receiptSnapshot.exists) receiptWrite.createdAt = FieldValue.serverTimestamp();
    if (product.kind === 'subscription') {
      receiptWrite.subscriptionState = verifiedSubscription.state;
      receiptWrite.expiryTime = verifiedSubscription.expiryMillis === null
        ? null
        : new Date(verifiedSubscription.expiryMillis).toISOString();
    }
    transaction.set(receiptRef, receiptWrite, { merge: true });
    return current;
  });

  return {
    verified: true,
    ...publicWallet(wallet),
  };
});



const REWARDED_AD_UNIT_TEST_ID = 'ca-app-pub-3940256099942544/5224354917';
const REWARDED_SESSION_TTL_MS = 2 * 60 * 60 * 1000;
const REWARDED_DAILY_LIMIT = 3;

function rewardedAdUnitCode() {
  const configured = process.env.ADMOB_REWARDED_AD_UNIT_ID || REWARDED_AD_UNIT_TEST_ID;
  return configured.split('/').pop();
}

function obfuscatedRewardUserId(uid) {
  return createHash('sha256').update(uid).digest('hex');
}

exports.createRewardedAdSession = onCall(async (request) => {
  const uid = requireUid(request);
  const today = berlinDateKey();
  const sessionId = randomBytes(24).toString('base64url');
  const userId = obfuscatedRewardUserId(uid);
  const userRef = walletDocument(uid);
  const dailyRef = userRef.collection('rewardedAdDays').doc(today);
  const sessionRef = db.collection('rewardedAdSessions').doc(sessionId);

  await db.runTransaction(async (transaction) => {
    const dailySnapshot = await transaction.get(dailyRef);
    const count = dailySnapshot.exists
      ? Math.max(0, Number(dailySnapshot.data().count || 0))
      : 0;
    if (count >= REWARDED_DAILY_LIMIT) {
      throw new HttpsError('resource-exhausted', 'Das tägliche Limit für Werbe-Token ist erreicht.');
    }
    transaction.create(sessionRef, {
      uid,
      userId,
      status: 'pending',
      createdAt: FieldValue.serverTimestamp(),
      expiresAt: Timestamp.fromMillis(Date.now() + REWARDED_SESSION_TTL_MS),
      dateKey: today,
    });
  });

  return { sessionId, userId };
});

exports.getRewardedAdStatus = onCall(async (request) => {
  const uid = requireUid(request);
  const sessionId = request.data && request.data.sessionId;
  if (typeof sessionId !== 'string' || !/^[A-Za-z0-9_-]{20,80}$/.test(sessionId)) {
    throw new HttpsError('invalid-argument', 'Ungültige Werbe-Sitzung.');
  }
  const snapshot = await db.collection('rewardedAdSessions').doc(sessionId).get();
  if (!snapshot.exists || snapshot.data().uid !== uid) {
    throw new HttpsError('not-found', 'Werbe-Sitzung wurde nicht gefunden.');
  }
  const data = snapshot.data();
  return {
    status: data.status || 'pending',
    message: data.status === 'granted'
      ? 'Token gutgeschrieben.'
      : data.status === 'limit_reached'
        ? 'Das tägliche Limit für Werbe-Token ist erreicht.'
        : data.status === 'expired'
          ? 'Die Bestätigung der Werbung ist abgelaufen.'
          : 'Die Werbe-Bestätigung steht noch aus.',
    ...(data.status === 'granted' ? await getWalletData(uid) : {}),
  };
});

async function getWalletData(uid) {
  const userRef = walletDocument(uid);
  const today = berlinDateKey();
  const snapshot = await userRef.get();
  const wallet = snapshot.exists
    ? refreshDailyTokens(normalizeWallet(snapshot.data(), today), today)
    : initialWallet(today);
  return publicWallet(wallet);
}

exports.admobRewardSsv = onRequest({ region: 'europe-west3' }, async (req, res) => {
  if (req.method !== 'GET') {
    res.set('Allow', 'GET');
    return res.status(405).send('Method Not Allowed');
  }

  try {
    const originalUrl = req.originalUrl || req.url || '';
    const question = originalUrl.indexOf('?');
    if (question < 0) return res.status(400).send('Missing query string');
    const rawQuery = originalUrl.slice(question + 1);
    if (!(await verifyAdMobSsv(rawQuery))) {
      return res.status(400).send('Invalid AdMob signature');
    }

    // Only trust query values after the cryptographic signature was verified.
    const params = new URLSearchParams(rawQuery);
    const sessionId = params.get('custom_data');
    const userId = params.get('user_id');
    const transactionId = params.get('transaction_id');
    const adUnit = params.get('ad_unit');
    const rewardAmount = params.get('reward_amount');
    const rewardItem = (params.get('reward_item') || '').toLowerCase();
    const timestamp = Number(params.get('timestamp'));

    if (!sessionId || !userId || !transactionId ||
        !/^[A-Za-z0-9_-]{20,80}$/.test(sessionId) ||
        !/^[A-Fa-f0-9]{16,128}$/.test(transactionId) ||
        userId.length !== 64 ||
        ![rewardedAdUnitCode(), process.env.ADMOB_REWARDED_AD_UNIT_ID || REWARDED_AD_UNIT_TEST_ID]
          .includes(adUnit) ||
        rewardAmount !== '1' || rewardItem !== 'token' ||
        !Number.isFinite(timestamp) ||
        timestamp > Date.now() + 5 * 60 * 1000 ||
        timestamp < Date.now() - 48 * 60 * 60 * 1000) {
      return res.status(400).send('Invalid reward parameters');
    }

    const sessionRef = db.collection('rewardedAdSessions').doc(sessionId);
    const receiptRef = db.collection('admobRewardTransactions').doc(transactionId);
    const sessionSnapshot = await sessionRef.get();
    if (!sessionSnapshot.exists) return res.status(404).send('Unknown session');
    const session = sessionSnapshot.data();

    if (session.userId !== userId) return res.status(403).send('Account mismatch');
    if (session.uid == null) return res.status(400).send('Session has no owner');

    const uid = session.uid;
    const userRef = walletDocument(uid);
    const dailyRef = userRef.collection('rewardedAdDays').doc(berlinDateKey());

    const result = await db.runTransaction(async (transaction) => {
      const [currentSessionSnapshot, receiptSnapshot, dailySnapshot, userSnapshot] =
        await Promise.all([
          transaction.get(sessionRef),
          transaction.get(receiptRef),
          transaction.get(dailyRef),
          transaction.get(userRef),
        ]);

      if (receiptSnapshot.exists) {
        return { status: 'duplicate' };
      }

      if (!currentSessionSnapshot.exists ||
          currentSessionSnapshot.data().uid !== uid ||
          currentSessionSnapshot.data().userId !== userId) {
        return { status: 'invalid_session' };
      }

      const currentSession = currentSessionSnapshot.data();
      if (currentSession.status !== 'pending') {
        return { status: currentSession.status || 'invalid_session' };
      }
      const expiresAt = currentSession.expiresAt &&
        typeof currentSession.expiresAt.toMillis === 'function'
        ? currentSession.expiresAt.toMillis()
        : 0;
      if (!expiresAt || expiresAt < Date.now()) {
        transaction.update(sessionRef, { status: 'expired', completedAt: FieldValue.serverTimestamp() });
        return { status: 'expired' };
      }

      const dailyCount = dailySnapshot.exists
        ? Math.max(0, Number(dailySnapshot.data().count || 0))
        : 0;
      if (dailyCount >= REWARDED_DAILY_LIMIT) {
        transaction.update(sessionRef, {
          status: 'limit_reached',
          completedAt: FieldValue.serverTimestamp(),
        });
        return { status: 'limit_reached' };
      }

      const today = berlinDateKey();
      const currentWallet = userSnapshot.exists
        ? normalizeWallet(userSnapshot.data(), today)
        : initialWallet(today);
      const wallet = refreshDailyTokens(currentWallet, today);
      wallet.purchasedTokens += 1;

      const walletWrite = { ...wallet, updatedAt: FieldValue.serverTimestamp() };
      if (!userSnapshot.exists) walletWrite.createdAt = FieldValue.serverTimestamp();
      transaction.set(userRef, walletWrite, { merge: true });
      transaction.set(dailyRef, {
        count: dailyCount + 1,
        dateKey: today,
        updatedAt: FieldValue.serverTimestamp(),
      }, { merge: true });
      transaction.create(receiptRef, {
        uid,
        sessionId,
        transactionId,
        rewardAmount: 1,
        rewardItem: 'token',
        adUnit,
        createdAt: FieldValue.serverTimestamp(),
      });
      transaction.update(sessionRef, {
        status: 'granted',
        transactionId,
        completedAt: FieldValue.serverTimestamp(),
      });
      return { status: 'granted' };
    });

    // Valid callbacks are acknowledged even for duplicate/expired/capped sessions.
    return res.status(200).send(result.status === 'granted' ? 'Reward granted' : result.status);
  } catch (error) {
    console.error('AdMob SSV callback failed:', error);
    return res.status(500).send('Temporary server error');
  }
});
