
'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { splitSignedQuery, verifySsvQueryString } = require('../ssv_verifier');

test('verifies an ECDSA-signed AdMob query without changing parameter order', () => {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
  });
  const payload = 'ad_network=123&ad_unit=5224354917&custom_data=abc123&reward_amount=1&reward_item=token&timestamp=1795600000000&transaction_id=abcdef&user_id=hash123';
  const signature = crypto.sign('sha256', Buffer.from(payload), privateKey).toString('base64url');
  const query = `${payload}&signature=${signature}&key_id=42`;
  const pem = publicKey.export({ type: 'spki', format: 'pem' });
  assert.equal(verifySsvQueryString(query, { '42': pem }), true);
  assert.deepEqual(splitSignedQuery(query).signedPayload, payload);
});

test('rejects a modified signed parameter', () => {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
  });
  const payload = 'ad_network=123&transaction_id=abcdef';
  const signature = crypto.sign('sha256', Buffer.from(payload), privateKey).toString('base64url');
  const query = `ad_network=123&transaction_id=changed&signature=${signature}&key_id=42`;
  const pem = publicKey.export({ type: 'spki', format: 'pem' });
  assert.equal(verifySsvQueryString(query, { '42': pem }), false);
});

test('rejects missing and malformed signature suffixes', () => {
  assert.throws(() => splitSignedQuery('ad_network=123&key_id=42'));
  assert.throws(() => splitSignedQuery('ad_network=123&signature=abc&key_id=x'));
});
