const test = require('node:test');
const assert = require('node:assert/strict');
const { extractObfuscatedAccountId } = require('../purchase_helpers');

test('reads account identifier from the ProductPurchaseV2 top-level field', () => {
  assert.equal(
    extractObfuscatedAccountId({ obfuscatedExternalAccountId: 'uid-hash' }, 'product'),
    'uid-hash',
  );
});

test('reads account identifier from SubscriptionPurchaseV2.externalAccountIdentifiers', () => {
  assert.equal(
    extractObfuscatedAccountId({
      externalAccountIdentifiers: { obfuscatedExternalAccountId: 'uid-hash' },
    }, 'subscription'),
    'uid-hash',
  );
});

test('missing account identifiers fail closed', () => {
  assert.equal(extractObfuscatedAccountId({}, 'product'), null);
  assert.equal(extractObfuscatedAccountId({}, 'subscription'), null);
  assert.equal(extractObfuscatedAccountId(null, 'subscription'), null);
});
