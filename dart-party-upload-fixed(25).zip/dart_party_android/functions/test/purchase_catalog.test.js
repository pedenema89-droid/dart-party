const test = require('node:test');
const assert = require('node:assert/strict');
const { PLAY_PRODUCTS } = require('../purchase_catalog');

test('all seven agreed Google Play product IDs are present', () => {
  assert.deepEqual(Object.keys(PLAY_PRODUCTS).sort(), [
    'dart_party_ad_free_lifetime',
    'dart_party_lifetime_unlimited',
    'dart_party_monthly_unlimited',
    'dart_party_token_1',
    'dart_party_token_10',
    'dart_party_token_100',
    'dart_party_token_30',
  ]);
});

test('token products grant exactly the agreed number of purchased tokens', () => {
  assert.equal(PLAY_PRODUCTS.dart_party_token_1.tokens, 1);
  assert.equal(PLAY_PRODUCTS.dart_party_token_10.tokens, 10);
  assert.equal(PLAY_PRODUCTS.dart_party_token_30.tokens, 30);
  assert.equal(PLAY_PRODUCTS.dart_party_token_100.tokens, 100);
  for (const id of Object.keys(PLAY_PRODUCTS).filter((id) => id.startsWith('dart_party_token_'))) {
    assert.equal(PLAY_PRODUCTS[id].kind, 'consumable');
  }
});

test('premium, lifetime and ad-free products have separate entitlements', () => {
  assert.equal(PLAY_PRODUCTS.dart_party_monthly_unlimited.kind, 'subscription');
  assert.equal(PLAY_PRODUCTS.dart_party_lifetime_unlimited.kind, 'lifetime');
  assert.equal(PLAY_PRODUCTS.dart_party_ad_free_lifetime.kind, 'adFree');
});
