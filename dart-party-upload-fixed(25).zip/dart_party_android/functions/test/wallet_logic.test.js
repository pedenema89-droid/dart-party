const test = require('node:test');
const assert = require('node:assert/strict');
const {
  berlinDateKey,
  initialWallet,
  normalizeWallet,
  refreshDailyTokens,
  consumeOneToken,
  isUnlimited,
  publicWallet,
} = require('../wallet_logic');

test('new account receives five welcome and two daily tokens', () => {
  const wallet = initialWallet('2026-11-22');
  assert.equal(wallet.welcomeTokens, 5);
  assert.equal(wallet.dailyTokens, 2);
  assert.equal(wallet.purchasedTokens, 0);
  assert.equal(publicWallet(wallet).totalTokens, 7);
});

test('token consumption order is welcome, daily, then purchased', () => {
  let wallet = { ...initialWallet('2026-11-22'), welcomeTokens: 1, dailyTokens: 1, purchasedTokens: 1 };
  let spend = consumeOneToken(wallet);
  assert.equal(spend.source, 'welcome');
  wallet = spend.wallet;
  spend = consumeOneToken(wallet);
  assert.equal(spend.source, 'daily');
  wallet = spend.wallet;
  spend = consumeOneToken(wallet);
  assert.equal(spend.source, 'purchased');
  assert.equal(spend.wallet.welcomeTokens + spend.wallet.dailyTokens + spend.wallet.purchasedTokens, 0);
  assert.equal(consumeOneToken(spend.wallet).consumed, false);
});

test('daily tokens refresh exactly when Berlin date changes', () => {
  const prior = { ...initialWallet('2026-11-21'), dailyTokens: 0 };
  const sameDay = refreshDailyTokens(prior, '2026-11-21');
  assert.equal(sameDay.dailyTokens, 0);
  const nextDay = refreshDailyTokens(prior, '2026-11-22');
  assert.equal(nextDay.dailyTokens, 2);
  assert.equal(nextDay.dailyDate, '2026-11-22');
});

test('monthly entitlement is time-limited and lifetime entitlement is permanent', () => {
  const now = Date.UTC(2026, 10, 22);
  assert.equal(isUnlimited({ lifetimeUnlimited: false, monthlyUntil: new Date(now + 60000) }, now), true);
  assert.equal(isUnlimited({ lifetimeUnlimited: false, monthlyUntil: new Date(now - 60000) }, now), false);
  assert.equal(isUnlimited({ lifetimeUnlimited: true, monthlyUntil: null }, now), true);
});

test('Berlin date key is a stable ISO date string', () => {
  assert.match(berlinDateKey(new Date('2026-11-21T23:30:00.000Z')), /^2026-11-\d{2}$/);
});

test('wallet normalization rejects negative or invalid counters', () => {
  const wallet = normalizeWallet({ welcomeTokens: -3, dailyTokens: 1.5, purchasedTokens: '99' }, '2026-11-22');
  assert.equal(wallet.welcomeTokens, 5);
  assert.equal(wallet.dailyTokens, 2);
  assert.equal(wallet.purchasedTokens, 0);
});
