// Product IDs must match the Google Play Console exactly.
const PLAY_PRODUCTS = Object.freeze({
  dart_party_token_1: Object.freeze({ kind: 'consumable', tokens: 1 }),
  dart_party_token_10: Object.freeze({ kind: 'consumable', tokens: 10 }),
  dart_party_token_30: Object.freeze({ kind: 'consumable', tokens: 30 }),
  dart_party_token_100: Object.freeze({ kind: 'consumable', tokens: 100 }),
  dart_party_monthly_unlimited: Object.freeze({ kind: 'subscription' }),
  dart_party_lifetime_unlimited: Object.freeze({ kind: 'lifetime' }),
  dart_party_ad_free_lifetime: Object.freeze({ kind: 'adFree' }),
});

module.exports = { PLAY_PRODUCTS };
