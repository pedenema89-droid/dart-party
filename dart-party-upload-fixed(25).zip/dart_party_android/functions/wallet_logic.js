const WELCOME_TOKEN_GRANT = 5;
const DAILY_TOKEN_GRANT = 2;

function berlinDateKey(date = new Date()) {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Europe/Berlin',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

function initialWallet(dateKey) {
  return {
    welcomeTokens: WELCOME_TOKEN_GRANT,
    dailyTokens: DAILY_TOKEN_GRANT,
    purchasedTokens: 0,
    dailyDate: dateKey,
    lifetimeUnlimited: false,
    monthlyUntil: null,
    adFree: false,
  };
}

function normalizeWallet(data, dateKey) {
  const wallet = data ? { ...data } : initialWallet(dateKey);
  wallet.welcomeTokens = nonNegativeInt(wallet.welcomeTokens, WELCOME_TOKEN_GRANT);
  wallet.dailyTokens = nonNegativeInt(wallet.dailyTokens, DAILY_TOKEN_GRANT);
  wallet.purchasedTokens = nonNegativeInt(wallet.purchasedTokens, 0);
  wallet.dailyDate = typeof wallet.dailyDate === 'string' ? wallet.dailyDate : dateKey;
  wallet.lifetimeUnlimited = wallet.lifetimeUnlimited === true;
  wallet.adFree = wallet.adFree === true;
  if (!Object.prototype.hasOwnProperty.call(wallet, 'monthlyUntil')) wallet.monthlyUntil = null;
  return wallet;
}

function nonNegativeInt(value, fallback) {
  return Number.isSafeInteger(value) && value >= 0 ? value : fallback;
}

function refreshDailyTokens(wallet, dateKey) {
  if (wallet.dailyDate !== dateKey) {
    return { ...wallet, dailyTokens: DAILY_TOKEN_GRANT, dailyDate: dateKey };
  }
  return { ...wallet };
}

function isMonthlyActive(wallet, nowMs = Date.now()) {
  const until = wallet.monthlyUntil;
  if (!until) return false;
  const expiry = typeof until.toMillis === 'function'
    ? until.toMillis()
    : new Date(until).getTime();
  return Number.isFinite(expiry) && expiry > nowMs;
}

function isUnlimited(wallet, nowMs = Date.now()) {
  return wallet.lifetimeUnlimited === true || isMonthlyActive(wallet, nowMs);
}

function consumeOneToken(wallet) {
  const next = { ...wallet };
  if (next.welcomeTokens > 0) {
    next.welcomeTokens -= 1;
    return { wallet: next, consumed: true, source: 'welcome' };
  }
  if (next.dailyTokens > 0) {
    next.dailyTokens -= 1;
    return { wallet: next, consumed: true, source: 'daily' };
  }
  if (next.purchasedTokens > 0) {
    next.purchasedTokens -= 1;
    return { wallet: next, consumed: true, source: 'purchased' };
  }
  return { wallet: next, consumed: false, source: null };
}

function publicWallet(wallet, nowMs = Date.now()) {
  const monthlyUnlimited = isMonthlyActive(wallet, nowMs);
  return {
    welcomeTokens: wallet.welcomeTokens,
    dailyTokens: wallet.dailyTokens,
    purchasedTokens: wallet.purchasedTokens,
    totalTokens: wallet.welcomeTokens + wallet.dailyTokens + wallet.purchasedTokens,
    lifetimeUnlimited: wallet.lifetimeUnlimited === true,
    monthlyUnlimited,
    unlimitedGames: wallet.lifetimeUnlimited === true || monthlyUnlimited,
    adFree: wallet.adFree === true,
  };
}

module.exports = {
  WELCOME_TOKEN_GRANT,
  DAILY_TOKEN_GRANT,
  berlinDateKey,
  initialWallet,
  normalizeWallet,
  refreshDailyTokens,
  isMonthlyActive,
  isUnlimited,
  consumeOneToken,
  publicWallet,
};
