// Google Play uses different response shapes for one-time products and subscriptions.
function extractObfuscatedAccountId(purchase, kind) {
  if (!purchase || typeof purchase !== 'object') return null;
  if (kind === 'subscription') {
    return purchase.externalAccountIdentifiers?.obfuscatedExternalAccountId || null;
  }
  return purchase.obfuscatedExternalAccountId || null;
}

module.exports = { extractObfuscatedAccountId };
