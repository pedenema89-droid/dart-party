# Backend-Stand

- Google Login: erfolgreich auf dem Gerät getestet.
- Firestore: Datenbank erstellt; Client-Regeln bleiben geschlossen.
- `getWallet` und `startMatch`: deployt und getestet.
- Wallet: 5 einmalige Starttoken, 2 tägliche Token (Europe/Berlin), gekaufte Token bleiben serverseitig gespeichert.
- `verifyPlayPurchase`: in Version 1.5.0 im Quellcode vorbereitet. Die Funktion prüft Produkt-ID und Kauf-Token über die Google Play Android Developer API (`productsv2.getproductpurchasev2` bzw. `subscriptionsv2.get`), bindet den Kauf über eine SHA-256-Kennung an das angemeldete Firebase-Konto, ordnet jeden Kauf-Token eindeutig zu und schreibt Token/Berechtigungen idempotent gut.
- `verifyPlayPurchase` ist noch nicht deployt und echte Käufe bleiben bis zur Play-Console-Einrichtung, API-Berechtigung und erfolgreichem Test gesperrt.
- Google-Play-Abo-Status wird bei Kauf und Wiederherstellung abgeglichen. RTDN-Benachrichtigungen sind noch offen.
- AdMob ist noch nicht integriert; Werbung bleibt deaktiviert.
- Bereitstellung: siehe `FIREBASE_BACKEND_SETUP.md` und `MONETARISIERUNG_EINRICHTEN.md`.
