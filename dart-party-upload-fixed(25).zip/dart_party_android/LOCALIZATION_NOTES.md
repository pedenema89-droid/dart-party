# Mehrsprachigkeit

- Unterstützte Sprachen: Deutsch (`de`), Englisch (`en`) und Niederländisch (`nl`).
- Die erste Sprachauswahl erscheint vor der Anmeldung; die Auswahl kann im Konto-Menü geändert werden.
- Für Englisch und Niederländisch werden die benötigten Modelle einmalig über WLAN geladen. Die Übersetzungsmodelle sind laut Google jeweils ungefähr 30 MB groß.
- Die App übersetzt angezeigte UI-Texte, Dialoge, Fehlermeldungen, Kauftexte sowie dynamische Challenge- und Party-Karten aus der deutschen Originalquelle.
- Übersetzungen laufen mit Google ML Kit auf dem Gerät. Beim ersten Wechsel auf Englisch oder Niederländisch werden die benötigten Sprachmodelle geladen. Danach kann die Übersetzung offline ausgeführt werden.
- Übersetzungen werden lokal zwischengespeichert. Spiel- und Kartenlogik bleibt unverändert, da die Originaldaten nicht umgeschrieben werden.
- Die App kennzeichnet die automatisierte Übersetzung mit Google Translate im unteren Bildschirmbereich.

## Release-Hinweis

Die ML-Kit-Übersetzung ist maschinell und laut Google für einfache/allgemeine Texte gedacht. Vor einer öffentlichen Freigabe müssen Spielregeln, Checkout-Erklärungen, Dart-Fachbegriffe und sämtliche Store-Texte auf Englisch und Niederländisch fachlich gegengelesen werden. Der erste Modell-Download benötigt eine Internetverbindung und zusätzlichen Gerätespeicher. Zusätzlich sind Googles aktuelle Vorgaben zur Attribution und zum Übersetzungs-Haftungshinweis umzusetzen; der aktuelle Textvermerk im App-Footer ersetzt die offizielle Grafik noch nicht.
