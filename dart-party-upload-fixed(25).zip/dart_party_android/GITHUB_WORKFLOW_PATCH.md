# GitHub-Workflow: Android-Paketkennung festlegen

Die Google-Anmeldung ist für den Android-Paketnamen `de.dartsparty.app` und den festen Debug-SHA-1 eingerichtet.
Der aktive Workflow im Repository muss nach `Android-Projekt erzeugen` (direkt nach `flutter create --project-name dart_party --platforms android .`) diesen Schritt ausführen, bevor Tests und APK-Build starten:

```yaml
      - name: Android-Paketkennung und Mindestversion setzen
        working-directory: app/dart_party_android
        run: |
          python3 - <<'PY'
          from pathlib import Path
          import re

          path = Path("android/app/build.gradle.kts")
          if not path.exists():
              raise SystemExit("android/app/build.gradle.kts fehlt")
          text = path.read_text(encoding="utf-8")
          text, count = re.subn(
              r'applicationId\s*=\s*"[^"]+"',
              'applicationId = "de.dartsparty.app"',
              text,
              count=1,
          )
          if count != 1:
              raise SystemExit("applicationId konnte nicht eindeutig gesetzt werden")
          text = re.sub(
              r'minSdk\s*=\s*flutter\.minSdkVersion',
              'minSdk = 24',
              text,
              count=1,
          )
          path.write_text(text, encoding="utf-8")
          PY
```

Dieser Schritt ist erforderlich, weil das Root-Workflow-Projekt Android bei jedem Build neu erzeugt. Er stellt sicher, dass die installierte App den bei Firebase registrierten Paketnamen verwendet.

Die Token-Verwaltung ist in dieser Version weiterhin lokal (SharedPreferences). Google-Anmeldung und Online-Prüfung sind eingebaut; die serverseitige Token-Verwaltung mit Firestore/Cloud Functions ist ein eigener nächster Umsetzungsschritt und ist noch nicht aktiv.
