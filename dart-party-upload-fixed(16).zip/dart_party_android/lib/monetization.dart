import 'dart:math';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth.dart';

/// Servergestützte Token- und Kaufverwaltung für Dart Party.
///
/// Das Guthaben wird ausschließlich über Firebase Callable Functions gelesen
/// und verändert. Lokale Werte werden nicht als Berechtigungsnachweis benutzt.
/// Käufe bleiben gesperrt, bis die serverseitige Google-Play-Prüfung ergänzt ist.
class MonetizationService {
  MonetizationService._();

  static final MonetizationService instance = MonetizationService._();

  static const String monthlyProductId = 'dart_party_monthly_unlimited';
  static const String lifetimeProductId = 'dart_party_lifetime_unlimited';
  static const String adFreeProductId = 'dart_party_ad_free_lifetime';
  static const String token1ProductId = 'dart_party_token_1';
  static const String token10ProductId = 'dart_party_token_10';
  static const String token30ProductId = 'dart_party_token_30';
  static const String token100ProductId = 'dart_party_token_100';

  static const int welcomeTokenGrant = 5;
  static const int dailyTokenGrant = 2;
  static const String _pendingMatchIdKey = 'dp_pending_server_match_id';

  final ValueNotifier<int> changes = ValueNotifier<int>(0);
  final FirebaseFunctions _functions =
      FirebaseFunctions.instanceFor(region: 'europe-west3');

  bool _initialized = false;
  bool walletAvailable = false;
  String? walletError;
  bool lifetimeUnlimited = false;
  bool adFree = false;
  bool monthlyUnlimited = false;
  int welcomeTokens = 0;
  int dailyTokens = 0;
  int purchasedTokens = 0;

  /// Echtgeldkäufe bleiben bis zur serverseitigen Play-Überprüfung deaktiviert.
  bool get purchasesEnabled => false;
  bool get unlimitedGames => lifetimeUnlimited || monthlyUnlimited;
  int get totalTokens => welcomeTokens + dailyTokens + purchasedTokens;
  bool get adsEnabled => false;
  bool get privacyOptionsRequired => false;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    try {
      await refreshWalletFromServer();
    } catch (error) {
      walletAvailable = false;
      walletError = 'Token-Guthaben konnte nicht vom Dart-Party-Server geladen werden.';
      debugPrint('Server wallet initialization failed: $error');
      changes.value++;
    }
  }

  Future<void> refreshWalletFromServer() async {
    final result = await _functions
        .httpsCallable('getWallet')
        .call<Map<String, dynamic>>();
    final raw = result.data;
    if (raw is! Map) {
      throw StateError('Ungültige Antwort des Token-Servers.');
    }
    _applyWallet(Map<String, dynamic>.from(raw));
    walletAvailable = true;
    walletError = null;
    changes.value++;
  }

  void _applyWallet(Map<String, dynamic> data) {
    welcomeTokens = _asInt(data['welcomeTokens']);
    dailyTokens = _asInt(data['dailyTokens']);
    purchasedTokens = _asInt(data['purchasedTokens']);
    lifetimeUnlimited = data['lifetimeUnlimited'] == true;
    monthlyUnlimited = data['monthlyUnlimited'] == true;
    adFree = data['adFree'] == true;
  }

  int _asInt(Object? value) => value is num ? value.toInt() : 0;

  Future<String> _pendingMatchId() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_pendingMatchIdKey);
    if (existing != null && existing.isNotEmpty) return existing;

    final random = Random.secure();
    final randomPart = List<String>.generate(
      32,
      (_) => random.nextInt(16).toRadixString(16),
    ).join();
    final id = '${DateTime.now().microsecondsSinceEpoch}-$randomPart';
    await prefs.setString(_pendingMatchIdKey, id);
    return id;
  }

  Future<void> _clearPendingMatchId() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_pendingMatchIdKey);
  }

  Future<int> gamesPlayedToday() async =>
      (dailyTokenGrant - dailyTokens).clamp(0, dailyTokenGrant).toInt();

  /// Werbung ist noch nicht eingebaut. Diese Methoden bleiben absichtlich leer.
  Future<void> showAppOpenAdOnLaunch() async {}
  Future<void> showInterstitialIfAvailable() async {}
  Future<void> showPrivacyOptions() async {}

  Future<bool> authorizeGameStart(BuildContext context) async {
    final onlineSession = await DartPartyAuth.verifyOnlineSession();
    if (!onlineSession) {
      _showMessage(
        context,
        'Zum Starten einer neuen Partie benötigst du eine aktive Internetverbindung und eine Google-Anmeldung.',
      );
      return false;
    }

    // Die gleiche ID wird bei einem unklaren Netzwerk-Timeout erneut verwendet.
    // So wird ein serverseitig bereits abgebuchter Token nicht doppelt belastet.
    final matchId = await _pendingMatchId();
    try {
      var response = await _startMatchOnServer(matchId);
      if (response['allowed'] == true) {
        await _clearPendingMatchId();
        changes.value++;
        return true;
      }

      if (response['reason'] == 'NO_TOKENS') {
        await Navigator.of(context).push<void>(
          MaterialPageRoute<void>(builder: (_) => const MonetizationScreen()),
        );
        if (!context.mounted) return false;
        await refreshWalletFromServer();
        if (totalTokens <= 0 && !unlimitedGames) {
          _showMessage(context, 'Keine Spieltoken mehr vorhanden.');
          return false;
        }

        response = await _startMatchOnServer(matchId);
        if (response['allowed'] == true) {
          await _clearPendingMatchId();
          changes.value++;
          return true;
        }
      }

      _showMessage(context, 'Die Partie konnte nicht freigegeben werden. Bitte versuche es erneut.');
      return false;
    } on FirebaseFunctionsException catch (error) {
      debugPrint('startMatch failed: ${error.code}: ${error.message}');
      _showMessage(
        context,
        'Der Dart-Party-Server ist momentan nicht erreichbar. Bitte versuche es erneut.',
      );
      return false;
    } catch (error) {
      debugPrint('startMatch failed: $error');
      _showMessage(context, 'Die Token-Prüfung ist fehlgeschlagen. Bitte versuche es erneut.');
      return false;
    }
  }

  Future<Map<String, dynamic>> _startMatchOnServer(String matchId) async {
    final result = await _functions.httpsCallable('startMatch').call<Map<String, dynamic>>(
      <String, dynamic>{'matchId': matchId},
    );
    final data = Map<String, dynamic>.from(result.data);
    _applyWallet(data);
    walletAvailable = true;
    walletError = null;
    changes.value++;
    return data;
  }

  void _showMessage(BuildContext context, String message) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> buyProduct(String productId) async {
    throw StateError(
      'Käufe werden erst freigeschaltet, wenn Google-Play-Käufe serverseitig geprüft werden.',
    );
  }

  Future<void> restorePurchases() async {
    throw StateError(
      'Die Kaufwiederherstellung wird nach der serverseitigen Google-Play-Prüfung aktiviert.',
    );
  }
}

/// Zeichnet zwei gekreuzte Dartpfeile als wiedererkennbares Token-Symbol.
class DartTokenIcon extends StatelessWidget {
  final double size;
  const DartTokenIcon({super.key, this.size = 25});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: _DartTokenPainter()),
      );
}

class _DartTokenPainter extends CustomPainter {
  static const Color _gold = Color(0xFFE4C477);
  static const Color _highlight = Color(0xFFFFE9A8);
  static const Color _shadow = Color(0xFF765A25);

  void _drawDart(Canvas canvas, Size size, double angle, bool lighter) {
    final w = size.width;
    final h = size.height;
    final main = Paint()
      ..color = lighter ? _highlight : _gold
      ..style = PaintingStyle.fill;
    final outline = Paint()
      ..color = _shadow
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * .035
      ..strokeJoin = StrokeJoin.round;
    final shaft = Paint()
      ..color = lighter ? _highlight : _gold
      ..strokeWidth = size.width * .075
      ..strokeCap = StrokeCap.round;
    final barrel = Paint()
      ..color = lighter ? const Color(0xFFF7DFA0) : const Color(0xFFC99E4B)
      ..strokeWidth = size.width * .14
      ..strokeCap = StrokeCap.round;

    canvas.save();
    canvas.translate(w * .5, h * .5);
    canvas.rotate(angle);

    final flight = Path()
      ..moveTo(-w * .47, 0)
      ..lineTo(-w * .39, -h * .34)
      ..lineTo(-w * .12, -h * .19)
      ..lineTo(-w * .06, 0)
      ..lineTo(-w * .12, h * .19)
      ..lineTo(-w * .39, h * .34)
      ..close();
    canvas.drawPath(flight, outline..style = PaintingStyle.stroke);
    canvas.drawPath(flight, main);
    canvas.drawLine(Offset(-w * .12, 0), Offset(w * .30, 0), shaft);
    canvas.drawLine(Offset(w * .09, -h * .09), Offset(w * .09, h * .09), barrel);
    canvas.drawLine(Offset(w * .16, -h * .08), Offset(w * .16, h * .08), barrel);
    canvas.drawLine(Offset(w * .23, -h * .07), Offset(w * .23, h * .07), barrel);

    final point = Path()
      ..moveTo(w * .29, -h * .055)
      ..lineTo(w * .49, 0)
      ..lineTo(w * .29, h * .055)
      ..close();
    canvas.drawPath(point, main);
    canvas.drawPath(point, outline);
    canvas.restore();
  }

  @override
  void paint(Canvas canvas, Size size) {
    // Leicht versetzte, gekreuzte Pfeile bleiben auch in kleiner Darstellung erkennbar.
    _drawDart(canvas, size, -mathPi / 4, false);
    _drawDart(canvas, size, mathPi / 4, true);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

const double mathPi = 3.141592653589793;

class MonetizationStartupGate extends StatefulWidget {
  final Widget child;
  const MonetizationStartupGate({super.key, required this.child});

  @override
  State<MonetizationStartupGate> createState() => _MonetizationStartupGateState();
}

class _MonetizationStartupGateState extends State<MonetizationStartupGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await MonetizationService.instance.initialize();
      await MonetizationService.instance.showAppOpenAdOnLaunch();
    } catch (error, stackTrace) {
      debugPrint('Monetization startup failed; opening app without ads: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (mounted) setState(() => _ready = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return widget.child;
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports, size: 58, color: Color(0xFFD8B66B)),
            SizedBox(height: 16),
            Text('DART PARTY', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(height: 18),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class MonetizationScreen extends StatefulWidget {
  const MonetizationScreen({super.key});

  @override
  State<MonetizationScreen> createState() => _MonetizationScreenState();
}

class _MonetizationScreenState extends State<MonetizationScreen> {

  @override
  void initState() {
    super.initState();
    MonetizationService.instance.refreshWalletFromServer().catchError((Object error) {
      debugPrint('Wallet refresh on monetization screen failed: $error');
    });
  }

  Widget _tokenOffer({required int amount, required String price, required String description}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Row(mainAxisSize: MainAxisSize.min, children: List.generate(amount >= 30 ? 3 : amount >= 10 ? 2 : 1, (_) => const Padding(padding: EdgeInsets.only(right: 2), child: DartTokenIcon(size: 23)))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$amount ${amount == 1 ? 'Token' : 'Token'}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            Text(description, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(price, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xFFD8B66B))),
            const SizedBox(height: 5),
            const SizedBox(height: 34, child: FilledButton(onPressed: null, child: Text('Folgt'))),
          ]),
        ]),
      ),
    );
  }

  Widget _premiumOffer({required String title, required String price, required String description, required bool active}) {
    return Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))), if (active) const Chip(label: Text('Aktiv'))]),
      Text(description, style: const TextStyle(color: Colors.white70, height: 1.35)),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: Text(price, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFFD8B66B)))), FilledButton(onPressed: null, child: Text(active ? 'Aktiv' : 'Folgt'))]),
    ])));
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: MonetizationService.instance.changes,
        builder: (context, _, __) {
          final service = MonetizationService.instance;
          return Scaffold(
            appBar: AppBar(title: const Text('Token & Premium')),
            body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
              if (!service.walletAvailable) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(service.walletError ?? 'Server-Guthaben wird geladen …', style: const TextStyle(color: Colors.orangeAccent))),
              const Text('DEIN DART-PARTY-GUTHABEN', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [const DartTokenIcon(size: 42), const SizedBox(width: 10), Text('${service.totalTokens}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: Color(0xFFD8B66B))), const SizedBox(width: 8), const Text('Token', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))]),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _balancePart('Start', service.welcomeTokens),
                  _balancePart('Heute', service.dailyTokens),
                  _balancePart('Gekauft', service.purchasedTokens),
                ]),
                const SizedBox(height: 12),
                const Text('5 Starttoken bei Installation · täglich 2 neue Gratis-Token · 1 Token pro gestarteter Partie', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
              ]))),
              const SizedBox(height: 18),
              const Text('TOKEN NACHKAUFEN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              const SizedBox(height: 5),
              _tokenOffer(amount: 1, price: '0,49 €', description: 'Für eine weitere Partie'),
              _tokenOffer(amount: 10, price: '2,99 €', description: '0,30 € pro Partie'),
              _tokenOffer(amount: 30, price: '5,99 €', description: '0,20 € pro Partie'),
              _tokenOffer(amount: 100, price: '12,99 €', description: '0,13 € pro Partie'),
              const SizedBox(height: 18),
              const Text('UNBEGRENZT SPIELEN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              _premiumOffer(title: 'Dart Party Premium', price: '2,99 € / Monat', description: 'Während des aktiven Abos unbegrenzt alle Spielmodi spielen.', active: service.monthlyUnlimited || service.lifetimeUnlimited),
              _premiumOffer(title: 'Dart Party Lifetime', price: '29,99 € einmalig', description: 'Einmal bezahlen und dauerhaft unbegrenzt spielen.', active: service.lifetimeUnlimited),
              const SizedBox(height: 18),
              const Text('WERBEFREI', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              _premiumOffer(title: 'Dart Party werbefrei', price: '7,99 € einmalig', description: 'Entfernt dauerhaft die reguläre Werbung in der App. Freiwillige Werbevideos zum Erhalt zusätzlicher Token bleiben davon ausgenommen.', active: service.adFree),
              OutlinedButton.icon(onPressed: null, icon: const Icon(Icons.restore), label: const Text('Käufe wiederherstellen – folgt')),
              const SizedBox(height: 8),
              const Text('Werbung ist in dieser Version noch nicht aktiviert. Echtgeldkäufe bleiben vorerst gesperrt, bis Google-Play-Käufe serverseitig geprüft und dem Konto gutgeschrieben werden. Die Werbefrei-Option gilt später nicht für freiwillige Werbevideos zum Tokenverdienen.', style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.35)),
            ])),
          );
        },
      );

  Widget _balancePart(String label, int value) => Column(children: [Text('$value', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11))]);
}
