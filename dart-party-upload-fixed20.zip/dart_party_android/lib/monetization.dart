import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth.dart';
import 'localization.dart';

/// Servergestützte Token- und Kaufverwaltung für Dart Party.
/// Echtgeldkäufe werden erst nach erfolgreicher Google-Play-Prüfung gutgeschrieben.
class MonetizationService {
  MonetizationService._();

  static final MonetizationService instance = MonetizationService._();

  static const String monthlyProductId = 'dart_party_monthly_unlimited';
  static const String lifetimeProductId = 'dart_party_lifetime_unlimited';
  static const String adFreeProductId = 'dart_party_ad_free_lifetime';
  static const String token1ProductId = 'dart_party_token_1';
  static const String token10ProductId = 'dart_party_token_10';
  static const String token30ProductId = 'dart_party_token_30';
  static const String token100ProductId = 'dart_party_token_100';

  static const Set<String> _productIds = <String>{
    token1ProductId,
    token10ProductId,
    token30ProductId,
    token100ProductId,
    monthlyProductId,
    lifetimeProductId,
    adFreeProductId,
  };
  static const Set<String> _consumableProductIds = <String>{
    token1ProductId,
    token10ProductId,
    token30ProductId,
    token100ProductId,
  };

  static const int welcomeTokenGrant = 5;
  static const int dailyTokenGrant = 2;
  static const String _pendingMatchIdKey = 'dp_pending_server_match_id';

  final ValueNotifier<int> changes = ValueNotifier<int>(0);
  final FirebaseFunctions _functions =
      FirebaseFunctions.instanceFor(region: 'europe-west3');
  final InAppPurchase _billing = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;

  bool _initialized = false;
  bool walletAvailable = false;
  String? walletError;
  bool lifetimeUnlimited = false;
  bool adFree = false;
  bool monthlyUnlimited = false;
  int welcomeTokens = 0;
  int dailyTokens = 0;
  int purchasedTokens = 0;

  bool storeAvailable = false;
  bool productsLoading = false;
  String? purchaseMessage;
  String? busyProductId;
  final Map<String, ProductDetails> products = <String, ProductDetails>{};

  bool get purchasesEnabled => storeAvailable && products.isNotEmpty;
  bool get unlimitedGames => lifetimeUnlimited || monthlyUnlimited;
  int get totalTokens => welcomeTokens + dailyTokens + purchasedTokens;
  bool get adsEnabled => false; // AdMob folgt als separater Integrationsschritt.
  bool get privacyOptionsRequired => false;

  bool isProductAvailable(String productId) =>
      storeAvailable && products.containsKey(productId);

  String displayPrice(String productId, String fallback) =>
      products[productId]?.price ?? fallback;

  String? get _obfuscatedAccountId {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || uid.isEmpty) return null;
    // Google Play receives only a one-way hash, never the Firebase UID itself.
    return sha256.convert(utf8.encode(uid)).toString();
  }

  String purchaseButtonLabel(String productId) {
    if (busyProductId == productId) return 'Wird verarbeitet …';
    if (products.containsKey(productId)) return 'Kaufen';
    if (productsLoading) return 'Lädt …';
    return 'Nicht verfügbar';
  }

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    _purchaseSubscription ??= _billing.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: _handlePurchaseStreamError,
    );
    unawaited(refreshStoreProducts());
    try {
      await refreshWalletFromServer();
    } catch (error) {
      walletAvailable = false;
      walletError = 'Token-Guthaben konnte nicht vom Dart-Party-Server geladen werden.';
      debugPrint('Server wallet initialization failed: $error');
      changes.value++;
    }
  }

  Future<void> refreshStoreProducts() async {
    if (productsLoading) return;
    productsLoading = true;
    changes.value++;
    try {
      storeAvailable = await _billing.isAvailable();
      if (!storeAvailable) {
        purchaseMessage = 'Google Play ist auf diesem Gerät momentan nicht verfügbar.';
        return;
      }
      final response = await _billing.queryProductDetails(_productIds);
      products
        ..clear()
        ..addEntries(response.productDetails.map(
          (product) => MapEntry<String, ProductDetails>(product.id, product),
        ));
      if (response.error != null) {
        purchaseMessage = 'Die Google-Play-Produkte konnten nicht geladen werden.';
        debugPrint('Play product query failed: ${response.error}');
      } else if (response.notFoundIDs.isNotEmpty) {
        debugPrint('Play products not configured or unavailable: ${response.notFoundIDs.join(', ')}');
      }
      // Restored permanent purchases and the current subscription are rechecked
      // against Google Play on startup; consumed token packs stay in the server wallet.
      unawaited(_restoreSilently());
    } catch (error) {
      storeAvailable = false;
      purchaseMessage = 'Google Play konnte nicht erreicht werden.';
      debugPrint('Play Billing initialization failed: $error');
    } finally {
      productsLoading = false;
      changes.value++;
    }
  }

  Future<void> refreshWalletFromServer() async {
    final result = await _functions
        .httpsCallable('getWallet')
        .call<Map<String, dynamic>>();
    final raw = result.data;
    if (raw is! Map) {
      throw StateError('Ungültige Antwort des Token-Servers.');
    }
    _applyWallet(Map<String, dynamic>.from(raw));
    walletAvailable = true;
    walletError = null;
    changes.value++;
  }

  void _applyWallet(Map<String, dynamic> data) {
    welcomeTokens = _asInt(data['welcomeTokens']);
    dailyTokens = _asInt(data['dailyTokens']);
    purchasedTokens = _asInt(data['purchasedTokens']);
    lifetimeUnlimited = data['lifetimeUnlimited'] == true;
    monthlyUnlimited = data['monthlyUnlimited'] == true;
    adFree = data['adFree'] == true;
  }

  int _asInt(Object? value) => value is num ? value.toInt() : 0;

  Future<String> _pendingMatchId() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_pendingMatchIdKey);
    if (existing != null && existing.isNotEmpty) return existing;

    final random = Random.secure();
    final randomPart = List<String>.generate(
      32,
      (_) => random.nextInt(16).toRadixString(16),
    ).join();
    final id = '${DateTime.now().microsecondsSinceEpoch}-$randomPart';
    await prefs.setString(_pendingMatchIdKey, id);
    return id;
  }

  Future<void> _clearPendingMatchId() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_pendingMatchIdKey);
  }

  Future<int> gamesPlayedToday() async =>
      (dailyTokenGrant - dailyTokens).clamp(0, dailyTokenGrant).toInt();

  /// Werbung bleibt deaktiviert, bis AdMob separat eingerichtet und getestet ist.
  Future<void> showAppOpenAdOnLaunch() async {}
  Future<void> showInterstitialIfAvailable() async {}
  Future<void> showPrivacyOptions() async {}

  Future<bool> authorizeGameStart(BuildContext context) async {
    final onlineSession = await DartPartyAuth.verifyOnlineSession();
    if (!onlineSession) {
      _showMessage(
        context,
        'Zum Starten einer neuen Partie benötigst du eine aktive Internetverbindung und eine Google-Anmeldung.',
      );
      return false;
    }

    final matchId = await _pendingMatchId();
    try {
      var response = await _startMatchOnServer(matchId);
      if (response['allowed'] == true) {
        await _clearPendingMatchId();
        changes.value++;
        return true;
      }

      if (response['reason'] == 'NO_TOKENS') {
        await Navigator.of(context).push<void>(
          MaterialPageRoute<void>(builder: (_) => const MonetizationScreen()),
        );
        if (!context.mounted) return false;
        await refreshWalletFromServer();
        if (totalTokens <= 0 && !unlimitedGames) {
          _showMessage(context, 'Keine Spieltoken mehr vorhanden.');
          return false;
        }

        response = await _startMatchOnServer(matchId);
        if (response['allowed'] == true) {
          await _clearPendingMatchId();
          changes.value++;
          return true;
        }
      }

      _showMessage(context, 'Die Partie konnte nicht freigegeben werden. Bitte versuche es erneut.');
      return false;
    } on FirebaseFunctionsException catch (error) {
      debugPrint('startMatch failed: ${error.code}: ${error.message}');
      _showMessage(
        context,
        'Der Dart-Party-Server ist momentan nicht erreichbar. Bitte versuche es erneut.',
      );
      return false;
    } catch (error) {
      debugPrint('startMatch failed: $error');
      _showMessage(context, 'Die Token-Prüfung ist fehlgeschlagen. Bitte versuche es erneut.');
      return false;
    }
  }

  Future<Map<String, dynamic>> _startMatchOnServer(String matchId) async {
    final result = await _functions.httpsCallable('startMatch').call<Map<String, dynamic>>(
      <String, dynamic>{'matchId': matchId},
    );
    final data = Map<String, dynamic>.from(result.data);
    _applyWallet(data);
    walletAvailable = true;
    walletError = null;
    changes.value++;
    return data;
  }

  Future<void> buyProduct(String productId) async {
    final product = products[productId];
    if (product == null || !storeAvailable) {
      _setPurchaseMessage('Dieses Produkt ist über Google Play momentan nicht verfügbar.');
      return;
    }
    if (busyProductId != null) return;

    final accountId = _obfuscatedAccountId;
    if (accountId == null) {
      _setPurchaseMessage('Bitte melde dich zuerst mit deinem Google-Konto an.');
      return;
    }

    busyProductId = productId;
    purchaseMessage = null;
    changes.value++;
    try {
      final purchaseParam = PurchaseParam(
        productDetails: product,
        applicationUserName: accountId,
      );
      final started = _consumableProductIds.contains(productId)
          ? await _billing.buyConsumable(
              purchaseParam: purchaseParam,
              autoConsume: false,
            )
          : await _billing.buyNonConsumable(purchaseParam: purchaseParam);
      if (!started) {
        busyProductId = null;
        _setPurchaseMessage('Google Play konnte den Kaufvorgang nicht starten.');
      }
    } catch (error) {
      busyProductId = null;
      debugPrint('Purchase flow failed for $productId: $error');
      _setPurchaseMessage('Der Kauf konnte nicht gestartet werden. Bitte versuche es erneut.');
    }
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> updates) async {
    for (final purchase in updates) {
      switch (purchase.status) {
        case PurchaseStatus.pending:
          busyProductId = purchase.productID;
          _setPurchaseMessage('Die Zahlung wird von Google Play verarbeitet.');
          break;
        case PurchaseStatus.error:
          busyProductId = null;
          debugPrint('Google Play purchase error: ${purchase.error}');
          _setPurchaseMessage('Der Kauf wurde nicht abgeschlossen.');
          break;
        case PurchaseStatus.canceled:
          busyProductId = null;
          _setPurchaseMessage('Der Kauf wurde abgebrochen.');
          break;
        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          await _verifyAndFinishPurchase(purchase);
          break;
      }
    }
  }

  Future<void> _verifyAndFinishPurchase(PurchaseDetails purchase) async {
    busyProductId = purchase.productID;
    changes.value++;
    try {
      if (!_productIds.contains(purchase.productID)) {
        throw StateError('Unbekannte Produktkennung.');
      }
      final purchaseToken = purchase.verificationData.serverVerificationData;
      if (purchaseToken.isEmpty) {
        throw StateError('Google Play hat kein Kauf-Token geliefert.');
      }

      final result = await _functions.httpsCallable('verifyPlayPurchase').call<Map<String, dynamic>>(
        <String, dynamic>{
          'productId': purchase.productID,
          'purchaseToken': purchaseToken,
        },
      );
      final data = Map<String, dynamic>.from(result.data);
      _applyWallet(data);
      walletAvailable = true;
      walletError = null;

      try {
        if (_consumableProductIds.contains(purchase.productID)) {
          final androidBilling = _billing
              .getPlatformAddition<InAppPurchaseAndroidPlatformAddition>();
          await androidBilling.consumePurchase(purchase);
        }
        if (purchase.pendingCompletePurchase) {
          await _billing.completePurchase(purchase);
        }
      } catch (error) {
        debugPrint('Purchase verified, but Play completion failed: $error');
        _setPurchaseMessage('Kauf bestätigt. Die Abschlussmeldung an Google Play wird erneut versucht.');
        return;
      }
      _setPurchaseMessage('Kauf erfolgreich bestätigt. Dein Guthaben wurde aktualisiert.');
    } on FirebaseFunctionsException catch (error) {
      debugPrint('Play purchase verification failed: ${error.code}: ${error.message}');
      _setPurchaseMessage('Der Kauf konnte noch nicht sicher bestätigt werden. Bitte nicht erneut kaufen; prüfe deine Internetverbindung und versuche es später erneut.');
      // Nicht abschließen: Google Play liefert den Kauf erneut, bis er bestätigt wurde.
    } catch (error) {
      debugPrint('Play purchase verification failed: $error');
      _setPurchaseMessage('Der Kauf konnte noch nicht sicher bestätigt werden. Bitte nicht erneut kaufen; versuche es später erneut.');
    } finally {
      busyProductId = null;
      changes.value++;
    }
  }

  void _handlePurchaseStreamError(Object error) {
    debugPrint('Google Play purchase stream failed: $error');
    busyProductId = null;
    _setPurchaseMessage('Die Verbindung zu Google Play wurde unterbrochen.');
  }

  Future<void> _restoreSilently() async {
    final accountId = _obfuscatedAccountId;
    if (accountId == null) return;
    try {
      await _billing.restorePurchases(applicationUserName: accountId);
    } catch (error) {
      debugPrint('Automatic Play purchase refresh failed: $error');
    }
  }

  Future<void> restorePurchases() async {
    if (!storeAvailable) {
      _setPurchaseMessage('Google Play ist momentan nicht verfügbar.');
      return;
    }
    final accountId = _obfuscatedAccountId;
    if (accountId == null) {
      _setPurchaseMessage('Bitte melde dich zuerst mit deinem Google-Konto an.');
      return;
    }
    try {
      _setPurchaseMessage('Vorhandene Käufe werden gesucht …');
      await _billing.restorePurchases(applicationUserName: accountId);
    } catch (error) {
      debugPrint('Restore purchases failed: $error');
      _setPurchaseMessage('Käufe konnten nicht wiederhergestellt werden.');
    }
  }

  void _setPurchaseMessage(String message) {
    purchaseMessage = message;
    changes.value++;
  }

  void _showMessage(BuildContext context, String message) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: LocalizedText(message)));
  }
}

/// Zeichnet zwei gekreuzte Dartpfeile als wiedererkennbares Token-Symbol.
class DartTokenIcon extends StatelessWidget {
  final double size;
  const DartTokenIcon({super.key, this.size = 25});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: _DartTokenPainter()),
      );
}

class _DartTokenPainter extends CustomPainter {
  static const Color _gold = Color(0xFFE4C477);
  static const Color _highlight = Color(0xFFFFE9A8);
  static const Color _shadow = Color(0xFF765A25);

  void _drawDart(Canvas canvas, Size size, double angle, bool lighter) {
    final w = size.width;
    final h = size.height;
    final main = Paint()
      ..color = lighter ? _highlight : _gold
      ..style = PaintingStyle.fill;
    final outline = Paint()
      ..color = _shadow
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * .035
      ..strokeJoin = StrokeJoin.round;
    final shaft = Paint()
      ..color = lighter ? _highlight : _gold
      ..strokeWidth = size.width * .075
      ..strokeCap = StrokeCap.round;
    final barrel = Paint()
      ..color = lighter ? const Color(0xFFF7DFA0) : const Color(0xFFC99E4B)
      ..strokeWidth = size.width * .14
      ..strokeCap = StrokeCap.round;

    canvas.save();
    canvas.translate(w * .5, h * .5);
    canvas.rotate(angle);

    final flight = Path()
      ..moveTo(-w * .47, 0)
      ..lineTo(-w * .39, -h * .34)
      ..lineTo(-w * .12, -h * .19)
      ..lineTo(-w * .06, 0)
      ..lineTo(-w * .12, h * .19)
      ..lineTo(-w * .39, h * .34)
      ..close();
    canvas.drawPath(flight, outline..style = PaintingStyle.stroke);
    canvas.drawPath(flight, main);
    canvas.drawLine(Offset(-w * .12, 0), Offset(w * .30, 0), shaft);
    canvas.drawLine(Offset(w * .09, -h * .09), Offset(w * .09, h * .09), barrel);
    canvas.drawLine(Offset(w * .16, -h * .08), Offset(w * .16, h * .08), barrel);
    canvas.drawLine(Offset(w * .23, -h * .07), Offset(w * .23, h * .07), barrel);

    final point = Path()
      ..moveTo(w * .29, -h * .055)
      ..lineTo(w * .49, 0)
      ..lineTo(w * .29, h * .055)
      ..close();
    canvas.drawPath(point, main);
    canvas.drawPath(point, outline);
    canvas.restore();
  }

  @override
  void paint(Canvas canvas, Size size) {
    // Leicht versetzte, gekreuzte Pfeile bleiben auch in kleiner Darstellung erkennbar.
    _drawDart(canvas, size, -mathPi / 4, false);
    _drawDart(canvas, size, mathPi / 4, true);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

const double mathPi = 3.141592653589793;

class MonetizationStartupGate extends StatefulWidget {
  final Widget child;
  const MonetizationStartupGate({super.key, required this.child});

  @override
  State<MonetizationStartupGate> createState() => _MonetizationStartupGateState();
}

class _MonetizationStartupGateState extends State<MonetizationStartupGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await MonetizationService.instance.initialize();
      await MonetizationService.instance.showAppOpenAdOnLaunch();
    } catch (error, stackTrace) {
      debugPrint('Monetization startup failed; opening app without ads: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (mounted) setState(() => _ready = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return widget.child;
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports, size: 58, color: Color(0xFFD8B66B)),
            SizedBox(height: 16),
            LocalizedText('DART PARTY', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(height: 18),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class MonetizationScreen extends StatefulWidget {
  const MonetizationScreen({super.key});

  @override
  State<MonetizationScreen> createState() => _MonetizationScreenState();
}

class _MonetizationScreenState extends State<MonetizationScreen> {

  @override
  void initState() {
    super.initState();
    final service = MonetizationService.instance;
    service.refreshWalletFromServer().catchError((Object error) {
      debugPrint('Wallet refresh on monetization screen failed: $error');
    });
    unawaited(service.refreshStoreProducts());
  }

  Widget _tokenOffer({required String productId, required int amount, required String price, required String description}) {
    final service = MonetizationService.instance;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Row(mainAxisSize: MainAxisSize.min, children: List.generate(amount >= 30 ? 3 : amount >= 10 ? 2 : 1, (_) => const Padding(padding: EdgeInsets.only(right: 2), child: DartTokenIcon(size: 23)))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            LocalizedText('$amount Token', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            LocalizedText(description, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            LocalizedText(service.displayPrice(productId, price), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xFFD8B66B))),
            const SizedBox(height: 5),
            SizedBox(height: 34, child: FilledButton(
              onPressed: service.isProductAvailable(productId) && service.busyProductId == null ? () { service.buyProduct(productId); } : null,
              child: LocalizedText(service.purchaseButtonLabel(productId)),
            )),
          ]),
        ]),
      ),
    );
  }

  Widget _premiumOffer({required String productId, required String title, required String price, required String description, required bool active}) {
    final service = MonetizationService.instance;
    return Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: LocalizedText(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))), if (active) const Chip(label: LocalizedText('Aktiv'))]),
      LocalizedText(description, style: const TextStyle(color: Colors.white70, height: 1.35)),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: LocalizedText(service.displayPrice(productId, price), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFFD8B66B)))),
        FilledButton(
          onPressed: active || !service.isProductAvailable(productId) || service.busyProductId != null ? null : () { service.buyProduct(productId); },
          child: LocalizedText(active ? 'Aktiv' : service.purchaseButtonLabel(productId)),
        ),
      ]),
    ])));
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: MonetizationService.instance.changes,
        builder: (context, _, __) {
          final service = MonetizationService.instance;
          return Scaffold(
            appBar: AppBar(title: const LocalizedText('Token & Premium')),
            body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
              if (!service.walletAvailable) Padding(padding: const EdgeInsets.only(bottom: 12), child: LocalizedText(service.walletError ?? 'Server-Guthaben wird geladen …', style: const TextStyle(color: Colors.orangeAccent))),
              const LocalizedText('DEIN DART-PARTY-GUTHABEN', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [const DartTokenIcon(size: 42), const SizedBox(width: 10), LocalizedText('${service.totalTokens}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: Color(0xFFD8B66B))), const SizedBox(width: 8), const LocalizedText('Token', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))]),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _balancePart('Start', service.welcomeTokens),
                  _balancePart('Heute', service.dailyTokens),
                  _balancePart('Gekauft', service.purchasedTokens),
                ]),
                const SizedBox(height: 12),
                const LocalizedText('5 Starttoken bei Installation · täglich 2 neue Gratis-Token · 1 Token pro gestarteter Partie', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
              ]))),
              const SizedBox(height: 18),
              const LocalizedText('TOKEN NACHKAUFEN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              const SizedBox(height: 5),
              _tokenOffer(productId: MonetizationService.token1ProductId, amount: 1, price: '0,49 €', description: 'Für eine weitere Partie'),
              _tokenOffer(productId: MonetizationService.token10ProductId, amount: 10, price: '2,99 €', description: '0,30 € pro Partie'),
              _tokenOffer(productId: MonetizationService.token30ProductId, amount: 30, price: '5,99 €', description: '0,20 € pro Partie'),
              _tokenOffer(productId: MonetizationService.token100ProductId, amount: 100, price: '12,99 €', description: '0,13 € pro Partie'),
              const SizedBox(height: 18),
              const LocalizedText('UNBEGRENZT SPIELEN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              _premiumOffer(productId: MonetizationService.monthlyProductId, title: 'Dart Party Premium', price: '2,99 € / Monat', description: 'Während des aktiven Abos unbegrenzt alle Spielmodi spielen.', active: service.monthlyUnlimited || service.lifetimeUnlimited),
              _premiumOffer(productId: MonetizationService.lifetimeProductId, title: 'Dart Party Lifetime', price: '29,99 € einmalig', description: 'Einmal bezahlen und dauerhaft unbegrenzt spielen.', active: service.lifetimeUnlimited),
              const SizedBox(height: 18),
              const LocalizedText('WERBEFREI', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              _premiumOffer(productId: MonetizationService.adFreeProductId, title: 'Dart Party werbefrei', price: '7,99 € einmalig', description: 'Entfernt dauerhaft die reguläre Werbung in der App. Freiwillige Werbevideos zum Erhalt zusätzlicher Token bleiben davon ausgenommen.', active: service.adFree),
              OutlinedButton.icon(onPressed: service.storeAvailable ? () { service.restorePurchases(); } : null, icon: const Icon(Icons.restore), label: const LocalizedText('Käufe wiederherstellen')),
              const SizedBox(height: 8),
              if (service.purchaseMessage != null) Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: LocalizedText(service.purchaseMessage!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 12, height: 1.4))),
              const LocalizedText('Käufe werden erst freigeschaltet, sobald die sieben Produkte in Google Play eingerichtet und die serverseitige Kaufprüfung berechtigt ist. Werbung ist in dieser Version noch nicht aktiviert. Die Werbefrei-Option gilt später nicht für freiwillige Werbevideos zum Tokenverdienen.', style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.35)),
            ])),
          );
        },
      );

  Widget _balancePart(String label, int value) => Column(children: [LocalizedText('$value', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), LocalizedText(label, style: const TextStyle(color: Colors.white54, fontSize: 11))]);
}
