# Dart Party – Token- und Premium-Modell (Version 1.4.7)

## In der App vorgesehene Regeln
- Bei der ersten Installation: 5 einmalige Starttoken.
- Pro Kalendertag: 2 kostenlose Token. Nicht verbrauchte Tages-Token werden nicht in den Folgetag übertragen; am neuen Tag stehen wieder 2 bereit.
- Pro gestarteter Partie wird genau 1 Token abgezogen. Mehrere Runden innerhalb derselben Partie verbrauchen keine weiteren Token.
- Verbrauchsreihenfolge: Starttoken, Tages-Token, gekaufte Token.
- Gekaufte Token verfallen nicht.
- Lifetime: 29,99 € einmalig, dauerhaft unbegrenzt spielen.
- Monatsabo: 2,99 € pro Monat, während eines aktiven Abos unbegrenzt spielen. Der Abo-Status wird beim Start über Google Play wiederhergestellt und nicht als dauerhaftes lokales Flag gespeichert.

## Vorgeschlagene Google-Play-Produkte
Die folgenden Produkt-IDs müssen in der Play Console exakt so angelegt werden. Die angezeigten Fallback-Preise sind Vorschläge; nach Produktabfrage zeigt die App den tatsächlichen Play-Preis.

| Produkt-ID | Typ | Preisvorschlag | Inhalt |
|---|---|---:|---:|
| `dart_party_token_1` | Verbrauchsprodukt | 0,49 € | 1 Token |
| `dart_party_token_10` | Verbrauchsprodukt | 2,99 € | 10 Token |
| `dart_party_token_30` | Verbrauchsprodukt | 5,99 € | 30 Token |
| `dart_party_token_100` | Verbrauchsprodukt | 12,99 € | 100 Token |
| `dart_party_monthly_unlimited` | Abo | 2,99 €/Monat | Unbegrenzt während aktiver Laufzeit |
| `dart_party_lifetime_unlimited` | Einmalkauf | 29,99 € | Dauerhaft unbegrenzt |
| `dart_party_ad_free_lifetime` | Einmalkauf | 7,99 € | Reguläre Werbung dauerhaft aus; Rewarded Videos für Token ausgenommen |

## Werbung
Werbung ist in dieser Version absichtlich NICHT implementiert. Geplant sind später: (1) freiwilliges Rewarded Video für +1 Token, Token nur nach bestätigtem vollständigem Reward; (2) eine Werbeeinblendung nach einer Partie; (3) eine Werbeeinblendung beim Start einer Partie. Die genaue Frequenz und die beiden Interstitial-Platzierungen müssen vor der AdMob-Integration noch technisch festgelegt werden, damit nicht direkt vor und nach jeder Partie übermäßig Werbung erscheint.

## Wichtige Release-Voraussetzungen
- Die Produkt-IDs in der Play Console anlegen und aktivieren.
- Für Token-Verbrauchsprodukte eine serverseitige Kaufprüfung und zuverlässige Idempotenz ergänzen, bevor echte Zahlungen live gehen. Lokale Guthabenspeicherung allein ist kein ausreichender Schutz gegen manipulierte oder doppelt verarbeitete Käufe.
- Das Monatsabo muss anhand des tatsächlichen Play-Abo-Status validiert werden.
- Werbung bleibt deaktiviert, bis AdMob eingerichtet und getestet ist.
