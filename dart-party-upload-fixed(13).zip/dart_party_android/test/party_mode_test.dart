import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:dart_party/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Partymodus – Dart-Challenge-Prüfung', () {
    test('Mindestpunktzahl wird anhand aller drei Darts geprüft', () {
      final goal = <String, dynamic>{'type': 'min_score', 'value': 60};
      final darts = [
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
      ];
      expect(evaluatePartyDartGoal(goal, darts), isTrue);
      expect(evaluatePartyDartGoal(goal, darts.take(2).toList()), isFalse);
    });

    test('Spezifischer Treffer prüft Multiplikator und Zahl', () {
      final goal = <String, dynamic>{'type': 'hit_segment', 'multiplier': 'T', 'number': 20};
      expect(evaluatePartyDartGoal(goal, [
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
        const DartThrow('T20', 60, number: 20, multiplier: 'T'),
        const DartThrow('S5', 5, number: 5, multiplier: 'S'),
      ]), isTrue);
      expect(evaluatePartyDartGoal(goal, [
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
        const DartThrow('D20', 40, number: 20, multiplier: 'D'),
        const DartThrow('S5', 5, number: 5, multiplier: 'S'),
      ]), isFalse);
    });

    test('Sequenz-Aufgabe Double vor Triple wird in der richtigen Reihenfolge geprüft', () {
      final goal = <String, dynamic>{'type': 'double_then_triple'};
      expect(evaluatePartyDartGoal(goal, [
        const DartThrow('D20', 40, number: 20, multiplier: 'D'),
        const DartThrow('T19', 57, number: 19, multiplier: 'T'),
        const DartThrow('S1', 1, number: 1, multiplier: 'S'),
      ]), isTrue);
      expect(evaluatePartyDartGoal(goal, [
        const DartThrow('T20', 60, number: 20, multiplier: 'T'),
        const DartThrow('D19', 38, number: 19, multiplier: 'D'),
        const DartThrow('S1', 1, number: 1, multiplier: 'S'),
      ]), isFalse);
    });
  });

  group('Partymodus – Bots', () {
    test('Bot-Spieler speichern Typ und gewählte Stärke', () {
      final bot = PartyPlayer('Computer', isBot: true, botDifficulty: 'Experte');
      expect(bot.isBot, isTrue);
      expect(bot.botDifficulty, 'Experte');
    });

    test('Bot-Konsequenz ist immer A oder B', () {
      for (var seed = 0; seed < 40; seed++) {
        final choice = choosePartyBotConsequence(Random(seed));
        expect(choice == 0 || choice == 1, isTrue);
      }
    });

    test('Höhere Bot-Stärke erhöht die Erfolgswahrscheinlichkeit bei Aktionskarten', () {
      final ultraEasy = partyBotActionSuccessChance('Ultra leicht', 'Gelegenheitsspieler');
      final medium = partyBotActionSuccessChance('Mittel', 'Gelegenheitsspieler');
      final expert = partyBotActionSuccessChance('Experte', 'Gelegenheitsspieler');
      expect(ultraEasy, lessThan(medium));
      expect(medium, lessThan(expert));
    });

    test('Kartenkategorie beeinflusst simulierte Aktionsaufgabe', () {
      final beginner = partyBotActionSuccessChance('Mittel', 'Dartsanfänger');
      final pro = partyBotActionSuccessChance('Mittel', 'Profis');
      expect(beginner, greaterThan(pro));
    });

    test('Bot-Action-Auswertung ist mit gleicher Zufallsquelle reproduzierbar', () {
      final first = evaluatePartyBotAction('Mittel', 'Gelegenheitsspieler', Random(123));
      final second = evaluatePartyBotAction('Mittel', 'Gelegenheitsspieler', Random(123));
      expect(first, second);
    });
  });

  group('Partymodus – Kartenstapel', () {
    test('enthält 100 Karten pro Kategorie und 30 Bonuskarten', () async {
      final deck = await loadPartyDeck({'Dartsanfänger', 'Gelegenheitsspieler', 'Profis'});
      expect(deck.length, 330);
      expect(deck.where((card) => card.isBonus).length, 30);
      expect(deck.where((card) => !card.isBonus && card.taskType == 'darts').length, 300);
      expect(deck.where((card) => !card.isBonus && card.taskType != 'darts'), isEmpty);
      for (final category in partyCategories) {
        expect(deck.where((card) => !card.isBonus && card.category == category).length, 100);
        expect(deck.where((card) => !card.isBonus && card.category == category).every((card) => card.taskType == 'darts'), isTrue);
      }
    });

    test('enthält nur die gewählte Kategorie plus alle Bonuskarten', () async {
      final deck = await loadPartyDeck({'Profis'});
      expect(deck.length, 130);
      expect(deck.where((card) => !card.isBonus).every((card) => card.category == 'Profis' && card.taskType == 'darts'), isTrue);
      expect(deck.where((card) => card.isBonus).length, 30);
    });
    test('Anfänger plus Gelegenheitsspieler ergeben 200 Dartaufgaben und 30 Bonuskarten', () async {
      final deck = await loadPartyDeck({'Dartsanfänger', 'Gelegenheitsspieler'});
      expect(deck.length, 230);
      expect(deck.where((card) => card.isBonus).length, 30);
      expect(deck.where((card) => !card.isBonus && card.taskType == 'darts').length, 200);
      expect(deck.where((card) => !card.isBonus && card.taskType != 'darts'), isEmpty);
      expect(deck.where((card) => !card.isBonus && card.category == 'Dartsanfänger').length, 100);
      expect(deck.where((card) => !card.isBonus && card.category == 'Gelegenheitsspieler').length, 100);
    });

  });
}
