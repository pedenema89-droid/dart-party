import 'package:flutter_test/flutter_test.dart';
import 'package:dart_party/main.dart';

void main() {
  group('Kartenjagd-Treffererkennung', () {
    test('Karte 139 zaehlt Double-Treffer nicht als einfache Zahlenfelder', () {
      const cardText = 'Triff mit drei Darts mindestens einmal ein Doppelfeld und mindestens zweimal ein einfaches Zahlenfeld.';
      final oneSingleAndTwoDoubles = [
        const DartThrow('S 13', 13, number: 13, multiplier: 'S'),
        const DartThrow('D 3', 6, number: 3, multiplier: 'D'),
        const DartThrow('D 8', 16, number: 8, multiplier: 'D'),
      ];
      expect(evaluateCard(cardText, oneSingleAndTwoDoubles), isFalse);

      final twoSinglesAndOneDouble = [
        const DartThrow('S 13', 13, number: 13, multiplier: 'S'),
        const DartThrow('S 8', 8, number: 8, multiplier: 'S'),
        const DartThrow('D 3', 6, number: 3, multiplier: 'D'),
      ];
      expect(evaluateCard(cardText, twoSinglesAndOneDouble), isTrue);
    });
    test('Triple 16 und Double 20 werden mit S15/S20/S19 nicht erfüllt', () {
      final darts = [
        const DartThrow('S 15', 15, number: 15, multiplier: 'S'),
        const DartThrow('S 20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S 19', 19, number: 19, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens einmal Triple 16 und Double 20.', darts), isFalse);
    });

    test('Single 10 und Single 11 werden mit S15/S20/S19 nicht erfüllt', () {
      final darts = [
        const DartThrow('S 15', 15, number: 15, multiplier: 'S'),
        const DartThrow('S 20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S 19', 19, number: 19, multiplier: 'S'),
      ];
      expect(evaluateCard('Triff mit drei Darts mindestens einmal Single 10 und Single 11.', darts), isFalse);
    });

    test('konkrete Triple- und Double-Treffer werden erkannt', () {
      final darts = [
        const DartThrow('T 16', 48, number: 16, multiplier: 'T'),
        const DartThrow('D 20', 40, number: 20, multiplier: 'D'),
        const DartThrow('S 1', 1, number: 1, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens einmal Triple 16 und Double 20.', darts), isTrue);
    });

    test('konkrete Single-Treffer werden erkannt', () {
      final darts = [
        const DartThrow('S 10', 10, number: 10, multiplier: 'S'),
        const DartThrow('S 11', 11, number: 11, multiplier: 'S'),
        const DartThrow('S 1', 1, number: 1, multiplier: 'S'),
      ];
      expect(evaluateCard('Triff mindestens einmal Single 10 und Single 11.', darts), isTrue);
    });

    test('einfache Zielformulierung mindestens einmal die 18 wird erkannt', () {
      final darts = [
        const DartThrow('S 18', 18, number: 18, multiplier: 'S'),
        const DartThrow('S 14', 14, number: 14, multiplier: 'S'),
        const DartThrow('S 15', 15, number: 15, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens einmal die 18.', darts), isTrue);
    });

    test('einfache Zielformulierung ohne Treffer bleibt unerfüllt', () {
      final darts = [
        const DartThrow('S 17', 17, number: 17, multiplier: 'S'),
        const DartThrow('S 14', 14, number: 14, multiplier: 'S'),
        const DartThrow('S 15', 15, number: 15, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens einmal die 18.', darts), isFalse);
    });



    test('Bullseye zaehlt als gerade, nicht als ungerade Zahl', () {
      final darts = [
        const DartThrow('Bullseye', 50, number: 25, multiplier: 'B'),
        const DartThrow('S 8', 8, number: 8, multiplier: 'S'),
        const DartThrow('S 7', 7, number: 7, multiplier: 'S'),
      ];
      // 50 + 8 + 7 = 65: genau ein ungerader Treffer (7) und mindestens ein gerader Treffer.
      expect(evaluateCard('Erreiche mindestens 65 Punkte und triff mindestens zwei ungerade Zahlen.', darts), isFalse);
      expect(evaluateCard('Erreiche mindestens 65 Punkte und triff mindestens eine gerade Zahl.', darts), isTrue);
    });

    test('Outer Bull zaehlt als ungerade Zahl', () {
      final darts = [
        const DartThrow('Outer Bull', 25, number: 25, multiplier: 'B', outerBull: true),
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 4', 4, number: 4, multiplier: 'S'),
      ];
      expect(evaluateCard('Erreiche mindestens 31 Punkte und triff mindestens eine ungerade Zahl.', darts), isTrue);
      expect(evaluateCard('Erreiche mindestens 31 Punkte und triff mindestens eine gerade Zahl.', darts), isTrue);
    });

    test('mindestens zwei gerade Zahlen werden korrekt erkannt', () {
      final darts = [
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 4', 4, number: 4, multiplier: 'S'),
        const DartThrow('S 7', 7, number: 7, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens zwei gerade Zahlen.', darts), isTrue);
    });

    test('eine ungerade Zahl wird korrekt erkannt', () {
      final darts = [
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 4', 4, number: 4, multiplier: 'S'),
        const DartThrow('S 7', 7, number: 7, multiplier: 'S'),
      ];
      expect(evaluateCard('Erreiche mindestens 13 Punkte und triff mindestens eine ungerade Zahl.', darts), isTrue);
    });


    test('mindestens eine gerade Zahl wird erkannt', () {
      final darts = [
        const DartThrow('S 10', 10, number: 10, multiplier: 'S'),
        const DartThrow('S 12', 12, number: 12, multiplier: 'S'),
        const DartThrow('S 8', 8, number: 8, multiplier: 'S'),
      ];
      expect(evaluateCard('Erreiche mit drei Darts mindestens 30 Punkte und triff dabei mindestens eine gerade Zahl.', darts), isTrue);
    });

    test('Bullseye erfuellt eine Anforderung nach zwei geraden Zahlen', () {
      final darts = [
        const DartThrow('Bullseye', 50, number: 25, multiplier: 'B', bull: true),
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 7', 7, number: 7, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens zwei gerade Zahlen.', darts), isTrue);
    });

    test('Outer Bull erfuellt eine Anforderung nach zwei ungeraden Zahlen', () {
      final darts = [
        const DartThrow('Outer Bull', 25, number: 25, multiplier: 'B', outerBull: true),
        const DartThrow('S 3', 3, number: 3, multiplier: 'S'),
        const DartThrow('S 8', 8, number: 8, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens zwei ungerade Zahlen.', darts), isTrue);
    });

    test('mindestens eine ungerade Zahl wird nicht durch gerade Treffer erfüllt', () {
      final darts = [
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 4', 4, number: 4, multiplier: 'S'),
        const DartThrow('S 6', 6, number: 6, multiplier: 'S'),
      ];
      expect(evaluateCard('Erreiche mit drei Darts mindestens 12 Punkte und triff dabei mindestens eine ungerade Zahl.', darts), isFalse);
    });


    test('eine einzelne gerade Zahl ohne weitere Bedingung wird erkannt', () {
      final darts = [
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 7', 7, number: 7, multiplier: 'S'),
        const DartThrow('S 9', 9, number: 9, multiplier: 'S'),
      ];
      expect(evaluateCard('Triff mindestens eine gerade Zahl.', darts), isTrue);
    });

    test('eine einzelne ungerade Zahl ohne weitere Bedingung wird erkannt', () {
      final darts = [
        const DartThrow('S 2', 2, number: 2, multiplier: 'S'),
        const DartThrow('S 7', 7, number: 7, multiplier: 'S'),
        const DartThrow('S 9', 9, number: 9, multiplier: 'S'),
      ];
      expect(evaluateCard('Triff mindestens eine ungerade Zahl.', darts), isTrue);
    });

  });
}
