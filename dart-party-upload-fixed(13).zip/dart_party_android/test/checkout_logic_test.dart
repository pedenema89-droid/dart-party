import 'package:flutter_test/flutter_test.dart';
import 'package:dart_party/main.dart';

void main() {
  group('Checkout-Berechnung', () {
    test('121 Double Out bevorzugt den üblichen Drei-Dart-Weg', () {
      final route = bestCheckout(121, 3, DartsRule.doubleRule);
      expect(route?.map((dart) => dart.label).toList(), ['T20', 'T11', 'D14']);
    });

    test('101 Double Out findet nach einem Single 20 den Zwei-Dart-Checkout', () {
      final player = DartsCounterPlayer('Test', 121);
      final afterSingle = evaluateDartsVisit(player, [
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
      ], DartsRule.straight, DartsRule.doubleRule);
      expect(afterSingle.remaining, 101);
      final route = bestCheckout(afterSingle.remaining, 2, DartsRule.doubleRule);
      expect(route?.map((dart) => dart.label).toList(), ['T17', 'Bullseye']);
    });

    test('170 ist das höchste Drei-Dart-Double-Out-Finish', () {
      final route = bestCheckout(170, 3, DartsRule.doubleRule);
      expect(route?.map((dart) => dart.label).toList(), ['T20', 'T20', 'Bullseye']);
      expect(bestCheckout(171, 3, DartsRule.doubleRule), isNull);
    });

    test('Master Out erlaubt Triple-Finish', () {
      final route = bestCheckout(180, 3, DartsRule.master);
      expect(route?.map((dart) => dart.label).toList(), ['T20', 'T20', 'T20']);
    });

    test('mit nur einem verbleibenden Dart wird keine Zwei-Dart-Lösung angezeigt', () {
      expect(bestCheckout(101, 1, DartsRule.doubleRule), isNull);
    });
  });

  group('In-, Out- und Bust-Regeln', () {
    test('Double In ignoriert vorherige Singles und zählt den Double-Dart', () {
      final player = DartsCounterPlayer('Test', 301)..hasStarted = false;
      final result = evaluateDartsVisit(player, [
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
        const DartThrow('D10', 20, number: 10, multiplier: 'D'),
      ], DartsRule.doubleRule, DartsRule.doubleRule);
      expect(result.started, isTrue);
      expect(result.scored, 20);
      expect(result.remaining, 281);
      expect(result.bust, isFalse);
    });

    test('Single Bull (Outer Bull) ist kein Double-Out-Finish', () {
      expect(_testOut(const DartThrow('Outer Bull', 25, outerBull: true), DartsRule.doubleRule), isFalse);
      expect(_testOut(const DartThrow('Bullseye', 50, bull: true), DartsRule.doubleRule), isTrue);
    });

    test('Ein ungültiger Finish-Versuch setzt die Aufnahme zurück', () {
      final player = DartsCounterPlayer('Test', 40);
      final result = evaluateDartsVisit(player, [
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S20', 20, number: 20, multiplier: 'S'),
      ], DartsRule.straight, DartsRule.doubleRule);
      expect(result.bust, isTrue);
      expect(result.remaining, 40);
    });
  });
}

bool _testOut(DartThrow dart, DartsRule rule) {
  // Testet die Regel indirekt durch einen Finish-Versuch von genau diesem Restscore.
  final player = DartsCounterPlayer('Test', dart.score);
  final result = evaluateDartsVisit(player, [dart], DartsRule.straight, rule);
  return result.won;
}
