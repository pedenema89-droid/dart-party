# Dart Party – Version 1.3.0

Flutter-App für lokale Dart-Spielmodi.

## Spielmodi
- **Kartenjagd:** Karten mit drei Darts erfüllen, werten oder streichen; Menschen und Bots können gemeinsam spielen.
- **Unter / Über 40:** Startgrenzen 40/40, drei Darts pro Runde, Triple 1 zählt 0. Menschliche Spieler und Bots können beliebig kombiniert werden.
- **Dartszähler:** Eigenständiger 301-/501-Zähler mit Straight, Double oder Master In und Out. Bust-Regel, automatisches Rundenende und Checkout-Hilfe sind integriert.

## Checkout-Hilfe
Wenn aktiviert, wird nach jedem Dart der beste aktuell mögliche legale Checkout neu berechnet. Die Suche berücksichtigt die gewählte Out-Regel und die verbleibende Dartanzahl. Es wird ausschließlich ein Vorschlag angezeigt. Die Auswahl priorisiert zunächst einen Checkout mit möglichst wenigen Darts und danach gängige Double-Felder.

## Bots
In Kartenjagd, Unter / Über 40 und Dartszähler lassen sich bis zu acht Spieler festlegen und pro Platz Mensch oder Bot auswählen. Für Bots stehen fünf Schwierigkeitsstufen zur Verfügung. Die Bots werfen ihre Darts automatisch.

## Build
Die Projektdateien liegen im Verzeichnis `dart_party_android`. Der GitHub-Actions-Workflow erzeugt bei Bedarf die Android-Plattformdateien, führt die Tests aus und baut anschließend die APK.


## Neuer Spielmodus: Partymodus (Version 1.2.1)

- 100 Challenge-Karten je Kategorie: Dartsanfänger, Gelegenheitsspieler und Profis.
- Zusätzlich 30 Bonuskarten. Die 30 Bonuskarten werden vor Spielbeginn mit den ausgewählten Challenge-Kategorien in einen gemeinsamen, verdeckten Stapel gemischt.
- Die Kartenart ist erst nach dem Ziehen sichtbar.
- Vor jeder Challenge muss Konsequenz A oder B gewählt werden; die Auswahl ist danach gesperrt.
- Alle Challenge-Karten sind Dartaufgaben und werden nach drei eingegebenen Darts automatisch ausgewertet. Jede Challenge hat zwei Konsequenzen; eine davon muss vor dem Start fest ausgewählt werden.
- Bonuskarten können die Reihenfolge umdrehen oder mischen, einen Spieler aussetzen lassen, einen Extra-Zug geben oder einen Schutzschild verleihen.
- Jede Karte wird im laufenden Spiel nur einmal gezogen. Ein Wasser-Shot ist bei Shot-Optionen immer eine gleichwertige alkoholfreie Alternative.

### Partymodus – Bots
- Jeder Spieler kann als Mensch oder Bot angelegt werden.
- Bot-Stufen: Ultra leicht, Leicht, Mittel, Hart und Experte.
- Bots ziehen verdeckte Karten automatisch und wählen vor jeder Challenge zuerst eine ihrer beiden Konsequenzen.
- Dart-Challenges werden mit drei simulierten Würfen über dieselbe Auswertungslogik geprüft.
- Bonuskarten einschließlich Zielauswahl, Aussetzen, Reihenfolgewechsel, Extrazug und Schutzschild werden automatisch ausgeführt.

## Partymodus – Kartenbestand (Version 1.2.2)

- 100 Dartaufgaben für Dartsanfänger
- 100 Dartaufgaben für Gelegenheitsspieler
- 100 Dartaufgaben für Profis
- 30 Bonuskarten
- Keine eigenständigen Aktionsaufgaben mehr
- Jede Challenge wird anhand der drei eingetragenen Darts automatisch ausgewertet; Konsequenz A oder B bleibt Bestandteil jeder Challenge.


## Monetarisierung (Version 1.3.0)

- Zwei kostenlose Spiele pro lokalem Kalendertag; jedes gestartete Spiel zählt einmal, unabhängig vom Spielmodus.
- 1,49 € monatlich: unbegrenzt spielen, Werbung bleibt aktiv.
- 14,99 € einmalig: dauerhaft unbegrenzt spielen, Werbung bleibt aktiv.
- 6,99 € einmalig: dauerhaft werbefrei, das Limit von zwei Spielen pro Tag bleibt bestehen.
- AdMob: App-Start-Anzeige sowie Vollbildanzeigen vor dem Spielstart und nach dem Spielende.
- Google UMP wird vor Anzeigenanfragen zur Verwaltung der Datenschutzeinwilligung aufgerufen.
- Die App verwendet zunächst offizielle Google-Testanzeigen-IDs. Vor dem Release sind eigene AdMob-App- und Anzeigenblock-IDs einzutragen.
- Die drei Produkt-IDs werden in der Google Play Console angelegt: `dart_party_monthly_unlimited` (Abo), `dart_party_lifetime_unlimited` (einmalig, nicht verbrauchbar) und `dart_party_remove_ads` (einmalig, nicht verbrauchbar).

### Vor der Veröffentlichung noch erforderlich

Die aktuelle IAP-Implementierung verarbeitet die Kaufmeldungen auf dem Gerät und speichert die Freischaltungen lokal. Für einen belastbaren Produktivbetrieb sollten Kauf-Tokens zusätzlich serverseitig über die Google Play Developer API geprüft und Abo-Status/Erstattungen dort verwaltet werden. Das tägliche Freispiel-Limit ist lokal auf dem Gerät gespeichert und deshalb kein manipulationssicheres Kontingent. Außerdem muss im AdMob-Konto die passende Datenschutznachricht unter „Datenschutz und Mitteilungen“ eingerichtet werden.


## Reparatur-Build 1.3.2

Die AdMob-/Google-Mobile-Ads-SDK ist in diesem Reparatur-Build vorübergehend entfernt. In der bisherigen Build-Pipeline fehlte die erforderliche AdMob-App-ID im erzeugten Android-Manifest. Werbung wird erst wieder aktiviert, wenn diese native Konfiguration im tatsächlich ausgeführten GitHub-Workflow gesetzt und getestet ist. Spielmodi, Karten, Anmeldung und In-App-Käufe bleiben im Quellcode enthalten.
