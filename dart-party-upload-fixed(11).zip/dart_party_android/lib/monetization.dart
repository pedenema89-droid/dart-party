import 'dart:async';

import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Token- und Kaufverwaltung für Dart Party.
/// Werbung bleibt bewusst deaktiviert und wird erst später ergänzt.
class MonetizationService {
  MonetizationService._();

  static final MonetizationService instance = MonetizationService._();

  static const String monthlyProductId = 'dart_party_monthly_unlimited';
  static const String lifetimeProductId = 'dart_party_lifetime_unlimited';
  static const String adFreeProductId = 'dart_party_ad_free_lifetime';
  static const String token1ProductId = 'dart_party_token_1';
  static const String token10ProductId = 'dart_party_token_10';
  static const String token30ProductId = 'dart_party_token_30';
  static const String token100ProductId = 'dart_party_token_100';

  static const int welcomeTokenGrant = 5;
  static const int dailyTokenGrant = 2;

  static const String _welcomeTokensKey = 'dp_welcome_tokens_remaining';
  static const String _dailyTokensKey = 'dp_daily_tokens_remaining';
  static const String _dailyDateKey = 'dp_daily_tokens_date';
  static const String _purchasedTokensKey = 'dp_purchased_tokens';
  static const String _lifetimeKey = 'dp_purchase_lifetime_unlimited';
  static const String _adFreeKey = 'dp_purchase_ad_free_lifetime';

  final InAppPurchase _billing = InAppPurchase.instance;
  final ValueNotifier<int> changes = ValueNotifier<int>(0);
  final Map<String, ProductDetails> products = <String, ProductDetails>{};

  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;
  bool _initialized = false;
  bool lifetimeUnlimited = false;
  bool adFree = false;
  bool monthlyUnlimited = false;
  int welcomeTokens = welcomeTokenGrant;
  int dailyTokens = dailyTokenGrant;
  int purchasedTokens = 0;

  bool get unlimitedGames => lifetimeUnlimited || monthlyUnlimited;
  int get totalTokens => welcomeTokens + dailyTokens + purchasedTokens;
  bool get adsEnabled => false;
  bool get privacyOptionsRequired => false;

  static const Set<String> _allProductIds = <String>{
    monthlyProductId,
    lifetimeProductId,
    adFreeProductId,
    token1ProductId,
    token10ProductId,
    token30ProductId,
    token100ProductId,
  };

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    _purchaseSubscription = _billing.purchaseStream.listen(
      _onPurchaseUpdates,
      onError: (Object error) => debugPrint('Purchase stream error: $error'),
    );

    try {
      final prefs = await SharedPreferences.getInstance();
      // Die fünf Starttoken werden nur bei der allerersten Installation vergeben.
      if (!prefs.containsKey(_welcomeTokensKey)) {
        await prefs.setInt(_welcomeTokensKey, welcomeTokenGrant);
      }
      welcomeTokens = prefs.getInt(_welcomeTokensKey) ?? welcomeTokenGrant;
      purchasedTokens = prefs.getInt(_purchasedTokensKey) ?? 0;
      lifetimeUnlimited = prefs.getBool(_lifetimeKey) ?? false;
      adFree = prefs.getBool(_adFreeKey) ?? false;
      // Abo-Status wird bei jedem Start über Google Play wiederhergestellt;
      // kein dauerhaftes lokales Flag, das nach Ablauf weiter freischalten könnte.
      monthlyUnlimited = false;
      await _refreshDailyTokens(prefs);
      changes.value++;
    } catch (error) {
      debugPrint('Could not load saved token state: $error');
    }

    unawaited(_loadProducts());
    try {
      await _restorePurchasesQuietly().timeout(const Duration(seconds: 2));
    } catch (_) {
      // Ein Store-Ausfall darf den App-Start nicht blockieren.
    }
  }

  Future<void> _refreshDailyTokens(SharedPreferences prefs) async {
    final today = _dateKey(DateTime.now());
    if (prefs.getString(_dailyDateKey) != today) {
      dailyTokens = dailyTokenGrant;
      await prefs.setString(_dailyDateKey, today);
      await prefs.setInt(_dailyTokensKey, dailyTokens);
    } else {
      dailyTokens = prefs.getInt(_dailyTokensKey) ?? dailyTokenGrant;
    }
  }

  Future<void> _restorePurchasesQuietly() async {
    try {
      if (await _billing.isAvailable()) await _billing.restorePurchases();
    } catch (error) {
      debugPrint('Automatic purchase restoration failed: $error');
    }
  }

  Future<void> _loadProducts() async {
    try {
      if (!await _billing.isAvailable()) return;
      final response = await _billing.queryProductDetails(_allProductIds);
      products
        ..clear()
        ..addEntries(response.productDetails.map((p) => MapEntry(p.id, p)));
      if (response.error != null) debugPrint('Product query error: ${response.error}');
      changes.value++;
    } catch (error) {
      debugPrint('Could not query Play products: $error');
    }
  }

  String _dateKey(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  Future<int> gamesPlayedToday() async {
    final prefs = await SharedPreferences.getInstance();
    await _refreshDailyTokens(prefs);
    return dailyTokenGrant - dailyTokens;
  }

  /// Werbung ist noch nicht eingebaut. Diese Methoden bleiben bis zur späteren
  /// AdMob-Integration absichtlich leer.
  Future<void> showAppOpenAdOnLaunch() async {}
  Future<void> showInterstitialIfAvailable() async {}
  Future<void> showPrivacyOptions() async {}

  Future<bool> authorizeGameStart(BuildContext context) async {
    if (unlimitedGames) return true;
    await _syncTokenState();
    if (totalTokens <= 0) {
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const MonetizationScreen()),
      );
      if (!context.mounted) return false;
      await _syncTokenState();
      if (totalTokens <= 0 && !unlimitedGames) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Keine Spieltoken mehr vorhanden.')),
        );
        return false;
      }
    }

    if (unlimitedGames) return true;
    await _spendOneToken();
    changes.value++;
    return true;
  }

  Future<void> _syncTokenState() async {
    final prefs = await SharedPreferences.getInstance();
    welcomeTokens = prefs.getInt(_welcomeTokensKey) ?? welcomeTokenGrant;
    purchasedTokens = prefs.getInt(_purchasedTokensKey) ?? 0;
    await _refreshDailyTokens(prefs);
  }

  Future<void> _spendOneToken() async {
    final prefs = await SharedPreferences.getInstance();
    await _syncTokenState();
    // Erst Gratisguthaben verbrauchen, gekaufte Token bleiben möglichst lange erhalten.
    if (welcomeTokens > 0) {
      welcomeTokens--;
      await prefs.setInt(_welcomeTokensKey, welcomeTokens);
    } else if (dailyTokens > 0) {
      dailyTokens--;
      await prefs.setInt(_dailyTokensKey, dailyTokens);
    } else if (purchasedTokens > 0) {
      purchasedTokens--;
      await prefs.setInt(_purchasedTokensKey, purchasedTokens);
    } else {
      throw StateError('Keine Spieltoken vorhanden.');
    }
  }

  Future<void> _onPurchaseUpdates(List<PurchaseDetails> updates) async {
    for (final purchase in updates) {
      if (purchase.status == PurchaseStatus.pending) {
        debugPrint('Purchase pending: ${purchase.productID}');
      } else if (purchase.status == PurchaseStatus.error) {
        debugPrint('Purchase failed: ${purchase.error}');
      } else if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        await _grantProduct(purchase.productID, restored: purchase.status == PurchaseStatus.restored);
      }
      if (purchase.pendingCompletePurchase) {
        try {
          await _billing.completePurchase(purchase);
        } catch (error) {
          debugPrint('Could not complete purchase: $error');
        }
      }
    }
  }

  Future<void> _grantProduct(String productId, {required bool restored}) async {
    final prefs = await SharedPreferences.getInstance();
    if (productId == lifetimeProductId) {
      lifetimeUnlimited = true;
      await prefs.setBool(_lifetimeKey, true);
    } else if (productId == adFreeProductId) {
      adFree = true;
      await prefs.setBool(_adFreeKey, true);
    } else if (productId == monthlyProductId) {
      monthlyUnlimited = true;
    } else if (!restored) {
      // Verbrauchsprodukte werden nicht wiederhergestellt: Ein Restore darf
      // bereits ausgegebene Token nicht ein zweites Mal gutschreiben.
      final amount = switch (productId) {
        token1ProductId => 1,
        token10ProductId => 10,
        token30ProductId => 30,
        token100ProductId => 100,
        _ => 0,
      };
      if (amount > 0) {
        purchasedTokens = (prefs.getInt(_purchasedTokensKey) ?? 0) + amount;
        await prefs.setInt(_purchasedTokensKey, purchasedTokens);
      }
    }
    changes.value++;
  }

  Future<void> buyProduct(String productId) async {
    final product = products[productId];
    if (product == null) {
      throw StateError('Dieses Angebot ist noch nicht im Google Play Store angelegt oder verfügbar.');
    }
    final purchaseParam = PurchaseParam(productDetails: product);
    final isToken = <String>{token1ProductId, token10ProductId, token30ProductId, token100ProductId}.contains(productId);
    final launched = isToken
        ? await _billing.buyConsumable(purchaseParam: purchaseParam, autoConsume: true)
        : await _billing.buyNonConsumable(purchaseParam: purchaseParam);
    if (!launched) throw StateError('Google Play konnte den Kaufvorgang nicht starten.');
  }

  Future<void> restorePurchases() async {
    if (!await _billing.isAvailable()) throw StateError('Google Play ist momentan nicht erreichbar.');
    await _billing.restorePurchases();
  }
}

/// Zeichnet einen kleinen, goldenen Dartpfeil als Token-Symbol.
class DartTokenIcon extends StatelessWidget {
  final double size;
  const DartTokenIcon({super.key, this.size = 25});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: _DartTokenPainter()),
      );
}

class _DartTokenPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final gold = Paint()..color = const Color(0xFFD8B66B)..style = PaintingStyle.fill;
    final dark = Paint()..color = const Color(0xFF171717)..style = PaintingStyle.fill;
    final shaft = Paint()..color = const Color(0xFFF1D48E)..strokeWidth = size.width * .09..strokeCap = StrokeCap.round;
    canvas.save();
    canvas.translate(size.width * .5, size.height * .5);
    canvas.rotate(-mathPi / 4);
    final w = size.width;
    final h = size.height;
    final flight = Path()
      ..moveTo(-w * .40, -h * .10)
      ..lineTo(-w * .48, -h * .42)
      ..lineTo(-w * .12, -h * .28)
      ..lineTo(-w * .02, 0)
      ..lineTo(-w * .12, h * .28)
      ..lineTo(-w * .48, h * .42)
      ..close();
    canvas.drawPath(flight, gold);
    canvas.drawLine(Offset(-w * .13, 0), Offset(w * .34, 0), shaft);
    final tip = Path()
      ..moveTo(w * .34, 0)
      ..lineTo(w * .48, -h * .08)
      ..lineTo(w * .48, h * .08)
      ..close();
    canvas.drawPath(tip, dark);
    canvas.drawPath(tip, gold..style = PaintingStyle.stroke..strokeWidth = 1.2);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

const double mathPi = 3.141592653589793;

class MonetizationStartupGate extends StatefulWidget {
  final Widget child;
  const MonetizationStartupGate({super.key, required this.child});

  @override
  State<MonetizationStartupGate> createState() => _MonetizationStartupGateState();
}

class _MonetizationStartupGateState extends State<MonetizationStartupGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await MonetizationService.instance.initialize();
      await MonetizationService.instance.showAppOpenAdOnLaunch();
    } catch (error, stackTrace) {
      debugPrint('Monetization startup failed; opening app without ads: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (mounted) setState(() => _ready = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return widget.child;
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports, size: 58, color: Color(0xFFD8B66B)),
            SizedBox(height: 16),
            Text('DART PARTY', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(height: 18),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class MonetizationScreen extends StatefulWidget {
  const MonetizationScreen({super.key});

  @override
  State<MonetizationScreen> createState() => _MonetizationScreenState();
}

class _MonetizationScreenState extends State<MonetizationScreen> {
  bool _busy = false;
  String? _message;

  Future<void> _buy(String productId) async {
    setState(() { _busy = true; _message = null; });
    try {
      await MonetizationService.instance.buyProduct(productId);
      if (mounted) setState(() => _message = 'Google Play hat den Kaufvorgang gestartet.');
    } catch (error) {
      if (mounted) setState(() => _message = error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    setState(() { _busy = true; _message = null; });
    try {
      await MonetizationService.instance.restorePurchases();
      if (mounted) setState(() => _message = 'Wiederherstellung wurde bei Google Play angefragt.');
    } catch (error) {
      if (mounted) setState(() => _message = error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _tokenOffer({required String productId, required int amount, required String price, required String description}) {
    final service = MonetizationService.instance;
    final product = service.products[productId];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Row(mainAxisSize: MainAxisSize.min, children: List.generate(amount >= 30 ? 3 : amount >= 10 ? 2 : 1, (_) => const Padding(padding: EdgeInsets.only(right: 2), child: DartTokenIcon(size: 23)))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$amount ${amount == 1 ? 'Token' : 'Token'}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            Text(description, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(product?.price ?? price, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xFFD8B66B))),
            const SizedBox(height: 5),
            SizedBox(height: 34, child: FilledButton(onPressed: _busy || product == null ? null : () => _buy(productId), child: const Text('Kaufen'))),
          ]),
        ]),
      ),
    );
  }

  Widget _premiumOffer({required String productId, required String title, required String price, required String description, required bool active}) {
    final product = MonetizationService.instance.products[productId];
    return Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))), if (active) const Chip(label: Text('Aktiv'))]),
      Text(description, style: const TextStyle(color: Colors.white70, height: 1.35)),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: Text(product?.price ?? price, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFFD8B66B)))), FilledButton(onPressed: _busy || active || product == null ? null : () => _buy(productId), child: Text(active ? 'Aktiv' : product == null ? 'Noch nicht verfügbar' : 'Auswählen'))]),
    ])));
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: MonetizationService.instance.changes,
        builder: (context, _, __) {
          final service = MonetizationService.instance;
          return Scaffold(
            appBar: AppBar(title: const Text('Token & Premium')),
            body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
              const Text('DEIN DART-PARTY-GUTHABEN', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [const DartTokenIcon(size: 42), const SizedBox(width: 10), Text('${service.totalTokens}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: Color(0xFFD8B66B))), const SizedBox(width: 8), const Text('Token', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))]),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _balancePart('Start', service.welcomeTokens),
                  _balancePart('Heute', service.dailyTokens),
                  _balancePart('Gekauft', service.purchasedTokens),
                ]),
                const SizedBox(height: 12),
                const Text('5 Starttoken bei Installation · täglich 2 neue Gratis-Token · 1 Token pro gestarteter Partie', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
              ]))),
              const SizedBox(height: 18),
              const Text('TOKEN NACHKAUFEN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              const SizedBox(height: 5),
              _tokenOffer(productId: MonetizationService.token1ProductId, amount: 1, price: '0,49 €', description: 'Für eine weitere Partie'),
              _tokenOffer(productId: MonetizationService.token10ProductId, amount: 10, price: '2,99 €', description: '0,30 € pro Partie'),
              _tokenOffer(productId: MonetizationService.token30ProductId, amount: 30, price: '5,99 €', description: '0,20 € pro Partie'),
              _tokenOffer(productId: MonetizationService.token100ProductId, amount: 100, price: '12,99 €', description: '0,13 € pro Partie'),
              const SizedBox(height: 18),
              const Text('UNBEGRENZT SPIELEN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              _premiumOffer(productId: MonetizationService.monthlyProductId, title: 'Dart Party Premium', price: '2,99 € / Monat', description: 'Während des aktiven Abos unbegrenzt alle Spielmodi spielen.', active: service.monthlyUnlimited || service.lifetimeUnlimited),
              _premiumOffer(productId: MonetizationService.lifetimeProductId, title: 'Dart Party Lifetime', price: '19,99 € einmalig', description: 'Einmal bezahlen und dauerhaft unbegrenzt spielen.', active: service.lifetimeUnlimited),
              const SizedBox(height: 18),
              const Text('WERBEFREI', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              _premiumOffer(productId: MonetizationService.adFreeProductId, title: 'Dart Party werbefrei', price: '7,99 € einmalig', description: 'Entfernt dauerhaft die reguläre Werbung in der App. Freiwillige Werbevideos zum Erhalt zusätzlicher Token bleiben davon ausgenommen.', active: service.adFree),
              if (_message != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_message!, style: const TextStyle(color: Colors.white70))),
              OutlinedButton.icon(onPressed: _busy ? null : _restore, icon: const Icon(Icons.restore), label: const Text('Käufe wiederherstellen')),
              const SizedBox(height: 8),
              const Text('Werbung ist in dieser Version noch nicht aktiviert. Die Werbefrei-Option gilt später nicht für freiwillige Werbevideos, mit denen zusätzliche Token verdient werden können. Alle Kaufprodukte müssen zuvor in Google Play eingerichtet werden.', style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.35)),
            ])),
          );
        },
      );

  Widget _balancePart(String label, int value) => Column(children: [Text('$value', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11))]);
}
