# Rewarded Ads – sichere Token-Gutschrift

## Firebase Functions bereitstellen

Nach dem Hochladen dieser ZIP in das Repository:

```bash
cd ~/dart-party
git pull
rm -rf /tmp/dp-deploy
mkdir -p /tmp/dp-deploy
unzip -oq "dart-party-upload-fixed(24).zip" -d /tmp/dp-deploy
cd /tmp/dp-deploy/dart_party_android
npm --prefix functions install
npm --prefix functions test
firebase deploy --only functions:createRewardedAdSession,functions:getRewardedAdStatus,functions:admobRewardSsv --project darts-party-2871c
```

Der öffentliche AdMob-Sicherheits-Callback lautet:

`https://europe-west3-darts-party-2871c.cloudfunctions.net/admobRewardSsv`

## AdMob konfigurieren (sobald das AdMob-Konto und eine eigene Rewarded-Ad-Einheit bestehen)

In AdMob unter **Apps → Dart Party → Anzeigenblöcke → Rewarded** die serverseitige Überprüfung (SSV) aktivieren und die Callback-URL oben eintragen. Den Reward exakt als **1 Token** einrichten (Reward item: `token`, amount: `1`) und die Callback-URL mit AdMobs Prüffunktion verifizieren.

Die App setzt `user_id` und `custom_data` vor dem Anzeigen des Videos. Firebase vertraut ausschließlich einem gültig signierten AdMob-Callback, prüft Sitzung, Nutzer, Laufzeit, Reward und eindeutige Transaktions-ID und schreibt den Token innerhalb einer Firestore-Transaktion gut. Maximal drei solcher Tokens werden pro Berliner Kalendertag gutgeschrieben.

Die App verwendet bis zur Einrichtung einer eigenen Anzeigen-Einheit die offizielle Google-Testanzeigen-ID. Diese Testanzeigen-Einheit kann nicht als eigene produktive AdMob-Einheit konfiguriert werden. Für einen echten SSV-End-to-End-Test muss daher später die eigene Rewarded-Ad-Einheit sowohl in der App als auch in der Firebase-Umgebungsvariable `ADMOB_REWARDED_AD_UNIT_ID` eingetragen werden.

**Wichtig:** Die Rewarded-Token-Gutschrift ist absichtlich nicht an den clientseitigen `onUserEarnedReward`-Callback gekoppelt. Ohne aktivierte SSV-Callback-URL gibt es deshalb keine Token-Gutschrift.


## Dart Party AdMob unit configuration (25 Nov 2026)

- AdMob App ID: `ca-app-pub-6695464935305060~6106904340`
- Interstitial ad unit: `ca-app-pub-6695464935305060/8325999880`
- Rewarded ad unit: `ca-app-pub-6695464935305060/2742374405`
- Firebase SSV callback: `https://europe-west3-darts-party-2871c.cloudfunctions.net/admobRewardSsv`

The app source and Android manifest are configured with these IDs. The Functions deployment
receives `ADMOB_REWARDED_AD_UNIT_ID` through the project-scoped dotenv file.


## AdMob "Verify URL" test values (version 1.5.5)

Because the backend requires a real, server-created reward session before crediting a token,
use these values only in AdMob's URL verification dialog:

- User ID: `1111111111111111111111111111111111111111111111111111111111111111`
- Custom data: `admob_url_verify_test_01`

The backend recognizes the `admob_url_verify_test_` prefix only after validating AdMob's
ECDSA signature and all reward parameters. It returns HTTP 200 for this synthetic URL check
without creating a reward or adding a token. Real app sessions use server-generated IDs and
are credited only once after valid SSV verification.
