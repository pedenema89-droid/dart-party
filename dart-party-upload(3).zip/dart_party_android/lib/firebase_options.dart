import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

/// Firebase-Konfiguration für die registrierte Android-App de.dartsparty.app.
class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBHbpCW_dBzJ4DSbZZYfVbAHcSRjah_XtA',
    appId: '1:773111487498:android:7f76b6f57d2ff9377bd3f3',
    messagingSenderId: '773111487498',
    projectId: 'darts-party-2871c',
    storageBucket: 'darts-party-2871c.firebasestorage.app',
  );

  static const String googleServerClientId =
      '773111487498-sqeksb1q47db9lebn83mdflvi3p1njpo.apps.googleusercontent.com';
}
