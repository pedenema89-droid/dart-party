# Dart Party – Version 1.2.0

Flutter-App für lokale Dart-Spielmodi.

## Spielmodi
- **Kartenjagd:** Karten mit drei Darts erfüllen, werten oder streichen; Menschen und Bots können gemeinsam spielen.
- **Unter / Über 40:** Startgrenzen 40/40, drei Darts pro Runde, Triple 1 zählt 0. Menschliche Spieler und Bots können beliebig kombiniert werden.
- **Dartszähler:** Eigenständiger 301-/501-Zähler mit Straight, Double oder Master In und Out. Bust-Regel, automatisches Rundenende und Checkout-Hilfe sind integriert.

## Checkout-Hilfe
Wenn aktiviert, wird nach jedem Dart der beste aktuell mögliche legale Checkout neu berechnet. Die Suche berücksichtigt die gewählte Out-Regel und die verbleibende Dartanzahl. Es wird ausschließlich ein Vorschlag angezeigt. Die Auswahl priorisiert zunächst einen Checkout mit möglichst wenigen Darts und danach gängige Double-Felder.

## Bots
In Kartenjagd, Unter / Über 40 und Dartszähler lassen sich bis zu acht Spieler festlegen und pro Platz Mensch oder Bot auswählen. Für Bots stehen fünf Schwierigkeitsstufen zur Verfügung. Die Bots werfen ihre Darts automatisch.

## Build
Die Projektdateien liegen im Verzeichnis `dart_party_android`. Der GitHub-Actions-Workflow erzeugt bei Bedarf die Android-Plattformdateien, führt die Tests aus und baut anschließend die APK.


## Neuer Spielmodus: Partymodus (Version 1.2.1)

- 100 Challenge-Karten je Kategorie: Dartsanfänger, Gelegenheitsspieler und Profis.
- Zusätzlich 30 Bonuskarten. Die 30 Bonuskarten werden vor Spielbeginn mit den ausgewählten Challenge-Kategorien in einen gemeinsamen, verdeckten Stapel gemischt.
- Die Kartenart ist erst nach dem Ziehen sichtbar.
- Vor jeder Challenge muss Konsequenz A oder B gewählt werden; die Auswahl ist danach gesperrt.
- Dart-Challenges werden nach drei eingegebenen Darts automatisch ausgewertet. Aktions-Challenges werden vom Spieler bestätigt. Jede Challenge hat zwei Konsequenzen; eine davon muss vor dem Start fest ausgewählt werden.
- Bonuskarten können die Reihenfolge umdrehen oder mischen, einen Spieler aussetzen lassen, einen Extra-Zug geben oder einen Schutzschild verleihen.
- Jede Karte wird im laufenden Spiel nur einmal gezogen. Ein Wasser-Shot ist bei Shot-Optionen immer eine gleichwertige alkoholfreie Alternative.

### Partymodus – Bots
- Jeder Spieler kann als Mensch oder Bot angelegt werden.
- Bot-Stufen: Ultra leicht, Leicht, Mittel, Hart und Experte.
- Bots ziehen verdeckte Karten automatisch und wählen vor jeder Challenge zuerst eine ihrer beiden Konsequenzen.
- Dart-Challenges werden mit drei simulierten Würfen über dieselbe Auswertungslogik geprüft.
- Aktions-Challenges werden anhand von Bot-Stärke und Kartenkategorie simuliert.
- Bonuskarten einschließlich Zielauswahl, Aussetzen, Reihenfolgewechsel, Extrazug und Schutzschild werden automatisch ausgeführt.

## Partymodus – Kartenbestand (Version 1.2.2)

- 100 Dartaufgaben für Dartsanfänger
- 100 Dartaufgaben für Gelegenheitsspieler
- 100 Dartaufgaben für Profis
- 30 Bonuskarten
- Keine eigenständigen Aktionsaufgaben mehr
- Jede Challenge wird anhand der drei eingetragenen Darts automatisch ausgewertet; Konsequenz A oder B bleibt Bestandteil jeder Challenge.
