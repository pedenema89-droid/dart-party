# Dart Party – Version 1.1.0

Flutter-App für lokale Dart-Spielmodi.

## Spielmodi
- **Kartenjagd:** Karten mit drei Darts erfüllen, werten oder streichen; Menschen und Bots können gemeinsam spielen.
- **Unter / Über 40:** Startgrenzen 40/40, drei Darts pro Runde, Triple 1 zählt 0. Menschliche Spieler und Bots können beliebig kombiniert werden.
- **Dartszähler:** Eigenständiger 301-/501-Zähler mit Straight, Double oder Master In und Out. Bust-Regel, automatisches Rundenende und Checkout-Hilfe sind integriert.

## Checkout-Hilfe
Wenn aktiviert, wird nach jedem Dart der beste aktuell mögliche legale Checkout neu berechnet. Die Suche berücksichtigt die gewählte Out-Regel und die verbleibende Dartanzahl. Es wird ausschließlich ein Vorschlag angezeigt. Die Auswahl priorisiert zunächst einen Checkout mit möglichst wenigen Darts und danach gängige Double-Felder.

## Bots
In allen drei Spielmodi lassen sich bis zu acht Spieler festlegen und pro Platz Mensch oder Bot auswählen. Für Bots stehen fünf Schwierigkeitsstufen zur Verfügung. Die Bots werfen ihre Darts automatisch.

## Build
Die Projektdateien liegen im Verzeichnis `dart_party_android`. Der GitHub-Actions-Workflow erzeugt bei Bedarf die Android-Plattformdateien, führt die Tests aus und baut anschließend die APK.
