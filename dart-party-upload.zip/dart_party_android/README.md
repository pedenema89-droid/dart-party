# Dart Party – Android

Version 0.2 – lokale Kartenjagd für 2 bis 8 Spieler.

## Änderungen in 0.2
- neue, übersichtliche Dart-Eingabe mit Single / Double / Triple, Zahlen 1–20, Fehlwurf, Outer Bull und Bullseye
- Eingaben können vor der Prüfung geändert werden
- nach drei Darts automatische Prüfung der Karten
- bei Treffern werden ausschließlich erfüllte Karten zur Auswahl angezeigt
- wenn keine Karte erfüllt ist, werden offene Karten zum Streichen angezeigt
- erfüllte und gestrichene Karten bleiben sichtbar; gestrichene Karten sind durchgestrichen
- Kartenbestand aus der Master-CSV bleibt eingebunden

## Hinweis
Die automatische Kartenprüfung nutzt die Formulierungen der Masterkarten und ein konservatives Regelwerk. Bei nicht eindeutig erkannten Sonderformulierungen wird eine Karte nicht automatisch als erfüllt gewertet. Der Code wurde in dieser Umgebung nicht mit Flutter kompiliert; der Android-Build erfolgt über den GitHub-Workflow.
