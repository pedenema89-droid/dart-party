# Dart Party – Android-Prototyp

Dies ist der erste Flutter-Prototyp für Dart Party.

## Enthalten
- Dunkles App-Grunddesign
- Lokale Spielerverwaltung (2 bis 8 Spieler)
- Kartenjagd mit 10 Karten pro Spieler
- Pro Spieler genau 2 Karten aus jeder Kategorie
- Dart-Eingabe für 3 Darts (Miss, Outer Bull, Bullseye, S/D/T 1–20)
- Punktesystem Easy 1, Medium 2, Hard 3, Legende 4, Unsterblich 5
- Ergebnisübersicht

## Wichtiger Prototyp-Hinweis
Die Kartenerfüllung wird in dieser ersten Version vom Spieler manuell bestätigt. Die automatische Prüfung benötigt ein separates, strukturiertes Regelwerk für jede Herausforderung. Dieses wird als nächster Entwicklungsschritt ergänzt.

## Android-Build
Das GitHub-Actions-Workflow unter `.github/workflows/android.yml` baut bei Push auf `main` oder manuellem Start eine Release-APK.

## Lokal bauen
```bash
flutter pub get
flutter build apk --release
```

Die CSV-Kartenliste liegt unter `assets/data/dart_challenges_master.csv`.
