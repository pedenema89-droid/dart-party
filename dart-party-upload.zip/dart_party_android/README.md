# Dart Party – Version 0.3

Android/Flutter-App für lokale Kartenjagd.

## Änderungen in Version 0.3
- Ein einziges Dart-Eingabefeld für alle drei Würfe.
- Die Würfe werden nacheinander eingegeben und direkt in drei kompakten Feldern angezeigt.
- Nach dem dritten Dart startet die Kartenprüfung automatisch.
- Bei Treffern werden ausschließlich erfüllte Karten zur Wertung angeboten.
- Wenn keine Karte erfüllt ist, werden offene Karten zum Streichen angezeigt.
- Gewertete und gestrichene Karten bleiben in der Übersicht sichtbar; gestrichene Karten sind durchgestrichen.
- Kartenansicht kompakter und klarer strukturiert.

## Build
Das Repository-Workflow-Skript entpackt diese ZIP-Datei und erstellt daraus die Android-APK.
