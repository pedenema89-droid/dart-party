import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const DartPartyApp());
}

const categories = ['Easy', 'Medium', 'Hard', 'Legende', 'Unsterblich'];
const categoryPoints = {
  'Easy': 1,
  'Medium': 2,
  'Hard': 3,
  'Legende': 4,
  'Unsterblich': 5,
};

class ChallengeCard {
  final String id;
  final String text;
  final String category;
  const ChallengeCard(this.id, this.text, this.category);
}

class Player {
  final String name;
  final List<ChallengeCard> cards;
  int score = 0;
  int turns = 0;
  Player(this.name, this.cards);
}

class DartThrow {
  final String label;
  final int score;
  const DartThrow(this.label, this.score);

  @override
  bool operator ==(Object other) =>
      other is DartThrow && other.label == label && other.score == score;

  @override
  int get hashCode => Object.hash(label, score);
}

class DartPartyApp extends StatelessWidget {
  const DartPartyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart Party',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF10131B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C5CFF),
          brightness: Brightness.dark,
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF1B2030),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF1B2030),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

Future<List<ChallengeCard>> loadCards() async {
  final raw = await rootBundle.loadString('assets/data/dart_challenges_master.csv');
  final lines = raw.split(RegExp(r'\r?\n')).where((e) => e.trim().isNotEmpty).toList();
  final result = <ChallengeCard>[];
  for (var i = 1; i < lines.length; i++) {
    final fields = _parseCsvLine(lines[i]);
    if (fields.length >= 3) {
      final id = fields[0].trim();
      final text = fields[1].trim();
      final category = fields[2].trim();
      if (categories.contains(category)) result.add(ChallengeCard(id, text, category));
    }
  }
  return result;
}

List<String> _parseCsvLine(String line) {
  final fields = <String>[];
  final buffer = StringBuffer();
  var quoted = false;
  for (var i = 0; i < line.length; i++) {
    final c = line[i];
    if (c == '"') {
      if (quoted && i + 1 < line.length && line[i + 1] == '"') {
        buffer.write('"');
        i++;
      } else {
        quoted = !quoted;
      }
    } else if (c == ',' && !quoted) {
      fields.add(buffer.toString());
      buffer.clear();
    } else {
      buffer.write(c);
    }
  }
  fields.add(buffer.toString());
  return fields;
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              const Icon(Icons.sports, size: 62, color: Color(0xFF9B86FF)),
              const SizedBox(height: 18),
              const Text('DART PARTY', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 2)),
              const SizedBox(height: 8),
              const Text('Dein Dartabend. Deine Regeln.', style: TextStyle(color: Colors.white60, fontSize: 16)),
              const SizedBox(height: 42),
              _ModeTile(
                title: 'Kartenjagd',
                subtitle: '10 Karten · 10 Runden · höchste Punktzahl gewinnt',
                icon: Icons.style,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlayerSetupScreen())),
              ),
              const SizedBox(height: 12),
              const _ModeTile(title: 'Weitere Spielmodi', subtitle: 'Leben, Punkte, Endlos und Unter/Über folgen', icon: Icons.lock_clock, disabled: true),
              const Spacer(),
              const Center(child: Text('TESTVERSION 0.1', style: TextStyle(color: Colors.white38, letterSpacing: 1.5))),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeTile extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  final VoidCallback? onTap;
  final bool disabled;
  const _ModeTile({required this.title, required this.subtitle, required this.icon, this.onTap, this.disabled = false});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(children: [
            Icon(icon, size: 30, color: disabled ? Colors.white24 : const Color(0xFF9B86FF)),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: disabled ? Colors.white38 : Colors.white)),
              const SizedBox(height: 4),
              Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ])),
            const Icon(Icons.chevron_right, color: Colors.white38),
          ]),
        ),
      ),
    );
  }
}

class PlayerSetupScreen extends StatefulWidget {
  const PlayerSetupScreen({super.key});
  @override
  State<PlayerSetupScreen> createState() => _PlayerSetupScreenState();
}

class _PlayerSetupScreenState extends State<PlayerSetupScreen> {
  final names = [TextEditingController(text: 'Spieler 1'), TextEditingController(text: 'Spieler 2')];
  bool loading = false;

  @override
  void dispose() {
    for (final n in names) { n.dispose(); }
    super.dispose();
  }

  void addPlayer() {
    if (names.length >= 8) return;
    setState(() => names.add(TextEditingController(text: 'Spieler ${names.length + 1}')));
  }

  Future<void> start() async {
    final validNames = names.map((e) => e.text.trim()).where((e) => e.isNotEmpty).toList();
    if (validNames.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bitte mindestens zwei Spieler eintragen.')));
      return;
    }
    setState(() => loading = true);
    try {
      final allCards = await loadCards();
      final random = Random();
      final players = <Player>[];
      for (final name in validNames) {
        final selected = <ChallengeCard>[];
        for (final category in categories) {
          final pool = allCards.where((c) => c.category == category).toList()..shuffle(random);
          if (pool.length < 2) throw Exception('Nicht genügend Karten in $category');
          selected.addAll(pool.take(2));
        }
        selected.shuffle(random);
        players.add(Player(name, selected));
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CardHuntScreen(players: players)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler beim Laden der Karten: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Spieler festlegen')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('KARTENJAGD', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('Jeder Spieler erhält separat 2 Karten aus jeder Kategorie.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 20),
        ...List.generate(names.length, (i) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            Expanded(child: TextField(controller: names[i], decoration: InputDecoration(labelText: 'Spieler ${i + 1}'))),
            if (names.length > 2) IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { names.removeAt(i).dispose(); })),
          ]),
        )),
        OutlinedButton.icon(onPressed: names.length >= 8 ? null : addPlayer, icon: const Icon(Icons.add), label: const Text('Spieler hinzufügen')),
        const SizedBox(height: 24),
        FilledButton.icon(onPressed: loading ? null : start, icon: const Icon(Icons.play_arrow), label: Text(loading ? 'Karten werden gemischt …' : 'Spiel starten')),
      ])),
    );
  }
}

class CardHuntScreen extends StatefulWidget {
  final List<Player> players;
  const CardHuntScreen({super.key, required this.players});
  @override
  State<CardHuntScreen> createState() => _CardHuntScreenState();
}

class _CardHuntScreenState extends State<CardHuntScreen> {
  int playerIndex = 0;
  int turnDartIndex = 0;
  final List<DartThrow> darts = [];
  bool awaitingChoice = false;
  int? lastTotal;

  Player get player => widget.players[playerIndex];
  int get turnNumber => player.turns + 1;
  int get totalDarts => darts.fold(0, (sum, d) => sum + d.score);

  void addDart(DartThrow dart) {
    if (darts.length >= 3 || awaitingChoice) return;
    setState(() => darts.add(dart));
    if (darts.length == 3) setState(() => awaitingChoice = true);
  }

  void finishTurn(ChallengeCard card, {required bool completed}) {
    setState(() {
      if (completed) player.score += categoryPoints[card.category] ?? 0;
      player.cards.remove(card);
      player.turns++;
      darts.clear();
      awaitingChoice = false;
      lastTotal = null;
      if (player.turns >= 10) {
        if (playerIndex < widget.players.length - 1) {
          playerIndex++;
        } else {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ResultsScreen(players: widget.players)));
        }
      }
    });
  }

  void discard(ChallengeCard card) => finishTurn(card, completed: false);

  @override
  Widget build(BuildContext context) {
    final remaining = player.cards;
    return Scaffold(
      appBar: AppBar(title: const Text('Kartenjagd'), actions: [
        Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text('${player.score} P', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)))),
      ]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
        Row(children: [
          Expanded(child: Text(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))),
          Text('Runde $turnNumber / 10', style: const TextStyle(color: Colors.white60)),
        ]),
        const SizedBox(height: 6),
        Text('Spieler ${playerIndex + 1} von ${widget.players.length} · ${remaining.length} Karten offen', style: const TextStyle(color: Colors.white54)),
        const SizedBox(height: 18),
        if (!awaitingChoice) ...[
          const Text('DEINE DREI DARTS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 8),
          ...List.generate(3, (i) => _DartPicker(index: i, value: i < darts.length ? darts[i] : null, enabled: i == darts.length, onSelected: addDart)),
          const SizedBox(height: 10),
          Text('Bisher: $totalDarts Punkte', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          const Text('DEINE KARTEN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const Text('Nach dem Wurf wählst du eine erfüllte Karte oder – falls keine passt – eine Karte zum Streichen.', style: TextStyle(color: Colors.white54, fontSize: 12)),
          const SizedBox(height: 8),
          ...remaining.map((c) => _ChallengeTile(card: c, mode: 'waiting')),
        ] else ...[
          const Text('WURF ABGESCHLOSSEN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 8),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Deine drei Darts', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 5),
            Text(darts.map((d) => d.label).join('  ·  '), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('Gesamt: $totalDarts Punkte', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFFB8A9FF))),
          ]))),
          const SizedBox(height: 12),
          const Text('Hast du eine Karte erfüllt? Wähle genau eine Karte aus.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          ...remaining.map((c) => _ChallengeTile(
            card: c,
            mode: 'choose',
            onComplete: () => finishTurn(c, completed: true),
            onDiscard: () => discard(c),
          )),
          const SizedBox(height: 8),
          const Text('Hinweis: In dieser ersten Testversion bestätigst du die erfüllte Karte selbst. Die automatische Prüfung kommt mit dem strukturierten Karten-Regelwerk.', style: TextStyle(color: Colors.amber, fontSize: 12)),
        ],
      ])),
    );
  }
}

class _DartPicker extends StatelessWidget {
  final int index;
  final DartThrow? value;
  final bool enabled;
  final ValueChanged<DartThrow> onSelected;
  const _DartPicker({required this.index, required this.value, required this.enabled, required this.onSelected});

  List<DartThrow> get options {
    final list = <DartThrow>[const DartThrow('Fehlwurf', 0), const DartThrow('Outer Bull', 25), const DartThrow('Bullseye', 50)];
    for (var n = 1; n <= 20; n++) {
      list.add(DartThrow('S$n', n));
      list.add(DartThrow('D$n', n * 2));
      list.add(DartThrow('T$n', n * 3));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5), child: Row(children: [
        CircleAvatar(radius: 15, child: Text('${index + 1}')),
        const SizedBox(width: 12),
        Expanded(child: DropdownButtonHideUnderline(child: DropdownButton<DartThrow>(
          isExpanded: true,
          hint: Text(enabled ? 'Dart ${index + 1} auswählen' : 'Warte auf Dart ${index + 1}'),
          value: value,
          items: options.map((d) => DropdownMenuItem(value: d, child: Text(d.label))).toList(),
          onChanged: enabled ? (d) { if (d != null) onSelected(d); } : null,
        ))),
        if (value != null) Text('${value!.score} P', style: const TextStyle(fontWeight: FontWeight.bold)),
      ])),
    );
  }
}

class _ChallengeTile extends StatelessWidget {
  final ChallengeCard card;
  final String mode;
  final VoidCallback? onComplete;
  final VoidCallback? onDiscard;
  const _ChallengeTile({required this.card, required this.mode, this.onComplete, this.onDiscard});

  Color get color => switch (card.category) {
    'Easy' => Colors.green,
    'Medium' => Colors.blue,
    'Hard' => Colors.orange,
    'Legende' => Colors.deepPurpleAccent,
    _ => Colors.redAccent,
  };

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('KARTE ${card.id}', style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
          const Spacer(),
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: color.withOpacity(.18), borderRadius: BorderRadius.circular(20)), child: Text(card.category, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold))),
          const SizedBox(width: 8),
          Text('+${categoryPoints[card.category]} P', style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 8),
        Text(card.text, style: const TextStyle(fontSize: 14, height: 1.3)),
        if (mode == 'choose') ...[
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: FilledButton(onPressed: onComplete, child: const Text('Erfüllt (+ Punkte)'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: onDiscard, child: const Text('Streichen'))),
          ]),
        ],
      ])),
    );
  }
}

class ResultsScreen extends StatelessWidget {
  final List<Player> players;
  const ResultsScreen({super.key, required this.players});

  @override
  Widget build(BuildContext context) {
    final sorted = [...players]..sort((a, b) => b.score.compareTo(a.score));
    final winner = sorted.first;
    return Scaffold(
      body: SafeArea(child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Spacer(),
        const Icon(Icons.emoji_events, size: 72, color: Color(0xFFFFD166)),
        const SizedBox(height: 12),
        const Center(child: Text('SPIEL BEENDET', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
        const SizedBox(height: 8),
        Center(child: Text('Gewonnen hat ${winner.name}', style: const TextStyle(fontSize: 18, color: Color(0xFFB8A9FF)))),
        const SizedBox(height: 24),
        ...sorted.map((p) => Card(child: ListTile(title: Text(p.name), trailing: Text('${p.score} Punkte', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))))),
        const Spacer(),
        FilledButton(onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false), child: const Text('Zurück zum Hauptmenü')),
      ]))),
    );
  }
}
