import 'dart:math';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const DartPartyApp());
const categories = ['Easy', 'Medium', 'Hard', 'Legende', 'Unsterblich'];
const categoryPoints = {'Easy': 1, 'Medium': 2, 'Hard': 3, 'Legende': 4, 'Unsterblich': 5};
const purple = Color(0xFFB8A9FF);

class ChallengeCard {
  final String id, text, category;
  const ChallengeCard(this.id, this.text, this.category);
}

enum CardState { open, completed, crossed }
class PlayerCard {
  final ChallengeCard card;
  CardState state = CardState.open;
  PlayerCard(this.card);
}
class Player {
  final String name;
  final List<PlayerCard> cards;
  final bool isBot;
  final String botDifficulty;
  int score = 0, turns = 0;
  Player(this.name, List<ChallengeCard> cards, {this.isBot = false, this.botDifficulty = 'Leicht'}) : cards = cards.map(PlayerCard.new).toList();
  List<PlayerCard> get openCards => cards.where((c) => c.state == CardState.open).toList();
}

class DartThrow {
  final String label;
  final int score, number;
  final String multiplier;
  final bool bull, outerBull, miss;
  const DartThrow(this.label, this.score, {this.number = 0, this.multiplier = 'S', this.bull = false, this.outerBull = false, this.miss = false});
  bool get triple => multiplier == 'T' && !bull && !outerBull;
  bool get doubleHit => multiplier == 'D' && !bull && !outerBull;
  bool get single => multiplier == 'S' && number > 0;
  String get fieldKey => bull ? 'BULL' : outerBull ? 'OUTER' : miss ? 'MISS' : '$multiplier$number';
  String get numberKey => (bull || outerBull || miss) ? fieldKey : '$number';
}

class DartPartyApp extends StatelessWidget {
  const DartPartyApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'Dart Party', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF10131B), colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C5CFF), brightness: Brightness.dark),
      cardTheme: CardThemeData(color: const Color(0xFF1B2030), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF1B2030), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
    home: const HomeScreen());
}

Future<List<ChallengeCard>> loadCards() async {
  final raw = await rootBundle.loadString('assets/data/dart_challenges_master.csv');
  final lines = raw.split(RegExp(r'\r?\n')).where((e) => e.trim().isNotEmpty).toList();
  final result = <ChallengeCard>[];
  for (var i = 1; i < lines.length; i++) { final f = _parseCsv(lines[i]); if (f.length >= 3 && categories.contains(f[2].trim())) result.add(ChallengeCard(f[0].trim(), f[1].trim(), f[2].trim())); }
  return result;
}
List<String> _parseCsv(String line) { final out=<String>[]; final b=StringBuffer(); var q=false; for(var i=0;i<line.length;i++){final c=line[i]; if(c=='"'){if(q&&i+1<line.length&&line[i+1]=='"'){b.write('"');i++;}else{q=!q;}}else if(c==','&&!q){out.add(b.toString());b.clear();}else{b.write(c);}} out.add(b.toString()); return out; }

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget _menuCard(BuildContext context, {required IconData icon, required String title, required String subtitle, required Widget screen}) =>
      Card(child: ListTile(
        leading: Icon(icon, color: purple, size: 30),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      ));

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Spacer(),
          const Icon(Icons.sports, size: 62, color: purple),
          const SizedBox(height: 18),
          const Text('DART PARTY', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 2)),
          const SizedBox(height: 8),
          const Text('Dein Dartabend. Deine Regeln.', style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 30),
          _menuCard(context, icon: Icons.style, title: 'Kartenjagd', subtitle: 'Wähle Kartenanzahl und Kategorien · höchste Punktzahl gewinnt', screen: const PlayerSetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.swap_vert_circle, title: 'Unter / Über 40', subtitle: 'Bleib außerhalb der Grenzen – wer dazwischen landet, scheidet aus.', screen: const UnderOverSetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.sports_score, title: 'Dartszähler', subtitle: '301 oder 501 · Straight, Double oder Master In/Out', screen: const DartsCounterSetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.bar_chart, title: 'Spieler-Statistik', subtitle: 'Siege, Spiele und Punkte', screen: const LocalStatsScreen()),
          const Spacer(),
          const Center(child: Text('VERSION 1.1', style: TextStyle(color: Colors.white38, letterSpacing: 1.5))),
        ]),
      ),
    ),
  );
}

class PlayerSetupScreen extends StatefulWidget { const PlayerSetupScreen({super.key}); @override State<PlayerSetupScreen> createState()=>_PlayerSetupScreenState(); }
class _PlayerSetupScreenState extends State<PlayerSetupScreen> {
 final names=[TextEditingController(text:'Spieler 1'),TextEditingController(text:'Spieler 2')]; final List<bool> botPlayers=[false,false]; final List<String> botLevels=['Leicht','Leicht']; bool loading=false; int cardsPerPlayer=10; final Set<String> selectedCategories = Set<String>.from(categories);
 @override void initState(){super.initState();_loadSavedNames();}
 Future<void> _loadSavedNames() async {final prefs=await SharedPreferences.getInstance();final saved=prefs.getStringList('dart_party_player_names');if(saved!=null&&saved.isNotEmpty){for(var i=0;i<saved.length&&i<8;i++){if(i>=names.length){names.add(TextEditingController(text:saved[i]));botPlayers.add(false);botLevels.add('Leicht');}else if(saved[i].trim().isNotEmpty){names[i].text=saved[i];}}if(mounted)setState((){});}}
 @override void dispose(){for(final n in names){n.dispose();}super.dispose();}
 Future<void> start() async {final valid=names.map((e)=>e.text.trim()).toList(); if(valid.length<2 || valid.any((e)=>e.isEmpty)){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Bitte für jeden Spieler einen Namen eintragen.')));return;} setState(()=>loading=true); try{final prefs=await SharedPreferences.getInstance();await prefs.setStringList('dart_party_player_names',valid);if(selectedCategories.isEmpty) throw Exception('Bitte mindestens eine Kategorie auswählen.'); final all=(await loadCards()).where((c)=>selectedCategories.contains(c.category)).toList(); final needed=cardsPerPlayer*valid.length; if(all.length<needed) throw Exception('In den gewählten Kategorien gibt es nicht genug Karten für alle Spieler.'); final rnd=Random(); final pool=List<ChallengeCard>.from(all)..shuffle(rnd); final ps=<Player>[]; var offset=0; for(var i=0;i<valid.length;i++){final chosen=pool.skip(offset).take(cardsPerPlayer).toList(); offset+=cardsPerPlayer; ps.add(Player(valid[i],chosen,isBot:botPlayers[i],botDifficulty:botLevels[i]));} if(!mounted)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>CardHuntScreen(players:ps, cardsPerPlayer:cardsPerPlayer)));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Fehler: $e')));}finally{if(mounted)setState(()=>loading=false);} }
 void showRules(){showDialog(context:context,builder:(context)=>AlertDialog(title:const Text('Spielregeln – Kartenjagd'),content:const SingleChildScrollView(child:Text('1. Jeder Spieler erhält die gewählte Anzahl Karten aus den aktivierten Kategorien.\\n\\n2. Die Spieler sind abwechselnd an der Reihe.\\n\\n3. Pro Zug werden genau drei Darts geworfen. Die App prüft danach die offenen Karten.\\n\\n4. Sind Karten erfüllt, darf genau eine davon gewertet werden. Die Punkte richten sich nach der Kategorie: Easy 1, Medium 2, Hard 3, Legende 4, Unsterblich 5.\\n\\n5. Ist keine Karte erfüllt, muss eine offene Karte gestrichen werden. Gestrichene Karten bleiben sichtbar und zählen null Punkte.\\n\\n6. Danach ist der nächste Spieler an der Reihe. Nach der letzten Karte gewinnt die höchste Punktzahl.'),),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Schließen'))]));}
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const Text('Spieler festlegen')),
  body:SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
   Row(children:[const Expanded(child:Text('KARTENJAGD',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900))),IconButton(tooltip:'Spielregeln',icon:const Icon(Icons.help_outline),onPressed:showRules)]),
   const SizedBox(height:6),const Text('Spieler eintragen und Spielumfang festlegen.',style:TextStyle(color:Colors.white60)),
   const SizedBox(height:10),
   DropdownButtonFormField<int>(value:cardsPerPlayer,decoration:const InputDecoration(labelText:'Karten pro Spieler'),items:[3,4,5,7,10].map((n)=>DropdownMenuItem(value:n,child:Text('$n Karten · $n Züge'))).toList(),onChanged:loading?null:(v)=>setState(()=>cardsPerPlayer=v??10)),
   const SizedBox(height:18),const Text('NUR KARTEN AUS FOLGENDEN KATEGORIEN',style:TextStyle(fontWeight:FontWeight.bold,fontSize:12,letterSpacing:.5)),const SizedBox(height:6),
   Wrap(spacing:7,runSpacing:2,children:categories.map((cat)=>FilterChip(label:Text(cat),selected:selectedCategories.contains(cat),onSelected:loading?null:(on)=>setState(()=>on?selectedCategories.add(cat):selectedCategories.remove(cat)))).toList()),
   const SizedBox(height:18),
   ...List.generate(names.length,(i)=>Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Expanded(child:TextField(controller:names[i],decoration:InputDecoration(labelText:'Spieler ${i+1}'))),if(names.length>2)IconButton(onPressed:()=>setState((){names.removeAt(i).dispose();botPlayers.removeAt(i);botLevels.removeAt(i);}),icon:const Icon(Icons.close))]),
    const SizedBox(height:6),
    Row(children:[Expanded(child:DropdownButtonFormField<bool>(value:botPlayers[i],decoration:const InputDecoration(labelText:'Spielertyp'),items:const [DropdownMenuItem(value:false,child:Text('Mensch')),DropdownMenuItem(value:true,child:Text('Bot'))],onChanged:loading?null:(v)=>setState(()=>botPlayers[i]=v??false))),if(botPlayers[i])const SizedBox(width:8),if(botPlayers[i])Expanded(child:DropdownButtonFormField<String>(value:botLevels[i],decoration:const InputDecoration(labelText:'Bot-Stärke'),items:const ['Ultra leicht','Leicht','Mittel','Hart','Experte'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:loading?null:(v)=>setState(()=>botLevels[i]=v??'Leicht')))])
   ]))),
   OutlinedButton.icon(onPressed:names.length>=8?null:()=>setState((){names.add(TextEditingController(text:'Spieler ${names.length+1}'));botPlayers.add(false);botLevels.add('Leicht');}),icon:const Icon(Icons.add),label:const Text('Spieler hinzufügen')),
   const SizedBox(height:24),FilledButton.icon(onPressed:loading?null:start,icon:const Icon(Icons.play_arrow),label:Text(loading?'Karten werden gemischt …':'Spiel starten'))
  ])));

}

class CardHuntScreen extends StatefulWidget {
  final List<Player> players;
  final int cardsPerPlayer;
  const CardHuntScreen({super.key, required this.players, required this.cardsPerPlayer});
  @override
  State<CardHuntScreen> createState() => _CardHuntScreenState();
}

class _CardHuntScreenState extends State<CardHuntScreen> {
  int playerIndex = 0;
  final List<DartThrow> darts = [];
  bool submitted = false;
  bool botBusy = false;
  @override void initState(){super.initState();WidgetsBinding.instance.addPostFrameCallback((_)=>_startBotIfNeeded());}
  void _startBotIfNeeded(){if(!mounted || botBusy || submitted || !player.isBot)return;botBusy=true;_playBotTurn();}
  Future<void> _playBotTurn() async {
    final bot=player; final expectedIndex=playerIndex;
    await Future.delayed(const Duration(milliseconds:700));
    for(var i=0;i<3;i++){if(!mounted || playerIndex!=expectedIndex || player!=bot)return; final dart=_botThrow(bot.botDifficulty); setState(()=>darts.add(dart)); await Future.delayed(const Duration(milliseconds:450));}
    if(!mounted || playerIndex!=expectedIndex || player!=bot)return;
    setState(()=>submitted=true); await Future.delayed(const Duration(milliseconds:900));
    if(!mounted || playerIndex!=expectedIndex || player!=bot)return;
    final choices=bot.openCards.where((c)=>evaluateCard(c.card.text,darts)).toList()..sort((a,b)=>(categoryPoints[b.card.category]??0).compareTo(categoryPoints[a.card.category]??0));
    final selected=choices.isNotEmpty?choices.first:(bot.openCards.isNotEmpty?bot.openCards[Random().nextInt(bot.openCards.length)]:null);
    botBusy=false; if(selected!=null)finish(selected,completed:choices.isNotEmpty);
  }
  Player get player => widget.players[playerIndex];
  int get total => darts.fold(0, (sum, dart) => sum + dart.score);
  int get turn => player.turns + 1;
  List<PlayerCard> get fulfilled => player.openCards.where((c) => evaluateCard(c.card.text, darts)).toList();

  void addDart(DartThrow dart) {
    if (darts.length >= 3 || submitted) return;
    setState(() {
      darts.add(dart);
      if (darts.length == 3) submitted = true;
    });
  }

  void undoDart() {
    if (darts.isEmpty || submitted) return;
    setState(() => darts.removeLast());
  }

  void resetDarts() {
    setState(() { darts.clear(); submitted = false; });
  }

  void finish(PlayerCard card, {required bool completed}) {
    setState(() {
      card.state = completed ? CardState.completed : CardState.crossed;
      if (completed) player.score += categoryPoints[card.card.category] ?? 0;
      player.turns++;
      darts.clear();
      submitted = false;

      // Nach jeder gewerteten oder gestrichenen Karte ist der nächste Spieler dran.
      // Spieler mit bereits 10 absolvierten Zügen werden übersprungen.
      final nextPlayer = List<int>.generate(widget.players.length, (i) => (playerIndex + i + 1) % widget.players.length)
          .firstWhere(
            (i) => widget.players[i].turns < widget.cardsPerPlayer,
            orElse: () => -1,
          );

      if (nextPlayer == -1) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => ResultsScreen(players: widget.players)),
        );
      } else {
        playerIndex = nextPlayer;
      }
    });
    if(mounted) WidgetsBinding.instance.addPostFrameCallback((_)=>_startBotIfNeeded());
  }

  @override
  Widget build(BuildContext context) {
    final matches = submitted ? fulfilled : <PlayerCard>[];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kartenjagd'),
        actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text('${player.score} P', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))))],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
          children: [
            Row(children: [Expanded(child: Text(player.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))), Text('Runde $turn / ${widget.cardsPerPlayer}', style: const TextStyle(color: Colors.white60))]),
            const SizedBox(height: 4),
            Text('Spieler ${playerIndex + 1} von ${widget.players.length} · ${player.openCards.length} Karten offen', style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 14),
            if (!submitted) ...[
              _DartProgress(darts: darts, total: total, onUndo: undoDart, onReset: resetDarts),
              const SizedBox(height: 10),
              if(!player.isBot) DartEntry(onChanged: addDart, disabled: darts.length >= 3) else const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('Bot wirft automatisch …',style:TextStyle(color:Colors.white60)))),
              const SizedBox(height: 16),
              const Text('DEINE KARTEN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
              const SizedBox(height: 7),
              ...player.cards.map((card) => ChallengeTile(item: card)),
            ] else ...[
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('DEINE DREI WÜRFE', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
                const SizedBox(height: 7),
                Text(darts.map((d) => d.label).join('   ·   '), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 5),
                Text('Gesamt: $total Punkte', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: purple)),
              ]))),
              const SizedBox(height: 12),
              if(player.isBot) ...[
                const Center(child:Padding(padding:EdgeInsets.all(12),child:Text('Bot wertet seinen Zug aus …',style:TextStyle(color:Colors.white60))))
              ] else if (matches.isNotEmpty) ...[
                Text(matches.length == 1 ? 'KARTE ERFÜLLT' : '${matches.length} KARTEN ERFÜLLT – WÄHLE EINE', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.greenAccent)),
                const SizedBox(height: 7),
                ...matches.map((card) => ChallengeTile(item: card, actionLabel: 'Karte werten · +${categoryPoints[card.card.category]} P', action: () => finish(card, completed: true))),
              ] else ...[
                const Text('KEINE KARTE ERFÜLLT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent)),
                const SizedBox(height: 4),
                const Text('Wähle eine Karte zum Streichen. Sie bleibt danach sichtbar.', style: TextStyle(color: Colors.white60)),
                const SizedBox(height: 7),
                ...player.openCards.map((card) => ChallengeTile(item: card, actionLabel: 'Diese Karte streichen', action: () => finish(card, completed: false))),
              ],
              const SizedBox(height: 10),
              if(!player.isBot) OutlinedButton.icon(onPressed: resetDarts, icon: const Icon(Icons.refresh), label: const Text('Würfe neu eingeben')),
            ],
          ],
        ),
      ),
    );
  }
}

class _DartProgress extends StatelessWidget {
  final List<DartThrow> darts;
  final int total;
  final VoidCallback? onUndo, onReset;
  final String completionText;
  const _DartProgress({required this.darts, required this.total, required this.onUndo, required this.onReset, this.completionText = 'Alle drei Würfe eingegeben – Karten werden geprüft.'});

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Expanded(child: Text('BISHER IN DIESEM ZUG', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))), Text('$total PUNKTE', style: const TextStyle(color: purple, fontWeight: FontWeight.w900, fontSize: 20))]),
    const SizedBox(height: 9),
    Row(children: List.generate(3, (i) => Expanded(child: Container(margin: EdgeInsets.only(right: i == 2 ? 0 : 7), padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4), decoration: BoxDecoration(color: i < darts.length ? purple.withOpacity(.20) : const Color(0xFF10131B), borderRadius: BorderRadius.circular(10), border: Border.all(color: i < darts.length ? purple : Colors.white12)), child: Column(children: [Text('DART ${i + 1}', style: const TextStyle(fontSize: 10, color: Colors.white60)), const SizedBox(height: 3), Text(i < darts.length ? darts[i].label : '—', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))]))))),
    const SizedBox(height: 7),
    Row(mainAxisAlignment: MainAxisAlignment.end, children: [TextButton.icon(onPressed: darts.isEmpty ? null : onUndo, icon: const Icon(Icons.undo, size: 17), label: const Text('Letzten zurück')), TextButton(onPressed: darts.isEmpty ? null : onReset, child: const Text('Alle löschen'))]),
    Text(darts.length == 3 ? completionText : 'Bitte Dart ${darts.length + 1} eingeben.', style: const TextStyle(color: Colors.white54, fontSize: 12)),
  ])));
}

class DartEntry extends StatefulWidget {
  final ValueChanged<DartThrow> onChanged;
  final bool disabled;
  const DartEntry({super.key, required this.onChanged, this.disabled = false});
  @override
  State<DartEntry> createState() => _DartEntryState();
}

class _DartEntryState extends State<DartEntry> {
  String multiplier = 'S';

  Widget specialButton(String label, DartThrow dart) => Expanded(child: OutlinedButton(onPressed: widget.disabled ? null : () => widget.onChanged(dart), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 12)), child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))));

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(11), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Ein Eingabefeld für alle drei Darts', style: TextStyle(color: Colors.white60, fontSize: 12)),
    const SizedBox(height: 8),
    Row(children: [for (final item in const [('S', 'Single'), ('D', 'Double'), ('T', 'Triple')]) Expanded(child: Padding(padding: const EdgeInsets.only(right: 5), child: ChoiceChip(label: Text(item.$2), selected: multiplier == item.$1, onSelected: widget.disabled ? null : (_) => setState(() => multiplier = item.$1))))]),
    const SizedBox(height: 7),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 5, mainAxisSpacing: 5, crossAxisSpacing: 5, childAspectRatio: 1.85, children: List.generate(20, (index) {
      final number = index + 1;
      final factor = multiplier == 'S' ? 1 : multiplier == 'D' ? 2 : 3;
      return FilledButton.tonal(onPressed: widget.disabled ? null : () => widget.onChanged(DartThrow('$multiplier $number', number * factor, number: number, multiplier: multiplier)), style: FilledButton.styleFrom(padding: EdgeInsets.zero), child: Text('$number'));
    })),
    const SizedBox(height: 7),
    Row(children: [specialButton('Fehlwurf\n0', const DartThrow('Fehlwurf', 0, miss: true)), const SizedBox(width: 5), specialButton('Outer Bull\n25', const DartThrow('Outer Bull', 25, outerBull: true)), const SizedBox(width: 5), specialButton('Bullseye\n50', const DartThrow('Bullseye', 50, bull: true))]),
  ])));
}

// Simuliert drei echte Treffer mit zunehmender Zielgenauigkeit je Bot-Stufe.
DartThrow _botThrow(String level){
  final rng=Random();
  final accuracy=switch(level){'Ultra leicht'=>0.10,'Leicht'=>0.24,'Mittel'=>0.42,'Hart'=>0.60,'Experte'=>0.76,_=>0.24};
  final missChance=switch(level){'Ultra leicht'=>0.24,'Leicht'=>0.12,'Mittel'=>0.07,'Hart'=>0.035,'Experte'=>0.015,_=>0.12};
  if(rng.nextDouble()<missChance)return const DartThrow('Fehlwurf',0,miss:true);
  // Experten zielen überwiegend auf T20; schwächere Bots streuen stärker über das Board.
  final target=rng.nextDouble()<accuracy?20:(rng.nextInt(20)+1);
  final roll=rng.nextDouble();
  if(level=='Experte'){
    if(roll<0.14)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.64)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.70)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else if(level=='Hart'){
    if(roll<0.28)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.63)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.82)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else if(level=='Mittel'){
    if(roll<0.14)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.65)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.80)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else if(level=='Leicht'){
    if(roll<0.06)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.72)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.82)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else{
    if(roll<0.02)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.66)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.74)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }
  if(rng.nextDouble()<0.35)return const DartThrow('Outer Bull',25,outerBull:true);
  if(rng.nextDouble()<0.12)return const DartThrow('Bullseye',50,bull:true);
  return DartThrow('S $target',target,number:target,multiplier:'S');
}

// Conservative rule engine: it evaluates the wording of the master cards. Unknown wording
// deliberately does not produce a false positive; the rule can be added without changing the UI.
bool evaluateCard(String raw,List<DartThrow> d){if(d.length!=3)return false;final t=raw.toLowerCase().replaceAll('ä','ae').replaceAll('ö','oe').replaceAll('ü','ue');final sum=d.fold<int>(0,(s,x)=>s+x.score);final triples=d.where((x)=>x.triple).length;final doubles=d.where((x)=>x.doubleHit).length;final bulls=d.where((x)=>x.bull).length;final outer=d.where((x)=>x.outerBull).length;final singles=d.where((x)=>x.single).length;final nums=d.map((x)=>x.numberKey).toSet();
 int? minScore=RegExp(r'mindestens\s+(\d+)\s+punkte').firstMatch(t)!=null?int.parse(RegExp(r'mindestens\s+(\d+)\s+punkte').firstMatch(t)!.group(1)!):null;
 int? exactScore=RegExp(r'genau\s+(\d+)(?:\s+punkte)?').firstMatch(t)!=null?int.parse(RegExp(r'genau\s+(\d+)(?:\s+punkte)?').firstMatch(t)!.group(1)!):null;
 if(minScore!=null&&sum<minScore)return false;if(exactScore!=null&&sum!=exactScore)return false;
 if(t.contains('ohne ein triple')||t.contains('ohne triple'))if(triples>0)return false;
 if(t.contains('ohne bullseye')||t.contains('ohne das bullseye'))if(bulls>0)return false;
 if(t.contains('ohne ein doppelfeld oder triple-feld')||t.contains('ohne ein doppelfeld oder triple'))if(doubles+triples>0)return false;
 if(t.contains('ausschliesslich einfache zahlenfelder')||t.contains('ausschliesslich einfache zahlenfelder treffen')||t.contains('nur einfache zahlenfelder'))if(d.any((x)=>!x.single))return false;
 if(t.contains('ausschliesslich single- und double-felder'))if(d.any((x)=>!(x.single||x.doubleHit)))return false;
 if(t.contains('ausschliesslich triple-felder oder bullseye'))if(d.any((x)=>!(x.triple||x.bull)))return false;
 final maxD=RegExp(r'hoechstens (\w+) doppelfeld').firstMatch(t);if(maxD!=null&&doubles>_wordNum(maxD.group(1)!))return false;
 final exactOneTriple=t.contains('genau einem triple');if(exactOneTriple&&triples!=1)return false;
 if(t.contains('mindestens drei unterschiedliche zahlenfelder')&&nums.length<3)return false;
 if(t.contains('mindestens drei unterschiedliche einfache zahlenfelder')&&d.where((x)=>x.single).map((x)=>x.number).toSet().length<3)return false;
 if(t.contains('jeder dart ein anderes zahlenfeld')&&nums.length<3)return false;
 if(t.contains('ohne dreimal dasselbe feld')&&d.map((x)=>x.fieldKey).toSet().length==1)return false;
 if(t.contains('ohne dreimal dasselbe zahlenfeld')&&nums.length==1)return false;
 if(t.contains('mindestens zwei unterschiedliche zahlenfelder')&&nums.length<2)return false;
 if(t.contains('mindestens zwei unterschiedliche doubles oder triples')){if(d.where((x)=>x.doubleHit||x.triple).map((x)=>x.fieldKey).toSet().length<2)return false;}
 if(t.contains('mindestens zwei verschiedene doubles oder triples')){if(d.where((x)=>x.doubleHit||x.triple).map((x)=>x.fieldKey).toSet().length<2)return false;}
 // Both wordings mean two hits on different numbers.
 final distinctDoublesRequired =
     t.contains('zwei unterschiedliche doubles') ||
     t.contains('zwei verschiedene doubles') ||
     t.contains('zweimal unterschiedliche doubles') ||
     t.contains('zweimal verschiedene doubles') ||
     t.contains('zweimal unterschiedliche double') ||
     t.contains('zweimal verschiedene double');
 if (distinctDoublesRequired &&
     d.where((x) => x.doubleHit).map((x) => x.number).toSet().length < 2) return false;

 final distinctTriplesRequired =
     t.contains('zwei unterschiedliche triples') ||
     t.contains('zwei verschiedene triples') ||
     t.contains('zweimal unterschiedliche triples') ||
     t.contains('zweimal verschiedene triples') ||
     t.contains('zweimal unterschiedliche triple') ||
     t.contains('zweimal verschiedene triple');
 if (distinctTriplesRequired &&
     d.where((x) => x.triple).map((x) => x.number).toSet().length < 2) return false;
 if(t.contains('zwei unterschiedliche einfache zahlenfelder')||t.contains('zwei unterschiedliche einfache zahlen'))if(d.where((x)=>x.single).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('mindestens zwei darts triple-felder'))if(triples<2)return false;
 if(t.contains('mindestens zwei triple-felder'))if(triples<2)return false;
 if(t.contains('mindestens ein triple-feld'))if(triples<1)return false;
 if(t.contains('mindestens zweimal ein doppelfeld')){if(doubles<2)return false;}
 if(t.contains('mindestens zweimal ein triple-feld')){if(triples<2)return false;}
 if(t.contains('mindestens zweimal ein beliebiges single-feld')){if(singles<2)return false;}
 if(t.contains('mindestens zwei einfache zahlenfelder mit geraden zahlen'))if(d.where((x)=>x.single&&x.number.isEven).length<2)return false;
 if(t.contains('mindestens zwei einfache zahlenfelder mit ungeraden zahlen'))if(d.where((x)=>x.single&&x.number.isOdd).length<2)return false;
 // Paritaet gemaess Spielregel: Bullseye ist gerade, Outer Bull ist ungerade.
 // Fehlwuerfe zaehlen weder als gerade noch als ungerade Zahl.
 final oddNumberRequirement = RegExp(r'mindestens\s+(ein|eine|einen|zwei|drei|vier|\d+)\s+ungerade zahlen?').firstMatch(t);
 if (oddNumberRequirement != null) {
   final required = _wordNum(oddNumberRequirement.group(1)!);
   final actual = d.where((x) => !x.miss && (x.outerBull || (!x.bull && x.number >= 1 && x.number <= 20 && x.number.isOdd))).length;
   if (required == 0 || actual < required) return false;
 }
 final evenNumberRequirement = RegExp(r'mindestens\s+(ein|eine|einen|zwei|drei|vier|\d+)\s+gerade zahlen?').firstMatch(t);
 if (evenNumberRequirement != null) {
   final required = _wordNum(evenNumberRequirement.group(1)!);
   final actual = d.where((x) => !x.miss && (x.bull || (!x.outerBull && x.number >= 1 && x.number <= 20 && x.number.isEven))).length;
   if (required == 0 || actual < required) return false;
 }

 if(t.contains('mindestens zweimal dasselbe zahlenfeld')){final counts=<String,int>{};for(final x in d){counts[x.numberKey]=(counts[x.numberKey]??0)+1;}if(counts.values.every((v)=>v<2))return false;}
 if(t.contains('mindestens zweimal die gleiche zahl als double oder triple')){final hits=d.where((x)=>x.doubleHit||x.triple).toList();if(hits.length<2||hits.map((x)=>x.number).toSet().length!=1)return false;}
 if(t.contains('shanghai')){if(d.map((x)=>x.number).toSet().length!=1||d.where((x)=>x.single).length!=1||d.where((x)=>x.doubleHit).length!=1||d.where((x)=>x.triple).length!=1)return false;}
 // Plain number targets such as "Treffe mindestens einmal die 18."
 // refer to the numbered segment, regardless of Single/Double/Triple.
 final plainNumberRe = RegExp(r'mindestens\s+(?:einmal|ein)\s+die\s+(\d{1,2})');
 for (final m in plainNumberRe.allMatches(t)) {
   final n = int.parse(m.group(1)!);
   if (n >= 1 && n <= 20 && !d.any((x) => x.number == n)) return false;
 }
 // Explicit hit requirements: count phrases are translated into exact field hits.
 // Parse named single/double/triple targets and required count from the text.
 // Konkrete einfache Zahlenfelder explizit prüfen. Das Leerzeichen vor der Zahl
 // ist wichtig: Ohne dieses wurde z.B. „einfache Zahlenfeld 18“ nicht erkannt.
 final simpleFieldRe = RegExp(r'einfache\s+zahlenfeld\s+(\d+)');
 for (final m in simpleFieldRe.allMatches(t)) {
   final n = int.parse(m.group(1)!);
   if (!d.any((x) => x.single && x.number == n)) return false;
 }
 final hitRe=RegExp(r'(mindestens\s+(zweimal|dreimal|einmal|zwei|drei)|mindestens\s+einmal|einmal)?\s*(?:das\s+)?(?:einfache\s+zahlenfeld\s+|einfache\s+|single\s+|double\s+|triple\s+)(\d+)');
 final requiredHits=<String,int>{};
 for(final m in hitRe.allMatches(t)){final segment=m.group(0)!;final n=int.parse(m.group(3)!);final typ=segment.contains('triple')?'T':segment.contains('double')?'D':'S';var count=1;if(segment.contains('zweimal')||segment.contains('zwei '))count=2;if(segment.contains('dreimal')||segment.contains('drei '))count=3;final key='$typ$n';requiredHits[key]=(requiredHits[key]??0)+count;}
 for(final entry in requiredHits.entries){final typ=entry.key[0];final n=int.parse(entry.key.substring(1));if(d.where((x)=>x.number==n&&x.multiplier==typ).length<entry.value)return false;}
 // Generic bull and field requirements.
 if(t.contains('bullseye')&&bulls<1&&!(t.contains('mindestens zweimal bullseye')&&bulls>=2))return false;
 if(t.contains('mindestens zweimal bullseye')&&bulls<2)return false;
 if(t.contains('outer bull')&&outer<(t.contains('zweimal outer bull')||t.contains('mindestens zweimal outer bull')?2:1))return false;
 if(t.contains('mindestens einmal ein doppelfeld')||t.contains('mindestens ein doppelfeld')||t.contains('mindestens ein double'))if(doubles<1)return false;
 if(t.contains('mindestens einmal ein triple')||t.contains('mindestens ein triple'))if(triples<1)return false;
 if(t.contains('mindestens zweimal ein doppelfeld'))if(doubles<2)return false;
 if(t.contains('mindestens zweimal ein triple'))if(triples<2)return false;
 // Requirements for unnumbered categories and ranges.
 if(t.contains('zwei unterschiedliche doubles')&&d.where((x)=>x.doubleHit).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('zwei unterschiedliche trip')&&d.where((x)=>x.triple).map((x)=>x.number).toSet().length<2)return false;
 final range=RegExp(r'(?:bereich|zwischen)\s+(\d+)\s+bis\s+(\d+)').firstMatch(t); if(range!=null){final a=int.parse(range.group(1)!),b=int.parse(range.group(2)!); if(!d.any((x)=>x.number>=a&&x.number<=b))return false;}
 // If text contains explicit field targets, every extracted requirement above is checked.
 // Unsupported special clauses remain unfulfilled rather than being guessed.
 // Fail closed: generic words alone must never make a card successful.
 final recognizedCondition =
     minScore != null || exactScore != null || requiredHits.isNotEmpty || plainNumberRe.hasMatch(t) || range != null ||
     t.contains('shanghai') ||
     t.contains('mindestens drei unterschiedliche zahlenfelder') ||
     t.contains('mindestens zwei unterschiedliche zahlenfelder') ||
     t.contains('jeder dart ein anderes zahlenfeld') ||
     t.contains('ohne dreimal dasselbe feld') ||
     t.contains('ohne dreimal dasselbe zahlenfeld') ||
     distinctDoublesRequired || distinctTriplesRequired ||
     t.contains('bullseye') || t.contains('outer bull') ||
     t.contains('doppelfeld') || t.contains('double') ||
     t.contains('triple') || t.contains('zahlenfeld') || t.contains('single');
 if (!recognizedCondition) return false;
 return true;
}
int _wordNum(String s)=>switch(s){'ein'=>1,'einen'=>1,'eine'=>1,'zwei'=>2,'drei'=>3,'vier'=>4,_=>int.tryParse(s)??0};

class ChallengeTile extends StatelessWidget {
  final PlayerCard item;
  final String? actionLabel;
  final VoidCallback? action;
  const ChallengeTile({super.key, required this.item, this.actionLabel, this.action});
  Color get color => switch (item.card.category) {'Easy' => Colors.green, 'Medium' => Colors.blue, 'Hard' => Colors.orange, 'Legende' => Colors.deepPurpleAccent, _ => Colors.redAccent};

  @override
  Widget build(BuildContext context) {
    final done = item.state != CardState.open;
    final crossed = item.state == CardState.crossed;
    final completed = item.state == CardState.completed;
    return Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text('#${item.card.id}', style: const TextStyle(color: Colors.white38, fontSize: 11, fontWeight: FontWeight.bold)), const SizedBox(width: 8), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: color.withOpacity(.18), borderRadius: BorderRadius.circular(20)), child: Text(item.card.category, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold))), const Spacer(), Text('+${categoryPoints[item.card.category]} P', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, fontSize: 12)), if (done) ...[const SizedBox(width: 7), Icon(completed ? Icons.check_circle : Icons.block, size: 17, color: completed ? Colors.greenAccent : Colors.orangeAccent)]]),
      const SizedBox(height: 6),
      Text(item.card.text, style: TextStyle(fontSize: 14, height: 1.25, color: done ? Colors.white38 : Colors.white, decoration: crossed ? TextDecoration.lineThrough : TextDecoration.none, decorationColor: Colors.white70, decorationThickness: 2)),
      if (done) Padding(padding: const EdgeInsets.only(top: 4), child: Text(completed ? 'GEWERTET' : 'GESTRICHEN', style: TextStyle(color: completed ? Colors.greenAccent : Colors.orangeAccent, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: .7))),
      if (actionLabel != null && action != null) Padding(padding: const EdgeInsets.only(top: 8), child: SizedBox(width: double.infinity, child: FilledButton(onPressed: action, child: Text(actionLabel!)))),
    ])));
  }
}


class ResultsScreen extends StatefulWidget {
  final List<Player> players;
  const ResultsScreen({super.key, required this.players});
  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _saveResults();
  }

  Future<void> _saveResults() async {
    if (_saved) return;
    _saved = true;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('dart_party_local_stats');
    final Map<String, dynamic> stats = raw == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(jsonDecode(raw) as Map);
    final highest = widget.players.map((p) => p.score).reduce((a, b) => a > b ? a : b);
    for (final p in widget.players) {
      final key = p.name.trim();
      final old = Map<String, dynamic>.from(stats[key] as Map? ?? <String, dynamic>{});
      final games = (old['games'] as num? ?? 0).toInt();
      final wins = (old['wins'] as num? ?? 0).toInt();
      final points = (old['points'] as num? ?? 0).toInt();
      stats[key] = <String, dynamic>{
        'games': games + 1,
        'wins': wins + (p.score == highest ? 1 : 0),
        'points': points + p.score,
      };
    }
    await prefs.setString('dart_party_local_stats', jsonEncode(stats));
  }

  @override
  Widget build(BuildContext context) {
    final sorted = [...widget.players]..sort((a, b) => b.score.compareTo(a.score));
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Icon(Icons.emoji_events, size: 72, color: Color(0xFFFFD166)),
              const SizedBox(height: 12),
              const Center(child: Text('SPIEL BEENDET', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
              const SizedBox(height: 8),
              Center(child: Text('Gewonnen hat ${sorted.first.name}', style: const TextStyle(fontSize: 18, color: purple))),
              const SizedBox(height: 24),
              ...sorted.map((p) => Card(child: ListTile(title: Text(p.name), trailing: Text('${p.score} Punkte', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))))),
              const Spacer(),
              FilledButton(
                onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false),
                child: const Text('Zurück zum Hauptmenü'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



enum DartsRule { straight, doubleRule, master }

String _ruleName(DartsRule rule) => switch (rule) {
  DartsRule.straight => 'Straight',
  DartsRule.doubleRule => 'Double',
  DartsRule.master => 'Master',
};

class DartsCounterPlayer {
  final String name;
  final bool isBot;
  final String botDifficulty;
  int remaining;
  bool hasStarted;
  int turns = 0;
  int? lastVisit;
  DartsCounterPlayer(this.name, int startScore, {this.isBot = false, this.botDifficulty = 'Leicht'})
      : remaining = startScore, hasStarted = true;
}

bool _isValidIn(DartThrow dart, DartsRule rule) => switch (rule) {
  DartsRule.straight => true,
  DartsRule.doubleRule => dart.doubleHit || dart.bull,
  DartsRule.master => dart.doubleHit || dart.triple || dart.bull,
};

bool _isValidOut(DartThrow dart, DartsRule rule) => switch (rule) {
  DartsRule.straight => true,
  DartsRule.doubleRule => dart.doubleHit || dart.bull,
  DartsRule.master => dart.doubleHit || dart.triple || dart.bull,
};

class DartsVisitEvaluation {
  final int scored;
  final int remaining;
  final bool started;
  final bool bust;
  final bool won;
  const DartsVisitEvaluation({required this.scored, required this.remaining, required this.started, this.bust = false, this.won = false});
}

DartsVisitEvaluation evaluateDartsVisit(DartsCounterPlayer player, List<DartThrow> darts, DartsRule inRule, DartsRule outRule) {
  var started = player.hasStarted;
  var scored = 0;
  for (final dart in darts) {
    if (!started) {
      if (!_isValidIn(dart, inRule)) continue;
      started = true;
    }
    scored += dart.score;
    final rest = player.remaining - scored;
    if (rest < 0) return DartsVisitEvaluation(scored: scored, remaining: player.remaining, started: started, bust: true);
    if (rest == 0) {
      if (_isValidOut(dart, outRule)) return DartsVisitEvaluation(scored: scored, remaining: 0, started: started, won: true);
      return DartsVisitEvaluation(scored: scored, remaining: player.remaining, started: started, bust: true);
    }
  }
  return DartsVisitEvaluation(scored: scored, remaining: player.remaining - scored, started: started);
}

List<DartThrow> _checkoutCandidates() {
  final result = <DartThrow>[];
  for (var n = 20; n >= 1; n--) result.add(DartThrow('T$n', n * 3, number: n, multiplier: 'T'));
  for (var n = 20; n >= 1; n--) result.add(DartThrow('D$n', n * 2, number: n, multiplier: 'D'));
  for (var n = 20; n >= 1; n--) result.add(DartThrow('S$n', n, number: n, multiplier: 'S'));
  result.add(const DartThrow('Bullseye', 50, bull: true));
  result.add(const DartThrow('Outer Bull', 25, outerBull: true));
  return result;
}

int _finishPreference(DartThrow dart, DartsRule outRule) {
  if (outRule == DartsRule.straight) {
    if (dart.triple) return 100 - dart.score;
    if (dart.doubleHit) return 200 - dart.score;
    if (dart.single) return 300 - dart.score;
    if (dart.bull) return 400;
    if (dart.outerBull) return 401;
    return 999;
  }
  if (dart.doubleHit) {
    const preferred = [20, 16, 18, 12, 14, 10, 8, 4, 2, 19, 17, 15, 13, 11, 9, 7, 6, 5, 3, 1];
    final index = preferred.indexOf(dart.number);
    return index < 0 ? 50 : index;
  }
  if (dart.bull) return 25;
  if (dart.triple && outRule == DartsRule.master) return 30 + (20 - dart.number);
  return 999;
}

List<DartThrow>? bestCheckout(int remaining, int dartsAvailable, DartsRule outRule) {
  final maxCheckout = outRule == DartsRule.doubleRule ? 170 : 180;
  if (remaining <= 0 || remaining > maxCheckout || dartsAvailable <= 0) return null;
  // Canonical route for 121 Double Out; after a missed T20 (S20), the
  // two-dart solver below immediately switches to T17 + Bullseye for 101.
  if (outRule == DartsRule.doubleRule && remaining == 121 && dartsAvailable >= 3) {
    return [
      DartThrow('T20', 60, number: 20, multiplier: 'T'),
      DartThrow('T11', 33, number: 11, multiplier: 'T'),
      DartThrow('D14', 28, number: 14, multiplier: 'D'),
    ];
  }
  final candidates = _checkoutCandidates();
  final candidateRank = <String, int>{for (var i = 0; i < candidates.length; i++) candidates[i].fieldKey: i};
  for (var used = 1; used <= dartsAvailable && used <= 3; used++) {
    final routes = <List<DartThrow>>[];
    void search(int slots, int pointsLeft, List<DartThrow> prefix) {
      if (slots == 1) {
        for (final finish in candidates) {
          if (finish.score == pointsLeft && _isValidOut(finish, outRule)) routes.add([...prefix, finish]);
        }
        return;
      }
      for (final dart in candidates) {
        if (dart.score <= 0 || dart.score >= pointsLeft) continue;
        prefix.add(dart);
        search(slots - 1, pointsLeft - dart.score, prefix);
        prefix.removeLast();
      }
    }
    search(used, remaining, <DartThrow>[]);
    if (routes.isNotEmpty) {
      routes.sort((a, b) {
        var c = _finishPreference(a.last, outRule).compareTo(_finishPreference(b.last, outRule));
        if (c != 0) return c;
        for (var i = 0; i < a.length - 1; i++) {
          c = (candidateRank[a[i].fieldKey] ?? 999).compareTo(candidateRank[b[i].fieldKey] ?? 999);
          if (c != 0) return c;
        }
        return 0;
      });
      return routes.first;
    }
  }
  return null;
}

class DartsCounterSetupScreen extends StatefulWidget {
  const DartsCounterSetupScreen({super.key});
  @override State<DartsCounterSetupScreen> createState() => _DartsCounterSetupScreenState();
}

class _DartsCounterSetupScreenState extends State<DartsCounterSetupScreen> {
  final names = [TextEditingController(text: 'Spieler 1'), TextEditingController(text: 'Spieler 2')];
  final List<bool> botPlayers = [false, false];
  final List<String> botLevels = ['Leicht', 'Leicht'];
  int startScore = 501;
  DartsRule inRule = DartsRule.straight;
  DartsRule outRule = DartsRule.doubleRule;
  bool checkoutHelp = true;
  bool loading = false;

  @override void initState() { super.initState(); _loadNames(); }
  Future<void> _loadNames() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dart_party_player_names');
    if (saved != null && saved.isNotEmpty) {
      for (var i = 0; i < saved.length && i < 8; i++) {
        if (i >= names.length) { names.add(TextEditingController(text: saved[i])); botPlayers.add(false); botLevels.add('Leicht'); }
        else if (saved[i].trim().isNotEmpty) names[i].text = saved[i];
      }
      if (mounted) setState(() {});
    }
  }
  @override void dispose() { for (final name in names) { name.dispose(); } super.dispose(); }
  void _addPlayer() => setState(() { names.add(TextEditingController(text: 'Spieler ${names.length + 1}')); botPlayers.add(false); botLevels.add('Leicht'); });
  void _removePlayer(int index) => setState(() { names.removeAt(index).dispose(); botPlayers.removeAt(index); botLevels.removeAt(index); });

  void _showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const Text('Spielregeln – Dartszähler'),
    content: const SingleChildScrollView(child: Text(
      'Ziel ist es, von 301 oder 501 Punkten exakt auf 0 zu kommen. Jeder Spieler wirft pro Aufnahme bis zu drei Darts.\n\n'
      'Straight In: Jeder Dart zählt von Beginn an. Double In: Erst ein Double oder Bullseye startet das Spiel; dieser Dart zählt bereits. Master In: Ein Double, Triple oder Bullseye startet das Spiel.\n\n'
      'Straight Out: Zum Sieg muss exakt 0 erreicht werden. Double Out: Der letzte Dart muss ein Double oder Bullseye sein. Master Out: Der letzte Dart muss ein Double, Triple oder Bullseye sein.\n\n'
      'Überwerfen oder ein ungültiger Finish-Versuch bedeutet Bust: Die gesamte Aufnahme wird zurückgesetzt. Ein erfolgreicher Checkout beendet das Spiel sofort.'
    )), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Schließen'))]));

  void _start() async {
    final valid = names.map((c) => c.text.trim()).toList();
    if (valid.length < 2 || valid.any((n) => n.isEmpty) || valid.toSet().length != valid.length) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bitte mindestens zwei unterschiedliche Spielernamen eintragen.')));
      return;
    }
    setState(() => loading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('dart_party_player_names', valid);
      final players = List.generate(valid.length, (i) => DartsCounterPlayer(valid[i], startScore, isBot: botPlayers[i], botDifficulty: botLevels[i])
        ..hasStarted = inRule == DartsRule.straight);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DartsCounterGameScreen(players: players, startScore: startScore, inRule: inRule, outRule: outRule, checkoutHelp: checkoutHelp)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fehler: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Dartszähler einstellen'), actions: [IconButton(tooltip: 'Spielregeln', icon: const Icon(Icons.help_outline), onPressed: _showRules)]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('DARTSZÄHLER', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6), const Text('Spieler, Startpunkte und Regeln festlegen.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      DropdownButtonFormField<int>(value: startScore, decoration: const InputDecoration(labelText: 'Startpunktzahl'), items: const [301, 501].map((n) => DropdownMenuItem(value: n, child: Text('$n Punkte'))).toList(), onChanged: loading ? null : (v) => setState(() => startScore = v ?? 501)),
      const SizedBox(height: 12),
      DropdownButtonFormField<DartsRule>(value: inRule, decoration: const InputDecoration(labelText: 'Spielbeginn (In)'), items: DartsRule.values.map((r) => DropdownMenuItem(value: r, child: Text('${_ruleName(r)} In'))).toList(), onChanged: loading ? null : (v) => setState(() => inRule = v ?? DartsRule.straight)),
      const SizedBox(height: 12),
      DropdownButtonFormField<DartsRule>(value: outRule, decoration: const InputDecoration(labelText: 'Spielende (Out)'), items: DartsRule.values.map((r) => DropdownMenuItem(value: r, child: Text('${_ruleName(r)} Out'))).toList(), onChanged: loading ? null : (v) => setState(() => outRule = v ?? DartsRule.doubleRule)),
      const SizedBox(height: 8),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Checkouthilfe anzeigen'), subtitle: const Text('Berechnet nach jedem Dart den besten legalen Weg auf 0.'), value: checkoutHelp, onChanged: loading ? null : (v) => setState(() => checkoutHelp = v)),
      const Divider(height: 28),
      const Text('SPIELER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 10),
      ...List.generate(names.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: TextField(controller: names[i], decoration: InputDecoration(labelText: 'Spieler ${i + 1}'))), if (names.length > 2) IconButton(onPressed: loading ? null : () => _removePlayer(i), icon: const Icon(Icons.close))]),
        const SizedBox(height: 7),
        Row(children: [
          Expanded(child: DropdownButtonFormField<bool>(value: botPlayers[i], decoration: const InputDecoration(labelText: 'Spielertyp'), items: const [DropdownMenuItem(value: false, child: Text('Mensch')), DropdownMenuItem(value: true, child: Text('Bot'))], onChanged: loading ? null : (v) => setState(() => botPlayers[i] = v ?? false))),
          if (botPlayers[i]) const SizedBox(width: 8),
          if (botPlayers[i]) Expanded(child: DropdownButtonFormField<String>(value: botLevels[i], decoration: const InputDecoration(labelText: 'Bot-Stärke'), items: const ['Ultra leicht', 'Leicht', 'Mittel', 'Hart', 'Experte'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: loading ? null : (v) => setState(() => botLevels[i] = v ?? 'Leicht'))),
        ]),
      ]))),
      OutlinedButton.icon(onPressed: loading || names.length >= 8 ? null : _addPlayer, icon: const Icon(Icons.add), label: const Text('Spieler hinzufügen')),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: loading ? null : _start, icon: const Icon(Icons.play_arrow), label: const Text('Spiel starten')),
    ])),
  );
}

class DartsCounterGameScreen extends StatefulWidget {
  final List<DartsCounterPlayer> players;
  final int startScore;
  final DartsRule inRule;
  final DartsRule outRule;
  final bool checkoutHelp;
  const DartsCounterGameScreen({super.key, required this.players, required this.startScore, required this.inRule, required this.outRule, required this.checkoutHelp});
  @override State<DartsCounterGameScreen> createState() => _DartsCounterGameScreenState();
}

class _DartsCounterGameScreenState extends State<DartsCounterGameScreen> {
  int playerIndex = 0;
  final List<DartThrow> darts = [];
  String? message;
  bool gameOver = false;
  bool botBusy = false;
  String? winner;
  DartsCounterPlayer get player => widget.players[playerIndex];
  DartsVisitEvaluation get visit => evaluateDartsVisit(player, darts, widget.inRule, widget.outRule);

  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded()); }

  void _startBotIfNeeded() {
    if (!mounted || gameOver || botBusy || !player.isBot) return;
    botBusy = true;
    _playBotVisit();
  }

  Future<void> _playBotVisit() async {
    final bot = player;
    final expectedIndex = playerIndex;
    for (var i = 0; i < 3; i++) {
      await Future.delayed(const Duration(milliseconds: 520));
      if (!mounted || gameOver || playerIndex != expectedIndex || player != bot) break;
      _addDart(_botThrow(bot.botDifficulty));
      if (gameOver || playerIndex != expectedIndex || player != bot) break;
    }
    botBusy = false;
    if (mounted && !gameOver && player.isBot && player != bot) _startBotIfNeeded();
  }

  void _addDart(DartThrow dart) {
    if (gameOver || player.isBot && !botBusy || darts.length >= 3) return;
    final updated = [...darts, dart];
    final result = evaluateDartsVisit(player, updated, widget.inRule, widget.outRule);
    if (result.bust || result.won || updated.length == 3) {
      setState(() {
        player.hasStarted = result.started;
        player.turns++;
        if (result.bust) {
          player.lastVisit = null;
          message = '${player.name}: BUST – die Aufnahme zählt nicht. Rest bleibt bei ${player.remaining}.';
        } else {
          player.remaining = result.remaining;
          player.lastVisit = result.scored;
          message = result.won ? '${player.name} checkt aus und gewinnt!' : '${player.name}: ${result.scored} Punkte – neuer Rest: ${player.remaining}.';
        }
        darts.clear();
        if (result.won) { gameOver = true; winner = player.name; }
        else { playerIndex = (playerIndex + 1) % widget.players.length; }
      });
      if (result.won) _showWinner();
      else WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
    } else {
      setState(() => darts.add(dart));
    }
  }

  void _showWinner() {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      showDialog(context: context, barrierDismissible: false, builder: (context) => AlertDialog(
        title: const Text('Spiel beendet'),
        content: Text('${winner ?? 'Ein Spieler'} gewinnt mit einem Checkout!'),
        actions: [TextButton(onPressed: () => Navigator.popUntil(context, (route) => route.isFirst), child: const Text('Zum Hauptmenü'))],
      ));
    });
  }

  Widget _checkoutCard() {
    if (!widget.checkoutHelp) return const SizedBox.shrink();
    final evaluation = visit;
    final remainingDarts = 3 - darts.length;
    String headline;
    String routeText = '';
    String detail = '';
    if (!evaluation.started) {
      headline = 'Zuerst einchecken';
      detail = '${_ruleName(widget.inRule)} In: Treffer mit den passenden Feldern startet das Spiel.';
    } else {
      final route = bestCheckout(evaluation.remaining, remainingDarts, widget.outRule);
      if (route == null) {
        headline = 'Kein Checkout möglich';
        detail = remainingDarts <= 0 ? 'Die Aufnahme ist beendet.' : 'Mit $remainingDarts verbleibenden Dart${remainingDarts == 1 ? '' : 's'} ist kein legaler Finish-Weg möglich.';
      } else {
        headline = route.map((d) => d.label).join(' – ');
        routeText = '${route.fold<int>(0, (sum, d) => sum + d.score)} Punkte';
        detail = '${route.length} Dart${route.length == 1 ? '' : 's'} · ${_ruleName(widget.outRule)} Out';
      }
    }
    return Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.alt_route, color: purple), const SizedBox(width: 8), const Text('BESTER CHECKOUT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8)), const Spacer(), Text('$remainingDarts/3 Darts übrig', style: const TextStyle(color: Colors.white54, fontSize: 11))]),
      const SizedBox(height: 10),
      Text(headline, style: TextStyle(fontSize: routeText.isEmpty ? 17 : 22, fontWeight: FontWeight.w900, color: routeText.isEmpty ? Colors.white70 : Colors.greenAccent)),
      if (routeText.isNotEmpty) Text(routeText, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      const SizedBox(height: 3), Text(detail, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    ])));
  }

  void _showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const Text('Spielregeln – Dartszähler'),
    content: SingleChildScrollView(child: Text(
      '${widget.startScore} Punkte · ${_ruleName(widget.inRule)} In · ${_ruleName(widget.outRule)} Out.\n\n'
      'Jeder Spieler wirft bis zu drei Darts. Ein Bust setzt die gesamte Aufnahme zurück. Ein erfolgreicher Checkout beendet das Spiel sofort.\n\n'
      'Double In/Out zählt mit einem Double oder innerem Bullseye. Master In/Out zählt mit Double, Triple oder innerem Bullseye. Outer Bull ist 25 Punkte, aber kein Double-Finish.'
    )),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Schließen'))]));

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${widget.startScore} – Dartszähler'), actions: [IconButton(tooltip: 'Spielregeln', icon: const Icon(Icons.help_outline), onPressed: _showRules)]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: Text(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))), Text('Aufnahme ${player.turns + 1}', style: const TextStyle(color: Colors.white60))]),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        const Text('RESTPUNKTE', style: TextStyle(color: Colors.white60, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 5),
        Text('${visit.remaining}', style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w900, color: purple), key: ValueKey('${player.name}-${visit.remaining}-${darts.length}')),
        Text('${_ruleName(widget.inRule)} In  ·  ${_ruleName(widget.outRule)} Out', style: const TextStyle(color: Colors.white54, fontSize: 12)),
        if (!player.hasStarted && !visit.started) const Padding(padding: EdgeInsets.only(top: 8), child: Text('Noch nicht eingecheckt', style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold))),
      ]))),
      _checkoutCard(),
      const SizedBox(height: 8),
      if (player.isBot)
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(botBusy ? 'Bot wirft automatisch … ${darts.length}/3 Darts' : 'Bot ist am Zug.', style: const TextStyle(color: Colors.white60))))
      else ...[
        _DartProgress(darts: darts, total: visit.scored, onUndo: darts.isEmpty ? null : () => setState(() => darts.removeLast()), onReset: darts.isEmpty ? null : () => setState(() => darts.clear()), completionText: 'Aufnahme wird nach dem dritten Dart automatisch gewertet.'),
        const SizedBox(height: 8),
        if (darts.length < 3) DartEntry(onChanged: _addDart),
      ],
      if (message != null) Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(message!, style: const TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 8),
      const Text('SPIELERÜBERSICHT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      ...widget.players.map((p) => Card(child: ListTile(
        leading: Icon(p.isBot ? Icons.smart_toy : Icons.person, color: p.name == player.name && !gameOver ? purple : Colors.white54),
        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${p.isBot ? 'Bot · ${p.botDifficulty}' : 'Mensch'}${p.hasStarted ? '' : ' · noch nicht eingecheckt'}${p.lastVisit == null ? '' : ' · letzte Aufnahme: ${p.lastVisit}'}'),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('${p.remaining}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), if (p.name == player.name && !gameOver) const Text('AM ZUG', style: TextStyle(color: purple, fontSize: 9, fontWeight: FontWeight.bold))]),
      ))),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: _showRules, icon: const Icon(Icons.help_outline), label: const Text('Spielregeln anzeigen')),
    ])),
  );
}

class UnderOverPlayer {
  final String name;
  final bool isBot;
  final String botDifficulty;
  int? lastScore;
  bool eliminated = false;
  int turns = 0;
  UnderOverPlayer(this.name, {this.isBot = false, this.botDifficulty = 'Leicht'});
}

class UnderOverSetupScreen extends StatefulWidget {
  const UnderOverSetupScreen({super.key});
  @override State<UnderOverSetupScreen> createState() => _UnderOverSetupScreenState();
}
class _UnderOverSetupScreenState extends State<UnderOverSetupScreen> {
  final names = [TextEditingController(text: 'Spieler 1'), TextEditingController(text: 'Spieler 2')];
  final List<bool> botPlayers = [false, false];
  final List<String> botLevels = ['Leicht', 'Leicht'];
  bool loading = false;
  @override void initState() { super.initState(); _loadNames(); }
  Future<void> _loadNames() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dart_party_player_names');
    if (saved != null && saved.isNotEmpty) {
      for (var i = 0; i < saved.length && i < 8; i++) {
        if (i >= names.length) { names.add(TextEditingController(text: saved[i])); botPlayers.add(false); botLevels.add('Leicht'); }
        else if (saved[i].trim().isNotEmpty) names[i].text = saved[i];
      }
      if (mounted) setState(() {});
    }
  }
  @override void dispose() { for (final c in names) { c.dispose(); } super.dispose(); }
  void _addPlayer() => setState(() { names.add(TextEditingController(text: 'Spieler ${names.length + 1}')); botPlayers.add(false); botLevels.add('Leicht'); });
  void _removePlayer(int index) => setState(() { names.removeAt(index).dispose(); botPlayers.removeAt(index); botLevels.removeAt(index); });
  void showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const Text('Spielregeln – Unter / Über 40'),
    content: const SingleChildScrollView(child: Text(
      '1. Beide Grenzen starten bei 40. Jeder Spieler – Mensch oder Bot – wirft drei Darts.\n\n'
      '2. Liegt die Summe unter der Untergrenze, wird die Untergrenze auf diese Summe gesetzt.\n\n'
      '3. Liegt die Summe über der Obergrenze, wird die Obergrenze auf diese Summe gesetzt.\n\n'
      '4. Innerhalb des Bereichs oder genau auf einer Grenze scheidet der Spieler aus.\n\n'
      '5. Triple 1 zählt 0 Punkte. Der letzte verbleibende Spieler gewinnt.'
    )), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Schließen'))]));
  void start() {
    final valid = names.map((c) => c.text.trim()).toList();
    if (valid.length < 2 || valid.any((n) => n.isEmpty) || valid.toSet().length != valid.length) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bitte mindestens zwei unterschiedliche Spielernamen eintragen.')));
      return;
    }
    final players = List.generate(valid.length, (i) => UnderOverPlayer(valid[i], isBot: botPlayers[i], botDifficulty: botLevels[i]));
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => UnderOverGameScreen(players: players)));
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Spieler festlegen')),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [const Expanded(child: Text('UNTER / ÜBER 40', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900))), IconButton(tooltip: 'Spielregeln', icon: const Icon(Icons.help_outline), onPressed: showRules)]),
      const Text('Trage Menschen und Bots ein. Beide Grenzen starten bei 40.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      ...List.generate(names.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: TextField(controller: names[i], decoration: InputDecoration(labelText: 'Spieler ${i + 1}'))), if (names.length > 2) IconButton(onPressed: loading ? null : () => _removePlayer(i), icon: const Icon(Icons.close))]),
        const SizedBox(height: 7),
        Row(children: [
          Expanded(child: DropdownButtonFormField<bool>(value: botPlayers[i], decoration: const InputDecoration(labelText: 'Spielertyp'), items: const [DropdownMenuItem(value: false, child: Text('Mensch')), DropdownMenuItem(value: true, child: Text('Bot'))], onChanged: loading ? null : (v) => setState(() => botPlayers[i] = v ?? false))),
          if (botPlayers[i]) const SizedBox(width: 8),
          if (botPlayers[i]) Expanded(child: DropdownButtonFormField<String>(value: botLevels[i], decoration: const InputDecoration(labelText: 'Bot-Stärke'), items: const ['Ultra leicht', 'Leicht', 'Mittel', 'Hart', 'Experte'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: loading ? null : (v) => setState(() => botLevels[i] = v ?? 'Leicht'))),
        ]),
      ]))),
      OutlinedButton.icon(onPressed: names.length >= 8 ? null : _addPlayer, icon: const Icon(Icons.add), label: const Text('Spieler hinzufügen')),
      const SizedBox(height: 22),
      FilledButton.icon(onPressed: start, icon: const Icon(Icons.play_arrow), label: const Text('Spiel starten')),
    ])),
  );
}

class UnderOverGameScreen extends StatefulWidget {
  final List<UnderOverPlayer> players;
  const UnderOverGameScreen({super.key, required this.players});
  @override State<UnderOverGameScreen> createState() => _UnderOverGameScreenState();
}

class _UnderOverGameScreenState extends State<UnderOverGameScreen> {
  int lower = 40, upper = 40, playerIndex = 0;
  final List<DartThrow> darts = [];
  String? message;
  bool gameOver = false;
  bool botBusy = false;
  UnderOverPlayer get player => widget.players[playerIndex];
  List<UnderOverPlayer> get active => widget.players.where((p) => !p.eliminated).toList();
  int get total => darts.fold<int>(0, (sum, dart) => sum + dart.score);

  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded()); }
  void _startBotIfNeeded() {
    if (!mounted || gameOver || botBusy || !player.isBot) return;
    botBusy = true;
    _playBotTurn();
  }
  Future<void> _playBotTurn() async {
    final bot = player;
    final expectedIndex = playerIndex;
    for (var i = 0; i < 3; i++) {
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted || gameOver || playerIndex != expectedIndex || player != bot) break;
      _addDart(_botThrow(bot.botDifficulty));
    }
    if (!mounted) return;
    if (playerIndex == expectedIndex && identical(player, bot) && darts.length == 3 && !gameOver) _submit();
    botBusy = false;
    if (mounted && !gameOver && player.isBot && !identical(player, bot)) _startBotIfNeeded();
  }

  void showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const Text('Spielregeln – Unter / Über 40'),
    content: const SingleChildScrollView(child: Text(
      'Start: Untergrenze 40 und Obergrenze 40. Jeder Spieler – Mensch oder Bot – wirft drei Darts.\n\n'
      'Unter der Untergrenze: Die Untergrenze wird auf die Summe gesetzt.\n\n'
      'Über der Obergrenze: Die Obergrenze wird auf die Summe gesetzt.\n\n'
      'Innerhalb des Bereichs oder genau auf einer Grenze: Der Spieler scheidet aus.\n\n'
      'Triple 1 zählt 0 Punkte. Der letzte verbleibende Spieler gewinnt.'
    )), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Schließen'))]));

  void _addDart(DartThrow dart) {
    if (gameOver || darts.length >= 3 || (player.isBot && !botBusy)) return;
    final accepted = dart.triple && dart.number == 1 ? const DartThrow('T 1', 0, number: 1, multiplier: 'T') : dart;
    setState(() => darts.add(accepted));
  }
  void _undoDart() { if (darts.isNotEmpty && !gameOver && !player.isBot) setState(() => darts.removeLast()); }
  void _resetDarts() { if (darts.isNotEmpty && !gameOver && !player.isBot) setState(() => darts.clear()); }

  void _submit() {
    if (darts.length != 3 || gameOver) return;
    final current = player;
    final value = total;
    setState(() {
      current.lastScore = value;
      current.turns++;
      if (value < lower) { lower = value; message = '${current.name}: $value Punkte – neue Untergrenze: $lower'; }
      else if (value > upper) { upper = value; message = '${current.name}: $value Punkte – neue Obergrenze: $upper'; }
      else { current.eliminated = true; message = '${current.name} scheidet mit $value Punkten aus.'; }
      darts.clear();
      if (active.length <= 1) gameOver = true;
      else {
        for (var i = 1; i <= widget.players.length; i++) {
          final next = (playerIndex + i) % widget.players.length;
          if (!widget.players[next].eliminated) { playerIndex = next; break; }
        }
      }
    });
    if (gameOver) {
      Future.delayed(const Duration(milliseconds: 350), () {
        if (!mounted) return;
        showDialog(context: context, barrierDismissible: false, builder: (context) => AlertDialog(
          title: const Text('Spiel beendet'),
          content: Text(active.isEmpty ? 'Alle Spieler sind ausgeschieden.' : 'Gewonnen hat ${active.first.name}!'),
          actions: [TextButton(onPressed: () => Navigator.popUntil(context, (route) => route.isFirst), child: const Text('Zum Hauptmenü'))],
        ));
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Unter / Über 40'), actions: [IconButton(tooltip: 'Spielregeln', icon: const Icon(Icons.help_outline), onPressed: showRules)]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: Text(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))), Text('Runde ${player.turns + 1}', style: const TextStyle(color: Colors.white60))]),
      if (player.isBot) const Padding(padding: EdgeInsets.only(top: 4), child: Text('BOT AM ZUG', style: TextStyle(color: purple, fontWeight: FontWeight.bold, fontSize: 11))),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        const Text('AKTUELLE GRENZEN', style: TextStyle(color: Colors.white60, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: Column(children: [const Text('UNTER', style: TextStyle(color: Colors.lightBlueAccent, fontWeight: FontWeight.bold)), Text('$lower', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Colors.lightBlueAccent))])),
          Container(width: 1, height: 48, color: Colors.white24),
          Expanded(child: Column(children: [const Text('ÜBER', style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold)), Text('$upper', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Colors.orangeAccent))])),
        ]),
      ]))),
      const SizedBox(height: 14),
      _DartProgress(darts: darts, total: total, onUndo: player.isBot ? null : _undoDart, onReset: player.isBot ? null : _resetDarts, completionText: 'Alle drei Darts eingegeben – Summe prüfen und bestätigen.'),
      const SizedBox(height: 10),
      if (player.isBot)
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Text('Bot wirft automatisch … ${darts.length}/3 Darts', style: const TextStyle(color: Colors.white60))))
      else if (darts.length < 3)
        DartEntry(onChanged: _addDart)
      else
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('DEINE DREI WÜRFE', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
          const SizedBox(height: 7),
          Text(darts.map((dart) => dart.label).join('   ·   '), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 5),
          Text('Gesamt: $total Punkte', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: purple)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.check), label: const Text('Wurf bestätigen'))),
        ]))),
      if (message != null) Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(message!, style: const TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 10),
      const Text('SPIELERÜBERSICHT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 6),
      ...widget.players.map((p) => Card(child: ListTile(
        leading: Icon(p.eliminated ? Icons.cancel : (p.isBot ? Icons.smart_toy : Icons.person), color: p.eliminated ? Colors.redAccent : (p.name == player.name && !gameOver ? purple : Colors.greenAccent)),
        title: Text(p.name, style: TextStyle(decoration: p.eliminated ? TextDecoration.lineThrough : null, color: p.eliminated ? Colors.white38 : Colors.white)),
        subtitle: Text('${p.isBot ? 'Bot · ${p.botDifficulty}' : 'Mensch'} · ${p.eliminated ? 'Ausgeschieden · ${p.lastScore} Punkte' : 'Noch im Spiel${p.lastScore == null ? '' : ' · letzter Wurf: ${p.lastScore}'}'}'),
        trailing: p.name == player.name && !gameOver ? const Text('AM ZUG', style: TextStyle(color: purple, fontWeight: FontWeight.bold)) : null,
      ))),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: showRules, icon: const Icon(Icons.help_outline), label: const Text('Spielregeln anzeigen')),
    ])),
  );
}

class LocalStatsScreen extends StatefulWidget {
  const LocalStatsScreen({super.key});
  @override
  State<LocalStatsScreen> createState() => _LocalStatsScreenState();
}

class _LocalStatsScreenState extends State<LocalStatsScreen> {
  Map<String, dynamic> stats = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('dart_party_local_stats');
    if (raw != null) {
      try {
        stats = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      } catch (_) {
        stats = {};
      }
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final entries = stats.entries.toList()
      ..sort((a, b) => ((b.value['wins'] as num?) ?? 0).compareTo((a.value['wins'] as num?) ?? 0));
    return Scaffold(
      appBar: AppBar(title: const Text('Spieler-Statistik')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : entries.isEmpty
              ? const Center(child: Text('Noch keine abgeschlossenen Spiele.'))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: entries.map((entry) {
                    final value = Map<String, dynamic>.from(entry.value as Map);
                    final games = (value['games'] as num? ?? 0).toInt();
                    final wins = (value['wins'] as num? ?? 0).toInt();
                    final points = (value['points'] as num? ?? 0).toInt();
                    final average = games == 0 ? 0 : points / games;
                    return Card(
                      child: ListTile(
                        title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('$games Spiele · $wins Siege · Ø ${average.toStringAsFixed(1)} Punkte/Spiel'),
                        trailing: Text('$points P', style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
                      ),
                    );
                  }).toList(),
                ),
    );
  }
}
