import 'package:flutter_test/flutter_test.dart';
import 'package:dart_party/main.dart';

void main() {
  group('Kartenjagd-Treffererkennung', () {
    test('Triple 16 und Double 20 werden mit S15/S20/S19 nicht erfüllt', () {
      final darts = [
        const DartThrow('S 15', 15, number: 15, multiplier: 'S'),
        const DartThrow('S 20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S 19', 19, number: 19, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens einmal Triple 16 und Double 20.', darts), isFalse);
    });

    test('Single 10 und Single 11 werden mit S15/S20/S19 nicht erfüllt', () {
      final darts = [
        const DartThrow('S 15', 15, number: 15, multiplier: 'S'),
        const DartThrow('S 20', 20, number: 20, multiplier: 'S'),
        const DartThrow('S 19', 19, number: 19, multiplier: 'S'),
      ];
      expect(evaluateCard('Triff mit drei Darts mindestens einmal Single 10 und Single 11.', darts), isFalse);
    });

    test('konkrete Triple- und Double-Treffer werden erkannt', () {
      final darts = [
        const DartThrow('T 16', 48, number: 16, multiplier: 'T'),
        const DartThrow('D 20', 40, number: 20, multiplier: 'D'),
        const DartThrow('S 1', 1, number: 1, multiplier: 'S'),
      ];
      expect(evaluateCard('Treffe mindestens einmal Triple 16 und Double 20.', darts), isTrue);
    });

    test('konkrete Single-Treffer werden erkannt', () {
      final darts = [
        const DartThrow('S 10', 10, number: 10, multiplier: 'S'),
        const DartThrow('S 11', 11, number: 11, multiplier: 'S'),
        const DartThrow('S 1', 1, number: 1, multiplier: 'S'),
      ];
      expect(evaluateCard('Triff mindestens einmal Single 10 und Single 11.', darts), isTrue);
    });
  });
}
