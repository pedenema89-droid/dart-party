# Dart Party – Version 1.0.5

Android/Flutter-App für lokale Kartenjagd.

## Projektstand 1.0.5
- Ein einziges Dart-Eingabefeld für alle drei Würfe.
- Die Würfe werden nacheinander eingegeben und direkt in drei kompakten Feldern angezeigt.
- Nach dem dritten Dart startet die Kartenprüfung automatisch.
- Bei Treffern werden ausschließlich erfüllte Karten zur Wertung angeboten.
- Wenn keine Karte erfüllt ist, werden offene Karten zum Streichen angezeigt.
- Gewertete und gestrichene Karten bleiben in der Übersicht sichtbar; gestrichene Karten sind durchgestrichen.
- Kartenansicht kompakter und klarer strukturiert.

## Build
Die Projektdateien liegen direkt im Repository-Hauptverzeichnis. Der GitHub-Actions-Workflow erstellt bei Bedarf die Android-Plattformdateien und baut anschließend die APK.
