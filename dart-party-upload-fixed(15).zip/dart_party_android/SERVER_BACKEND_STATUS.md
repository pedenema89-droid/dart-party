# Backend-Stand

- Google Login: in Version 1.4.8 bereits erfolgreich auf dem Gerät getestet.
- Firestore: Datenbank erstellt; Regeln bleiben clientseitig vollständig geschlossen.
- Neue Funktionen: `getWallet` und `startMatch` in `functions/index.js`.
- Wallet: 5 Starttoken einmalig, 2 tägliche Token (Europe/Berlin), gekaufte Token sind vorbereitet, aber noch nicht gutschreibbar, bis Play-Belegprüfung implementiert ist.
- Echtgeldkäufe: absichtlich deaktiviert, bis Google Play Developer API serverseitig angeschlossen ist.
- Bereitstellung: siehe `FIREBASE_BACKEND_SETUP.md`.
