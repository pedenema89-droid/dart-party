const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const {
  berlinDateKey,
  initialWallet,
  normalizeWallet,
  refreshDailyTokens,
  isUnlimited,
  consumeOneToken,
  publicWallet,
} = require('./wallet_logic');

initializeApp();
setGlobalOptions({
  region: 'europe-west3',
  maxInstances: 10,
});

const db = getFirestore();

function requireUid(request) {
  const uid = request.auth && request.auth.uid;
  if (!uid) {
    throw new HttpsError('unauthenticated', 'Bitte melde dich mit Google an.');
  }
  return uid;
}

function validateMatchId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{12,100}$/.test(value);
}

function walletDocument(uid) {
  return db.collection('users').doc(uid);
}

exports.getWallet = onCall(async (request) => {
  const uid = requireUid(request);
  const userRef = walletDocument(uid);
  const today = berlinDateKey();

  const wallet = await db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(userRef);
    const current = snapshot.exists
      ? normalizeWallet(snapshot.data(), today)
      : initialWallet(today);
    const refreshed = refreshDailyTokens(current, today);
    const needsWrite = !snapshot.exists || current.dailyDate !== today;
    if (needsWrite) {
      const writeData = {
        ...refreshed,
        updatedAt: FieldValue.serverTimestamp(),
      };
      if (!snapshot.exists) writeData.createdAt = FieldValue.serverTimestamp();
      transaction.set(userRef, writeData, { merge: true });
    }
    return refreshed;
  });

  return publicWallet(wallet);
});

exports.startMatch = onCall(async (request) => {
  const uid = requireUid(request);
  const matchId = request.data && request.data.matchId;
  if (!validateMatchId(matchId)) {
    throw new HttpsError('invalid-argument', 'Ungültige Spielkennung.');
  }

  const userRef = walletDocument(uid);
  const matchRef = userRef.collection('matchRequests').doc(matchId);
  const today = berlinDateKey();

  const result = await db.runTransaction(async (transaction) => {
    const [userSnapshot, matchSnapshot] = await Promise.all([
      transaction.get(userRef),
      transaction.get(matchRef),
    ]);

    const current = userSnapshot.exists
      ? normalizeWallet(userSnapshot.data(), today)
      : initialWallet(today);
    let wallet = refreshDailyTokens(current, today);

    if (matchSnapshot.exists) {
      // Idempotency: lost responses/retries for the same attempted game do not
      // consume a second token.
      return {
        allowed: true,
        alreadyStarted: true,
        ...publicWallet(wallet),
      };
    }

    let tokenCharged = false;
    let tokenSource = 'unlimited';
    if (!isUnlimited(wallet)) {
      const spend = consumeOneToken(wallet);
      wallet = spend.wallet;
      if (!spend.consumed) {
        const noTokensWrite = {
          ...wallet,
          updatedAt: FieldValue.serverTimestamp(),
        };
        if (!userSnapshot.exists) noTokensWrite.createdAt = FieldValue.serverTimestamp();
        transaction.set(userRef, noTokensWrite, { merge: true });
        return {
          allowed: false,
          reason: 'NO_TOKENS',
          ...publicWallet(wallet),
        };
      }
      tokenCharged = true;
      tokenSource = spend.source;
    }

    const walletWrite = {
      ...wallet,
      updatedAt: FieldValue.serverTimestamp(),
    };
    if (!userSnapshot.exists) walletWrite.createdAt = FieldValue.serverTimestamp();
    transaction.set(userRef, walletWrite, { merge: true });
    transaction.create(matchRef, {
      matchId,
      uid,
      status: 'started',
      tokenCharged,
      tokenSource,
      startedAt: FieldValue.serverTimestamp(),
    });

    return {
      allowed: true,
      alreadyStarted: false,
      ...publicWallet(wallet),
    };
  });

  return result;
});
