import 'dart:math';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'monetization.dart';
import 'localization.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppLocalization.initialize();
  String? firebaseInitializationError;
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: 'AIzaSyBHbpCW_dBzJ4DSbZZYfVbAHcSRjah_XtA',
        appId: '1:773111487498:android:7f76b6f57d2ff9377bd3f3',
        messagingSenderId: '773111487498',
        projectId: 'darts-party-2871c',
        storageBucket: 'darts-party-2871c.firebasestorage.app',
      ),
    );
  } catch (error, stackTrace) {
    firebaseInitializationError = error.toString();
    debugPrint('Firebase initialization failed: $error');
    debugPrintStack(stackTrace: stackTrace);
  }
  runApp(DartPartyApp(firebaseInitializationError: firebaseInitializationError));
}
const categories = ['Easy', 'Medium', 'Hard', 'Legende', 'Unsterblich'];
const categoryPoints = {'Easy': 1, 'Medium': 2, 'Hard': 3, 'Legende': 4, 'Unsterblich': 5};
const purple = Color(0xFFB8A9FF);
const brandGold = Color(0xFFD6B56D);
const appBackground = Color(0xFF10131B);

bool rallyTargetReached(int score, int target) => score >= target;

class ChallengeCard {
  final String id, text, category;
  const ChallengeCard(this.id, this.text, this.category);
}

enum CardState { open, completed, crossed }
class PlayerCard {
  final ChallengeCard card;
  CardState state = CardState.open;
  PlayerCard(this.card);
}
class Player {
  final String name;
  final List<PlayerCard> cards;
  final bool isBot;
  final String botDifficulty;
  int score = 0, turns = 0;
  Player(this.name, List<ChallengeCard> cards, {this.isBot = false, this.botDifficulty = 'Leicht'}) : cards = cards.map(PlayerCard.new).toList();
  // Immer nur die nächsten zwei noch offenen Karten anzeigen.
  List<PlayerCard> get openCards => cards.where((c) => c.state == CardState.open).take(2).toList();
}

class DartThrow {
  final String label;
  final int score, number;
  final String multiplier;
  final bool bull, outerBull, miss;
  const DartThrow(this.label, this.score, {this.number = 0, this.multiplier = 'S', this.bull = false, this.outerBull = false, this.miss = false});
  // Special fields are recognized both by explicit flags (normal app input) and
  // by their label/multiplier (legacy test fixtures and imported throw data).
  bool get isBullseye => bull || (!outerBull && multiplier == 'B' && label.toLowerCase().contains('bullseye'));
  bool get isOuterBull => outerBull || (!bull && multiplier == 'B' && label.toLowerCase().contains('outer bull'));
  bool get triple => multiplier == 'T' && !isBullseye && !isOuterBull;
  bool get doubleHit => multiplier == 'D' && !isBullseye && !isOuterBull;
  bool get single => multiplier == 'S' && number >= 1 && number <= 20 && !isBullseye && !isOuterBull && !miss;
  String get fieldKey => isBullseye ? 'BULL' : isOuterBull ? 'OUTER' : miss ? 'MISS' : '$multiplier$number';
  String get numberKey => (isBullseye || isOuterBull || miss) ? fieldKey : '$number';
}

class DartPartyApp extends StatelessWidget {
  final String? firebaseInitializationError;
  const DartPartyApp({super.key, this.firebaseInitializationError});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
    valueListenable: AppLocalization.language,
    builder: (context, selectedLanguage, _) => MaterialApp(
      title: 'Dart Party',
      debugShowCheckedModeBanner: false,
      locale: Locale(selectedLanguage),
      supportedLocales: const [Locale('de'), Locale('en'), Locale('nl')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.transparent,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C5CFF), brightness: Brightness.dark),
        cardTheme: CardThemeData(color: const Color(0xFF1B2030), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF1B2030), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
      ),
      builder: (context, child) => ColoredBox(
        color: appBackground,
        child: Stack(fit: StackFit.expand, children: [
          IgnorePointer(child: Center(child: Opacity(opacity: 0.045, child: Image.asset('assets/brand/dart_party_logo.png', width: 360, fit: BoxFit.contain)))),
          Column(children: [
            Expanded(child: child ?? const SizedBox.shrink()),
            if (selectedLanguage != 'de')
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                color: appBackground,
                child: const LocalizedText(
                  'Automatische Übersetzung mit Google Translate',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white38, fontSize: 9),
                ),
              ),
          ]),
        ]),
      ),
      home: LanguageSelectionGate(
        child: firebaseInitializationError == null
            ? const FirebaseAuthGate(child: MonetizationStartupGate(child: HomeScreen()))
            : FirebaseInitializationErrorScreen(error: firebaseInitializationError!),
      ),
    ),
  );
}

Future<List<ChallengeCard>> loadCards() async {
  final raw = await rootBundle.loadString('assets/data/dart_challenges_master.csv');
  final lines = raw.split(RegExp(r'\r?\n')).where((e) => e.trim().isNotEmpty).toList();
  final result = <ChallengeCard>[];
  for (var i = 1; i < lines.length; i++) { final f = _parseCsv(lines[i]); if (f.length >= 3 && categories.contains(f[2].trim())) result.add(ChallengeCard(f[0].trim(), f[1].trim(), f[2].trim())); }
  return result;
}
List<String> _parseCsv(String line) { final out=<String>[]; final b=StringBuffer(); var q=false; for(var i=0;i<line.length;i++){final c=line[i]; if(c=='"'){if(q&&i+1<line.length&&line[i+1]=='"'){b.write('"');i++;}else{q=!q;}}else if(c==','&&!q){out.add(b.toString());b.clear();}else{b.write(c);}} out.add(b.toString()); return out; }

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget _menuCard(BuildContext context, {required IconData icon, required String title, required String subtitle, required Widget screen}) =>
      Card(child: ListTile(
        leading: Icon(icon, color: purple, size: 30),
        title: LocalizedText(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: LocalizedText(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      ));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const LocalizedText('Dart Party'),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Center(
            child: ValueListenableBuilder<int>(
              valueListenable: MonetizationService.instance.changes,
              builder: (context, _, __) {
                final service = MonetizationService.instance;
                return Material(
                  color: const Color(0xFF252A37),
                  borderRadius: BorderRadius.circular(24),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(24),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MonetizationScreen())),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const DartTokenIcon(size: 23),
                        const SizedBox(width: 7),
                        LocalizedText(service.unlimitedGames ? '∞' : '${service.totalTokens}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: brandGold)),
                        const SizedBox(width: 3),
                        const Icon(Icons.add_circle_outline, size: 17, color: Colors.white70),
                      ]),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        PopupMenuButton<String>(
          tooltip: AppLocalization.immediate('Konto'),
          icon: const Icon(Icons.account_circle_outlined),
          onSelected: (value) async {
            if (value == 'sign_out') {
              await DartPartyAuth.signOut();
            } else if (value == 'language') {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const LanguagePickerScreen()));
            }
          },
          itemBuilder: (context) => const [
            PopupMenuItem<String>(
              value: 'language',
              child: LocalizedText('Sprache ändern'),
            ),
            PopupMenuItem<String>(
              value: 'sign_out',
              child: LocalizedText('Abmelden'),
            ),
          ],
        ),
      ],
    ),
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 22),
        children: [
          const SizedBox(height: 10),
          Center(child: SizedBox(height: 145, child: Image.asset('assets/brand/dart_party_logo.png', fit: BoxFit.contain))),
          const SizedBox(height: 8),
          const Center(child: LocalizedText('Dein Dartabend. Deine Regeln.', style: TextStyle(color: Colors.white60))),
          const SizedBox(height: 22),
          _menuCard(context, icon: Icons.style, title: 'Kartenjagd', subtitle: 'Jage die Karten und erfülle möglichst viele.', screen: const PlayerSetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.flag, title: 'Kartenrallye', subtitle: 'Erreiche zuerst das Punktziel.', screen: const CardsRallySetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.swap_vert_circle, title: 'Unter / Über 40', subtitle: 'Bleib außerhalb der Grenzen – wer dazwischen landet, scheidet aus.', screen: const UnderOverSetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.sports_score, title: 'Klassisches Spiel', subtitle: '301 oder 501 · Straight, Double oder Master In/Out', screen: const DartsCounterSetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.celebration, title: 'Partymodus', subtitle: '300 Challenges · 30 geheime Bonuskarten', screen: const PartySetupScreen()),
          const SizedBox(height: 10),
          _menuCard(context, icon: Icons.bar_chart, title: 'Spieler-Statistik', subtitle: 'Siege, Spiele und Punkte', screen: const LocalStatsScreen()),
          const SizedBox(height: 22),
          const Center(child: LocalizedText('VERSION 1.5.1', style: TextStyle(color: Colors.white38, letterSpacing: 1.5))),
          const SizedBox(height: 16),
        ],
      ),
    ),
  );
}

class PlayerSetupScreen extends StatefulWidget { const PlayerSetupScreen({super.key}); @override State<PlayerSetupScreen> createState()=>_PlayerSetupScreenState(); }
class _PlayerSetupScreenState extends State<PlayerSetupScreen> {
 final names=[TextEditingController(text:'Spieler 1'),TextEditingController(text:'Spieler 2')]; final List<bool> botPlayers=[false,false]; final List<String> botLevels=['Leicht','Leicht']; bool loading=false; int cardsPerPlayer=10; final Set<String> selectedCategories = Set<String>.from(categories);
 @override void initState(){super.initState();_loadSavedNames();}
 Future<void> _loadSavedNames() async {final prefs=await SharedPreferences.getInstance();final saved=prefs.getStringList('dart_party_player_names');if(saved!=null&&saved.isNotEmpty){for(var i=0;i<saved.length&&i<8;i++){if(i>=names.length){names.add(TextEditingController(text:saved[i]));botPlayers.add(false);botLevels.add('Leicht');}else if(saved[i].trim().isNotEmpty){names[i].text=saved[i];}}if(mounted)setState((){});}}
 @override void dispose(){for(final n in names){n.dispose();}super.dispose();}
 Future<void> start() async {final valid=names.map((e)=>e.text.trim()).toList(); if(valid.length<2 || valid.any((e)=>e.isEmpty)){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:LocalizedText('Bitte für jeden Spieler einen Namen eintragen.')));return;} setState(()=>loading=true); try{final prefs=await SharedPreferences.getInstance();await prefs.setStringList('dart_party_player_names',valid);if(selectedCategories.isEmpty) throw Exception('Bitte mindestens eine Kategorie auswählen.'); final all=(await loadCards()).where((c)=>selectedCategories.contains(c.category)).toList(); if(all.length<cardsPerPlayer) throw Exception('In den gewählten Kategorien gibt es nicht genug Karten.'); final rnd=Random(); final pool=List<ChallengeCard>.from(all)..shuffle(rnd); final sharedCards=pool.take(cardsPerPlayer).toList(); final ps=<Player>[]; for(var i=0;i<valid.length;i++){ps.add(Player(valid[i],sharedCards,isBot:botPlayers[i],botDifficulty:botLevels[i]));} if(!mounted)return; final allowed=await MonetizationService.instance.authorizeGameStart(context); if(!allowed||!mounted)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>CardHuntScreen(players:ps, cardsPerPlayer:cardsPerPlayer)));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:LocalizedText('Fehler: $e')));}finally{if(mounted)setState(()=>loading=false);} }
 void showRules(){showDialog(context:context,builder:(context)=>AlertDialog(title:const LocalizedText('Spielregeln – Kartenjagd'),content:const SingleChildScrollView(child:LocalizedText('1. Der Moderator wählt Kartenanzahl und Kategorien. Jeder Spieler erhält exakt dieselben Karten in derselben Reihenfolge.\n\n2. Es sind immer nur die nächsten zwei offenen Karten sichtbar.\n\n3. Pro Zug werden genau drei Darts geworfen. Danach prüft die App nur diese beiden Karten.\n\n4. Ist mindestens eine Karte erfüllt, muss eine erfüllte Karte gewertet werden. Sind beide erfüllt, darf eine davon ausgewählt werden. Punkte: Easy 1, Medium 2, Hard 3, Legende 4, Unsterblich 5.\n\n5. Ist keine Karte erfüllt, muss eine der beiden Karten endgültig gestrichen werden. Sie zählt null Punkte.\n\n6. Die andere Karte bleibt liegen und die nächste Karte rückt nach. So sind wieder höchstens zwei Karten sichtbar.\n\n7. Danach ist der nächste Spieler an der Reihe. Nach Verarbeitung aller Karten gewinnt die höchste Punktzahl.'),),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const LocalizedText('Schließen'))]));}
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const LocalizedText('Spieler festlegen')),
  body:SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
   Row(children:[const Expanded(child:LocalizedText('KARTENJAGD',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900))),IconButton(tooltip:AppLocalization.immediate('Spielregeln'),icon:const Icon(Icons.help_outline),onPressed:showRules)]),
   const SizedBox(height:6),const LocalizedText('Spieler eintragen und Spielumfang festlegen.',style:TextStyle(color:Colors.white60)),
   const SizedBox(height:10),
   DropdownButtonFormField<int>(initialValue:cardsPerPlayer,decoration:const InputDecoration(label: LocalizedText('Karten pro Spieler')),items:[3,4,5,7,10].map((n)=>DropdownMenuItem(value:n,child:LocalizedText('$n Karten · $n Züge'))).toList(),onChanged:loading?null:(v)=>setState(()=>cardsPerPlayer=v??10)),
   const SizedBox(height:18),const LocalizedText('NUR KARTEN AUS FOLGENDEN KATEGORIEN',style:TextStyle(fontWeight:FontWeight.bold,fontSize:12,letterSpacing:.5)),const SizedBox(height:6),
   Wrap(spacing:7,runSpacing:2,children:categories.map((cat)=>FilterChip(label:LocalizedText(cat),selected:selectedCategories.contains(cat),onSelected:loading?null:(on)=>setState(()=>on?selectedCategories.add(cat):selectedCategories.remove(cat)))).toList()),
   const SizedBox(height:18),
   ...List.generate(names.length,(i)=>Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Expanded(child:TextField(controller:names[i],decoration:InputDecoration(label: LocalizedText('Spieler ${i+1}')))),if(names.length>2)IconButton(onPressed:()=>setState((){names.removeAt(i).dispose();botPlayers.removeAt(i);botLevels.removeAt(i);}),icon:const Icon(Icons.close))]),
    const SizedBox(height:6),
    Row(children:[Expanded(child:DropdownButtonFormField<bool>(initialValue:botPlayers[i],decoration:const InputDecoration(label: LocalizedText('Spielertyp')),items:const [DropdownMenuItem(value:false,child:LocalizedText('Mensch')),DropdownMenuItem(value:true,child:LocalizedText('Bot'))],onChanged:loading?null:(v)=>setState(()=>botPlayers[i]=v??false))),if(botPlayers[i])const SizedBox(width:8),if(botPlayers[i])Expanded(child:DropdownButtonFormField<String>(initialValue:botLevels[i],decoration:const InputDecoration(label: LocalizedText('Bot-Stärke')),items:const ['Ultra leicht','Leicht','Mittel','Hart','Experte'].map((v)=>DropdownMenuItem(value:v,child:LocalizedText(v))).toList(),onChanged:loading?null:(v)=>setState(()=>botLevels[i]=v??'Leicht')))])
   ]))),
   OutlinedButton.icon(onPressed:names.length>=8?null:()=>setState((){names.add(TextEditingController(text:'Spieler ${names.length+1}'));botPlayers.add(false);botLevels.add('Leicht');}),icon:const Icon(Icons.add),label:const LocalizedText('Spieler hinzufügen')),
   const SizedBox(height:24),FilledButton.icon(onPressed:loading?null:start,icon:const Icon(Icons.play_arrow),label:LocalizedText(loading?'Karten werden gemischt …':'Spiel starten'))
  ])));

}

class CardsRallySetupScreen extends StatefulWidget {
  const CardsRallySetupScreen({super.key});
  @override
  State<CardsRallySetupScreen> createState() => _CardsRallySetupScreenState();
}

class _CardsRallySetupScreenState extends State<CardsRallySetupScreen> {
  final List<TextEditingController> names = [TextEditingController(text: 'Spieler 1'), TextEditingController(text: 'Spieler 2')];
  final List<bool> botPlayers = [false, false];
  final List<String> botLevels = ['Leicht', 'Leicht'];
  final Set<String> selectedCategories = Set<String>.from(categories);
  final List<int> targetOptions = const [20, 30, 40, 50, 60, 75, 100, 150, 200, 300, 500];
  int targetScore = 50;
  bool loading = false;

  @override
  void initState() { super.initState(); _loadSavedNames(); }
  Future<void> _loadSavedNames() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dart_party_player_names');
    if (saved == null || saved.isEmpty) return;
    for (var i = 0; i < saved.length && i < 8; i++) {
      if (i >= names.length) { names.add(TextEditingController(text: saved[i])); botPlayers.add(false); botLevels.add('Leicht'); }
      else if (saved[i].trim().isNotEmpty) names[i].text = saved[i];
    }
    if (mounted) setState(() {});
  }
  @override
  void dispose() { for (final name in names) { name.dispose(); } super.dispose(); }
  void _showRules() => showDialog<void>(context: context, builder: (context) => AlertDialog(
    title: const LocalizedText('Spielregeln – Kartenrallye'),
    content: const SingleChildScrollView(child: LocalizedText(
      '1. Der Moderator legt das Punktziel fest. Jeder Spieler erhält dieselben Karten in derselben Reihenfolge.\n\n'
      '2. Es sind immer nur die nächsten zwei offenen Karten sichtbar.\n\n'
      '3. Pro Zug werden drei Darts geworfen. Die App prüft danach die beiden sichtbaren Karten.\n\n'
      '4. Ist mindestens eine Karte erfüllt, muss eine erfüllte Karte gewertet werden. Sind beide erfüllt, darf eine davon gewählt werden.\n\n'
      '5. Ist keine Karte erfüllt, muss eine Karte endgültig gestrichen werden.\n\n'
      '6. Die andere Karte bleibt liegen und die nächste rückt nach. Danach ist der nächste Spieler an der Reihe.\n\n'
      '7. Wer zuerst das Punktziel erreicht oder überschreitet, gewinnt sofort. Die Karten bringen je nach Kategorie 1 bis 5 Punkte.'
    )),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))],
  ));

  Future<void> _start() async {
    final playerNames = names.map((e) => e.text.trim()).toList();
    if (playerNames.length < 2 || playerNames.any((e) => e.isEmpty) || playerNames.toSet().length != playerNames.length) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: LocalizedText('Bitte mindestens zwei unterschiedliche Spielernamen eintragen.')));
      return;
    }
    if (selectedCategories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: LocalizedText('Bitte mindestens eine Kartenkategorie auswählen.')));
      return;
    }
    setState(() => loading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('dart_party_player_names', playerNames);
      final all = (await loadCards()).where((card) => selectedCategories.contains(card.category)).toList();
      final possiblePoints = all.fold<int>(0, (sum, card) => sum + (categoryPoints[card.category] ?? 0));
      if (possiblePoints < targetScore) throw Exception('Mit den gewählten Kategorien sind maximal $possiblePoints Punkte möglich. Wähle weitere Kategorien oder ein niedrigeres Ziel.');
      all.shuffle(Random());
      final players = List.generate(playerNames.length, (i) => Player(playerNames[i], all, isBot: botPlayers[i], botDifficulty: botLevels[i]));
      if (!mounted) return;
      final allowed = await MonetizationService.instance.authorizeGameStart(context);
      if (!allowed || !mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CardRallyScreen(players: players, targetScore: targetScore)));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: LocalizedText('Kartenrallye konnte nicht gestartet werden: $error')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _addPlayer() => setState(() { names.add(TextEditingController(text: 'Spieler ${names.length + 1}')); botPlayers.add(false); botLevels.add('Leicht'); });
  void _removePlayer(int index) => setState(() { names.removeAt(index).dispose(); botPlayers.removeAt(index); botLevels.removeAt(index); });

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const LocalizedText('Kartenrallye – Spieler')),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [const Expanded(child: LocalizedText('KARTENRALLY', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1))), IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: _showRules)]),
      const LocalizedText('Kein Kartenlimit: Wer zuerst das Ziel erreicht, gewinnt.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      DropdownButtonFormField<int>(initialValue: targetScore, decoration: const InputDecoration(label: LocalizedText('Zielpunktzahl')), items: targetOptions.map((value) => DropdownMenuItem(value: value, child: LocalizedText('$value Punkte'))).toList(), onChanged: loading ? null : (value) => setState(() => targetScore = value ?? 50)),
      const SizedBox(height: 18),
      const LocalizedText('KARTENKATEGORIEN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: .6)),
      const SizedBox(height: 7),
      Wrap(spacing: 7, runSpacing: 2, children: categories.map((category) => FilterChip(label: LocalizedText('$category · ${categoryPoints[category]} P'), selected: selectedCategories.contains(category), onSelected: loading ? null : (selected) => setState(() { if (selected) { selectedCategories.add(category); } else { selectedCategories.remove(category); } }))).toList()),
      const SizedBox(height: 8),
      LocalizedText('Alle Karten der gewählten Kategorien werden als identischer Stapel für jeden Spieler verwendet.', style: const TextStyle(color: Colors.white54, fontSize: 12)),
      const SizedBox(height: 18),
      ...List.generate(names.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: TextField(controller: names[i], decoration: InputDecoration(label: LocalizedText('Spieler ${i + 1}')))), if (names.length > 2) IconButton(onPressed: loading ? null : () => _removePlayer(i), icon: const Icon(Icons.close))]),
        const SizedBox(height: 6),
        Row(children: [
          Expanded(child: DropdownButtonFormField<bool>(initialValue: botPlayers[i], decoration: const InputDecoration(label: LocalizedText('Spielertyp')), items: const [DropdownMenuItem(value: false, child: LocalizedText('Mensch')), DropdownMenuItem(value: true, child: LocalizedText('Bot'))], onChanged: loading ? null : (value) => setState(() => botPlayers[i] = value ?? false))),
          if (botPlayers[i]) const SizedBox(width: 8),
          if (botPlayers[i]) Expanded(child: DropdownButtonFormField<String>(initialValue: botLevels[i], decoration: const InputDecoration(label: LocalizedText('Bot-Stärke')), items: const ['Ultra leicht', 'Leicht', 'Mittel', 'Hart', 'Experte'].map((level) => DropdownMenuItem(value: level, child: LocalizedText(level))).toList(), onChanged: loading ? null : (value) => setState(() => botLevels[i] = value ?? 'Leicht'))),
        ]),
      ]))),
      OutlinedButton.icon(onPressed: loading || names.length >= 8 ? null : _addPlayer, icon: const Icon(Icons.add), label: const LocalizedText('Spieler hinzufügen')),
      const SizedBox(height: 22),
      FilledButton.icon(onPressed: loading ? null : _start, icon: const Icon(Icons.flag), label: LocalizedText(loading ? 'Karten werden vorbereitet …' : 'Kartenrallye starten')),
    ])),
  );
}

class CardRallyScreen extends StatefulWidget {
  final List<Player> players;
  final int targetScore;
  const CardRallyScreen({super.key, required this.players, required this.targetScore});
  @override
  State<CardRallyScreen> createState() => _CardRallyScreenState();
}

class _CardRallyScreenState extends State<CardRallyScreen> {
  int playerIndex = 0;
  final List<DartThrow> darts = [];
  bool submitted = false;
  bool botBusy = false;
  bool gameOver = false;
  Player get player => widget.players[playerIndex];
  int get total => darts.fold(0, (sum, dart) => sum + dart.score);
  int get turn => player.turns + 1;
  List<PlayerCard> get fulfilled => player.openCards.where((card) => evaluateCard(card.card.text, darts)).toList();

  @override
  void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded()); }

  void _startBotIfNeeded() { if (!mounted || gameOver || botBusy || submitted || !player.isBot) return; botBusy = true; _playBotTurn(); }

  Future<void> _playBotTurn() async {
    final bot = player;
    final expectedIndex = playerIndex;
    bool sameTurn() => mounted && !gameOver && playerIndex == expectedIndex && identical(player, bot) && !submitted;
    await Future.delayed(const Duration(milliseconds: 650));
    for (var i = 0; i < 3; i++) {
      if (!sameTurn()) { botBusy = false; return; }
      setState(() => darts.add(_botThrow(bot.botDifficulty)));
      await Future.delayed(const Duration(milliseconds: 420));
    }
    if (!mounted || playerIndex != expectedIndex || !identical(player, bot)) { botBusy = false; return; }
    setState(() => submitted = true);
    await Future.delayed(const Duration(milliseconds: 750));
    if (!mounted || playerIndex != expectedIndex || !identical(player, bot)) { botBusy = false; return; }
    final choices = bot.openCards.where((card) => evaluateCard(card.card.text, darts)).toList()..sort((a, b) => (categoryPoints[b.card.category] ?? 0).compareTo(categoryPoints[a.card.category] ?? 0));
    final selected = choices.isNotEmpty ? choices.first : (bot.openCards.isEmpty ? null : bot.openCards.first);
    botBusy = false;
    if (selected != null) _finishCard(selected, completed: choices.isNotEmpty);
  }

  void _addDart(DartThrow dart) { if (darts.length >= 3 || submitted) return; setState(() { darts.add(dart); if (darts.length == 3) submitted = true; }); }
  void _undoDart() { if (darts.isEmpty || submitted) return; setState(() => darts.removeLast()); }
  void _resetDarts() { setState(() { darts.clear(); submitted = false; }); }

  void _finishCard(PlayerCard card, {required bool completed}) {
    setState(() {
      card.state = completed ? CardState.completed : CardState.crossed;
      if (completed) player.score += categoryPoints[card.card.category] ?? 0;
      player.turns++;
      darts.clear();
      submitted = false;
      if (completed && rallyTargetReached(player.score, widget.targetScore)) {
        gameOver = true;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ResultsScreen(players: widget.players, resultMessage: '${player.name} hat zuerst ${widget.targetScore} Punkte erreicht.')));
        return;
      }
      final nextPlayer = List<int>.generate(widget.players.length, (i) => (playerIndex + i + 1) % widget.players.length).firstWhere(
        (i) => widget.players[i].cards.any((entry) => entry.state == CardState.open),
        orElse: () => -1,
      );
      if (nextPlayer == -1) {
        gameOver = true;
        final highest = widget.players.map((entry) => entry.score).reduce((a, b) => a > b ? a : b);
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ResultsScreen(players: widget.players, resultMessage: 'Das Ziel von ${widget.targetScore} Punkten wurde nicht erreicht. Höchster Stand: $highest Punkte.')));
      } else {
        playerIndex = nextPlayer;
      }
    });
    if (mounted) WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
  }

  @override
  Widget build(BuildContext context) {
    final matches = submitted ? fulfilled : <PlayerCard>[];
    final progress = (player.score / widget.targetScore).clamp(0.0, 1.0).toDouble();
    return Scaffold(
      appBar: AppBar(title: const LocalizedText('Kartenrallye'), actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: LocalizedText('${player.score}/${widget.targetScore} P', style: const TextStyle(color: brandGold, fontWeight: FontWeight.w900, fontSize: 16))))]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 24), children: [
        Row(children: [Expanded(child: LocalizedText(player.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))), LocalizedText('Zug $turn', style: const TextStyle(color: Colors.white60))]),
        const SizedBox(height: 4),
        LocalizedText('Spieler ${playerIndex + 1} von ${widget.players.length}', style: const TextStyle(color: Colors.white54)),
        const SizedBox(height: 10),
        DartPartyCardSurface(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Expanded(child: LocalizedText('PUNKTE BIS ZUM ZIEL', style: TextStyle(color: brandGold, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: .8))), LocalizedText('${player.score} / ${widget.targetScore}', style: const TextStyle(fontWeight: FontWeight.w900, color: brandGold))]),
          const SizedBox(height: 9),
          ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: Colors.white12, valueColor: const AlwaysStoppedAnimation<Color>(brandGold))),
        ])),
        const SizedBox(height: 8),
        DartPartyCardSurface(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const LocalizedText('SPIELSTAND', style: TextStyle(color: brandGold, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .8)),
          const SizedBox(height: 4),
          ...widget.players.map((entry) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [
            Expanded(child: LocalizedText('${entry.name}${entry.isBot ? ' · BOT' : ''}', style: TextStyle(fontWeight: identical(entry, player) ? FontWeight.w900 : FontWeight.normal, color: identical(entry, player) ? Colors.white : Colors.white70))),
            LocalizedText('${entry.score} P', style: TextStyle(color: identical(entry, player) ? brandGold : Colors.white70, fontWeight: FontWeight.w800)),
          ]))),
        ])),
        const SizedBox(height: 14),
        if (!submitted) ...[
          _DartProgress(darts: darts, total: total, onUndo: _undoDart, onReset: _resetDarts),
          const SizedBox(height: 10),
          if (!player.isBot) DartEntry(onChanged: _addDart, disabled: darts.length >= 3) else const Card(child: Padding(padding: EdgeInsets.all(14), child: LocalizedText('Bot wirft automatisch …', style: TextStyle(color: Colors.white60)))),
          const SizedBox(height: 14),
          const LocalizedText('DIE ZWEI OFFENEN KARTEN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8)),
          const SizedBox(height: 7),
          CardPairLayout(cards: player.openCards, itemBuilder: (card) => ChallengeTile(item: card)),
        ] else ...[
          DartPartyCardSurface(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const LocalizedText('DEINE DREI WÜRFE', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
            const SizedBox(height: 7),
            LocalizedText(darts.map((dart) => dart.label).join('   ·   '), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 5),
            LocalizedText('Gesamt: $total Punkte', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: brandGold)),
          ])),
          const SizedBox(height: 12),
          if (player.isBot) ...[
            const Center(child: Padding(padding: EdgeInsets.all(12), child: LocalizedText('Bot wertet seinen Zug aus …', style: TextStyle(color: Colors.white60)))),
          ] else if (matches.isNotEmpty) ...[
            LocalizedText(matches.length == 1 ? 'KARTE ERFÜLLT' : '${matches.length} KARTEN ERFÜLLT – WÄHLE EINE', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.greenAccent)),
            const SizedBox(height: 7),
            CardPairLayout(cards: matches, itemBuilder: (card) => ChallengeTile(item: card, actionLabel: 'Werten +${categoryPoints[card.card.category]} P', action: () => _finishCard(card, completed: true))),
          ] else ...[
            const LocalizedText('KEINE KARTE ERFÜLLT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent)),
            const SizedBox(height: 4),
            const LocalizedText('Wähle eine Karte zum endgültigen Streichen.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 7),
            CardPairLayout(cards: player.openCards, itemBuilder: (card) => ChallengeTile(item: card, actionLabel: 'Streichen', action: () => _finishCard(card, completed: false))),
          ],
          const SizedBox(height: 10),
          if (!player.isBot) OutlinedButton.icon(onPressed: _resetDarts, icon: const Icon(Icons.refresh), label: const LocalizedText('Würfe neu eingeben')),
        ],
      ])),
    );
  }
}

class CardHuntScreen extends StatefulWidget {
  final List<Player> players;
  final int cardsPerPlayer;
  const CardHuntScreen({super.key, required this.players, required this.cardsPerPlayer});
  @override
  State<CardHuntScreen> createState() => _CardHuntScreenState();
}

class _CardHuntScreenState extends State<CardHuntScreen> {
  int playerIndex = 0;
  final List<DartThrow> darts = [];
  bool submitted = false;
  bool botBusy = false;
  @override void initState(){super.initState();WidgetsBinding.instance.addPostFrameCallback((_)=>_startBotIfNeeded());}
  void _startBotIfNeeded(){if(!mounted || botBusy || submitted || !player.isBot)return;botBusy=true;_playBotTurn();}
  Future<void> _playBotTurn() async {
    final bot=player; final expectedIndex=playerIndex;
    await Future.delayed(const Duration(milliseconds:700));
    for(var i=0;i<3;i++){if(!mounted || playerIndex!=expectedIndex || player!=bot)return; final dart=_botThrow(bot.botDifficulty); setState(()=>darts.add(dart)); await Future.delayed(const Duration(milliseconds:450));}
    if(!mounted || playerIndex!=expectedIndex || player!=bot)return;
    setState(()=>submitted=true); await Future.delayed(const Duration(milliseconds:900));
    if(!mounted || playerIndex!=expectedIndex || player!=bot)return;
    final choices=bot.openCards.where((c)=>evaluateCard(c.card.text,darts)).toList()..sort((a,b)=>(categoryPoints[b.card.category]??0).compareTo(categoryPoints[a.card.category]??0));
    final selected=choices.isNotEmpty?choices.first:(bot.openCards.isNotEmpty?bot.openCards[Random().nextInt(bot.openCards.length)]:null);
    botBusy=false; if(selected!=null)finish(selected,completed:choices.isNotEmpty);
  }
  Player get player => widget.players[playerIndex];
  int get total => darts.fold(0, (sum, dart) => sum + dart.score);
  int get turn => player.turns + 1;
  List<PlayerCard> get fulfilled => player.openCards.where((c) => evaluateCard(c.card.text, darts)).toList();

  void addDart(DartThrow dart) {
    if (darts.length >= 3 || submitted) return;
    setState(() {
      darts.add(dart);
      if (darts.length == 3) submitted = true;
    });
  }

  void undoDart() {
    if (darts.isEmpty || submitted) return;
    setState(() => darts.removeLast());
  }

  void resetDarts() {
    setState(() { darts.clear(); submitted = false; });
  }

  void finish(PlayerCard card, {required bool completed}) {
    setState(() {
      card.state = completed ? CardState.completed : CardState.crossed;
      if (completed) player.score += categoryPoints[card.card.category] ?? 0;
      player.turns++;
      darts.clear();
      submitted = false;

      // Nach jeder gewerteten oder gestrichenen Karte ist der nächste Spieler dran.
      // Spieler mit bereits 10 absolvierten Zügen werden übersprungen.
      final nextPlayer = List<int>.generate(widget.players.length, (i) => (playerIndex + i + 1) % widget.players.length)
          .firstWhere(
            (i) => widget.players[i].turns < widget.cardsPerPlayer,
            orElse: () => -1,
          );

      if (nextPlayer == -1) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => ResultsScreen(players: widget.players)),
        );
      } else {
        playerIndex = nextPlayer;
      }
    });
    if(mounted) WidgetsBinding.instance.addPostFrameCallback((_)=>_startBotIfNeeded());
  }

  @override
  Widget build(BuildContext context) {
    final matches = submitted ? fulfilled : <PlayerCard>[];
    return Scaffold(
      appBar: AppBar(
        title: const LocalizedText('Kartenjagd'),
        actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: LocalizedText('${player.score} P', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))))],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
          children: [
            Row(children: [Expanded(child: LocalizedText(player.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))), LocalizedText('Runde $turn / ${widget.cardsPerPlayer}', style: const TextStyle(color: Colors.white60))]),
            const SizedBox(height: 4),
            LocalizedText('Spieler ${playerIndex + 1} von ${widget.players.length} · ${player.openCards.length} Karten in der Auswahl', style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 14),
            if (!submitted) ...[
              _DartProgress(darts: darts, total: total, onUndo: undoDart, onReset: resetDarts),
              const SizedBox(height: 10),
              if(!player.isBot) DartEntry(onChanged: addDart, disabled: darts.length >= 3) else const Card(child:Padding(padding:EdgeInsets.all(14),child:LocalizedText('Bot wirft automatisch …',style:TextStyle(color:Colors.white60)))),
              const SizedBox(height: 16),
              const LocalizedText('DEINE KARTEN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
              const SizedBox(height: 7),
              CardPairLayout(cards: player.openCards, itemBuilder: (card) => ChallengeTile(item: card)),
            ] else ...[
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const LocalizedText('DEINE DREI WÜRFE', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
                const SizedBox(height: 7),
                LocalizedText(darts.map((d) => d.label).join('   ·   '), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 5),
                LocalizedText('Gesamt: $total Punkte', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: purple)),
              ]))),
              const SizedBox(height: 12),
              if(player.isBot) ...[
                const Center(child:Padding(padding:EdgeInsets.all(12),child:LocalizedText('Bot wertet seinen Zug aus …',style:TextStyle(color:Colors.white60))))
              ] else if (matches.isNotEmpty) ...[
                LocalizedText(matches.length == 1 ? 'KARTE ERFÜLLT' : '${matches.length} KARTEN ERFÜLLT – WÄHLE EINE', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.greenAccent)),
                const SizedBox(height: 7),
                CardPairLayout(cards: matches, itemBuilder: (card) => ChallengeTile(item: card, actionLabel: 'Werten +${categoryPoints[card.card.category]} P', action: () => finish(card, completed: true))),
              ] else ...[
                const LocalizedText('KEINE KARTE ERFÜLLT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent)),
                const SizedBox(height: 4),
                const LocalizedText('Keine der beiden Karten geschafft. Wähle eine Karte zum endgültigen Streichen.', style: TextStyle(color: Colors.white60)),
                const SizedBox(height: 7),
                CardPairLayout(cards: player.openCards, itemBuilder: (card) => ChallengeTile(item: card, actionLabel: 'Streichen', action: () => finish(card, completed: false))),
              ],
              const SizedBox(height: 10),
              if(!player.isBot) OutlinedButton.icon(onPressed: resetDarts, icon: const Icon(Icons.refresh), label: const LocalizedText('Würfe neu eingeben')),
            ],
          ],
        ),
      ),
    );
  }
}

class _DartProgress extends StatelessWidget {
  final List<DartThrow> darts;
  final int total;
  final VoidCallback? onUndo, onReset;
  final String completionText;
  const _DartProgress({required this.darts, required this.total, required this.onUndo, required this.onReset, this.completionText = 'Alle drei Würfe eingegeben – Karten werden geprüft.'});

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Expanded(child: LocalizedText('BISHER IN DIESEM ZUG', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))), LocalizedText('$total PUNKTE', style: const TextStyle(color: purple, fontWeight: FontWeight.w900, fontSize: 20))]),
    const SizedBox(height: 9),
    Row(children: List.generate(3, (i) => Expanded(child: Container(margin: EdgeInsets.only(right: i == 2 ? 0 : 7), padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4), decoration: BoxDecoration(color: i < darts.length ? purple.withOpacity(.20) : const Color(0xFF10131B), borderRadius: BorderRadius.circular(10), border: Border.all(color: i < darts.length ? purple : Colors.white12)), child: Column(children: [LocalizedText('DART ${i + 1}', style: const TextStyle(fontSize: 10, color: Colors.white60)), const SizedBox(height: 3), LocalizedText(i < darts.length ? darts[i].label : '—', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))]))))),
    const SizedBox(height: 7),
    Row(mainAxisAlignment: MainAxisAlignment.end, children: [TextButton.icon(onPressed: darts.isEmpty ? null : onUndo, icon: const Icon(Icons.undo, size: 17), label: const LocalizedText('Letzten zurück')), TextButton(onPressed: darts.isEmpty ? null : onReset, child: const LocalizedText('Alle löschen'))]),
    LocalizedText(darts.length == 3 ? completionText : 'Bitte Dart ${darts.length + 1} eingeben.', style: const TextStyle(color: Colors.white54, fontSize: 12)),
  ])));
}

class DartEntry extends StatefulWidget {
  final ValueChanged<DartThrow> onChanged;
  final bool disabled;
  const DartEntry({super.key, required this.onChanged, this.disabled = false});
  @override
  State<DartEntry> createState() => _DartEntryState();
}

class _DartEntryState extends State<DartEntry> {
  String multiplier = 'S';

  Widget specialButton(String label, DartThrow dart) => Expanded(child: OutlinedButton(onPressed: widget.disabled ? null : () => widget.onChanged(dart), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 12)), child: LocalizedText(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))));

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(11), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const LocalizedText('Ein Eingabefeld für alle drei Darts', style: TextStyle(color: Colors.white60, fontSize: 12)),
    const SizedBox(height: 8),
    Row(children: [for (final item in const [('S', 'Single'), ('D', 'Double'), ('T', 'Triple')]) Expanded(child: Padding(padding: const EdgeInsets.only(right: 5), child: ChoiceChip(label: LocalizedText(item.$2), selected: multiplier == item.$1, onSelected: widget.disabled ? null : (_) => setState(() => multiplier = item.$1))))]),
    const SizedBox(height: 7),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 5, mainAxisSpacing: 5, crossAxisSpacing: 5, childAspectRatio: 1.85, children: List.generate(20, (index) {
      final number = index + 1;
      final factor = multiplier == 'S' ? 1 : multiplier == 'D' ? 2 : 3;
      return FilledButton.tonal(onPressed: widget.disabled ? null : () => widget.onChanged(DartThrow('$multiplier $number', number * factor, number: number, multiplier: multiplier)), style: FilledButton.styleFrom(padding: EdgeInsets.zero), child: LocalizedText('$number'));
    })),
    const SizedBox(height: 7),
    Row(children: [specialButton('Fehlwurf\n0', const DartThrow('Fehlwurf', 0, miss: true)), const SizedBox(width: 5), specialButton('Outer Bull\n25', const DartThrow('Outer Bull', 25, outerBull: true)), const SizedBox(width: 5), specialButton('Bullseye\n50', const DartThrow('Bullseye', 50, bull: true))]),
  ])));
}

// Simuliert drei echte Treffer mit zunehmender Zielgenauigkeit je Bot-Stufe.
DartThrow _botThrow(String level){
  final rng=Random();
  final accuracy=switch(level){'Ultra leicht'=>0.10,'Leicht'=>0.24,'Mittel'=>0.42,'Hart'=>0.60,'Experte'=>0.76,_=>0.24};
  final missChance=switch(level){'Ultra leicht'=>0.24,'Leicht'=>0.12,'Mittel'=>0.07,'Hart'=>0.035,'Experte'=>0.015,_=>0.12};
  if(rng.nextDouble()<missChance)return const DartThrow('Fehlwurf',0,miss:true);
  // Experten zielen überwiegend auf T20; schwächere Bots streuen stärker über das Board.
  final target=rng.nextDouble()<accuracy?20:(rng.nextInt(20)+1);
  final roll=rng.nextDouble();
  if(level=='Experte'){
    if(roll<0.14)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.64)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.70)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else if(level=='Hart'){
    if(roll<0.28)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.63)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.82)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else if(level=='Mittel'){
    if(roll<0.14)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.65)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.80)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else if(level=='Leicht'){
    if(roll<0.06)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.72)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.82)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }else{
    if(roll<0.02)return DartThrow('T $target',target*3,number:target,multiplier:'T');
    if(roll<0.66)return DartThrow('S $target',target,number:target,multiplier:'S');
    if(roll<0.74)return DartThrow('D $target',target*2,number:target,multiplier:'D');
  }
  if(rng.nextDouble()<0.35)return const DartThrow('Outer Bull',25,outerBull:true);
  if(rng.nextDouble()<0.12)return const DartThrow('Bullseye',50,bull:true);
  return DartThrow('S $target',target,number:target,multiplier:'S');
}

// Conservative rule engine: it evaluates the wording of the master cards. Unknown wording
// deliberately does not produce a false positive; the rule can be added without changing the UI.
bool evaluateCard(String raw,List<DartThrow> d){if(d.length!=3)return false;final t=raw.toLowerCase().replaceAll('ä','ae').replaceAll('ö','oe').replaceAll('ü','ue');final sum=d.fold<int>(0,(s,x)=>s+x.score);final triples=d.where((x)=>x.triple).length;final doubles=d.where((x)=>x.doubleHit).length;final bulls=d.where((x)=>x.isBullseye).length;final outer=d.where((x)=>x.isOuterBull).length;final singles=d.where((x)=>x.single).length;final nums=d.map((x)=>x.numberKey).toSet();
 int? minScore=RegExp(r'mindestens\s+(\d+)\s+punkte').firstMatch(t)!=null?int.parse(RegExp(r'mindestens\s+(\d+)\s+punkte').firstMatch(t)!.group(1)!):null;
 int? exactScore=RegExp(r'genau\s+(\d+)(?:\s+punkte)?').firstMatch(t)!=null?int.parse(RegExp(r'genau\s+(\d+)(?:\s+punkte)?').firstMatch(t)!.group(1)!):null;
 if(minScore!=null&&sum<minScore)return false;if(exactScore!=null&&sum!=exactScore)return false;
 if(t.contains('ohne ein triple')||t.contains('ohne triple'))if(triples>0)return false;
 if(t.contains('ohne bullseye')||t.contains('ohne das bullseye'))if(bulls>0)return false;
 if(t.contains('ohne ein doppelfeld oder triple-feld')||t.contains('ohne ein doppelfeld oder triple'))if(doubles+triples>0)return false;
 if(t.contains('ausschliesslich einfache zahlenfelder')||t.contains('ausschliesslich einfache zahlenfelder treffen')||t.contains('nur einfache zahlenfelder'))if(d.any((x)=>!x.single))return false;
 if(t.contains('ausschliesslich single- und double-felder'))if(d.any((x)=>!(x.single||x.doubleHit)))return false;
 if(t.contains('ausschliesslich triple-felder oder bullseye'))if(d.any((x)=>!(x.triple||x.isBullseye)))return false;
 final maxD=RegExp(r'hoechstens (\w+) doppelfeld').firstMatch(t);if(maxD!=null&&doubles>_wordNum(maxD.group(1)!))return false;
 final exactOneTriple=t.contains('genau einem triple');if(exactOneTriple&&triples!=1)return false;
 if(t.contains('mindestens drei unterschiedliche zahlenfelder')&&nums.length<3)return false;
 if(t.contains('mindestens drei unterschiedliche einfache zahlenfelder')&&d.where((x)=>x.single).map((x)=>x.number).toSet().length<3)return false;
 if(t.contains('jeder dart ein anderes zahlenfeld')&&nums.length<3)return false;
 if(t.contains('ohne dreimal dasselbe feld')&&d.map((x)=>x.fieldKey).toSet().length==1)return false;
 if(t.contains('ohne dreimal dasselbe zahlenfeld')&&nums.length==1)return false;
 if(t.contains('mindestens zwei unterschiedliche zahlenfelder')&&nums.length<2)return false;
 if(t.contains('mindestens zwei unterschiedliche doubles oder triples')){if(d.where((x)=>x.doubleHit||x.triple).map((x)=>x.fieldKey).toSet().length<2)return false;}
 if(t.contains('mindestens zwei verschiedene doubles oder triples')){if(d.where((x)=>x.doubleHit||x.triple).map((x)=>x.fieldKey).toSet().length<2)return false;}
 // Both wordings mean two hits on different numbers.
 final distinctDoublesRequired =
     t.contains('zwei unterschiedliche doubles') ||
     t.contains('zwei verschiedene doubles') ||
     t.contains('zweimal unterschiedliche doubles') ||
     t.contains('zweimal verschiedene doubles') ||
     t.contains('zweimal unterschiedliche double') ||
     t.contains('zweimal verschiedene double');
 if (distinctDoublesRequired &&
     d.where((x) => x.doubleHit).map((x) => x.number).toSet().length < 2) return false;

 final distinctTriplesRequired =
     t.contains('zwei unterschiedliche triples') ||
     t.contains('zwei verschiedene triples') ||
     t.contains('zweimal unterschiedliche triples') ||
     t.contains('zweimal verschiedene triples') ||
     t.contains('zweimal unterschiedliche triple') ||
     t.contains('zweimal verschiedene triple');
 if (distinctTriplesRequired &&
     d.where((x) => x.triple).map((x) => x.number).toSet().length < 2) return false;
 if(t.contains('zwei unterschiedliche einfache zahlenfelder')||t.contains('zwei unterschiedliche einfache zahlen'))if(d.where((x)=>x.single).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('mindestens zwei darts triple-felder'))if(triples<2)return false;
 if(t.contains('mindestens zwei triple-felder'))if(triples<2)return false;
 if(t.contains('mindestens ein triple-feld'))if(triples<1)return false;
 if(t.contains('mindestens zweimal ein doppelfeld')){if(doubles<2)return false;}
 if(t.contains('mindestens zweimal ein triple-feld')){if(triples<2)return false;}
 // Count generic Single hits by multiplier, not only by the exact card wording.
 // Card 139 says „mindestens zweimal ein einfaches Zahlenfeld“; Double/Triple
 // hits on numbered segments must never be counted as Single hits.
 final atLeastTwoSingles = RegExp(
   r'mindestens\s+(?:zweimal|zwei|2)\s+(?:ein\s+)?(?:beliebiges\s+)?(?:einfach(?:es|e|en)?\s+zahlenfeld(?:er)?|single[- ]?felder?)'
 ).hasMatch(t);
 if (atLeastTwoSingles && singles < 2) return false;
 if(t.contains('mindestens zweimal ein beliebiges single-feld')){if(singles<2)return false;}
 if(t.contains('mindestens zwei einfache zahlenfelder mit geraden zahlen'))if(d.where((x)=>x.single&&x.number.isEven).length<2)return false;
 if(t.contains('mindestens zwei einfache zahlenfelder mit ungeraden zahlen'))if(d.where((x)=>x.single&&x.number.isOdd).length<2)return false;
 // Paritaet gemaess Spielregel: Bullseye ist gerade, Outer Bull ist ungerade.
 // Fehlwuerfe zaehlen weder als gerade noch als ungerade Zahl.
 final oddNumberRequirement = RegExp(r'mindestens\s+(ein|eine|einen|zwei|drei|vier|\d+)\s+ungerade zahl(?:en)?').firstMatch(t);
 if (oddNumberRequirement != null) {
   final required = _wordNum(oddNumberRequirement.group(1)!);
   final actual = d.where((x) => !x.miss && (x.isOuterBull || (!x.isBullseye && x.number >= 1 && x.number <= 20 && x.number.isOdd))).length;
   if (required == 0 || actual < required) return false;
 }
 final evenNumberRequirement = RegExp(r'mindestens\s+(ein|eine|einen|zwei|drei|vier|\d+)\s+gerade zahl(?:en)?').firstMatch(t);
 if (evenNumberRequirement != null) {
   final required = _wordNum(evenNumberRequirement.group(1)!);
   final actual = d.where((x) => !x.miss && (x.isBullseye || (!x.isOuterBull && x.number >= 1 && x.number <= 20 && x.number.isEven))).length;
   if (required == 0 || actual < required) return false;
 }

 if(t.contains('mindestens zweimal dasselbe zahlenfeld')){final counts=<String,int>{};for(final x in d){counts[x.numberKey]=(counts[x.numberKey]??0)+1;}if(counts.values.every((v)=>v<2))return false;}
 if(t.contains('mindestens zweimal die gleiche zahl als double oder triple')){final hits=d.where((x)=>x.doubleHit||x.triple).toList();if(hits.length<2||hits.map((x)=>x.number).toSet().length!=1)return false;}
 if(t.contains('shanghai')){if(d.map((x)=>x.number).toSet().length!=1||d.where((x)=>x.single).length!=1||d.where((x)=>x.doubleHit).length!=1||d.where((x)=>x.triple).length!=1)return false;}
 // Plain number targets such as "Treffe mindestens einmal die 18."
 // refer to the numbered segment, regardless of Single/Double/Triple.
 final plainNumberRe = RegExp(r'mindestens\s+(?:einmal|ein)\s+die\s+(\d{1,2})');
 for (final m in plainNumberRe.allMatches(t)) {
   final n = int.parse(m.group(1)!);
   if (n >= 1 && n <= 20 && !d.any((x) => x.number == n)) return false;
 }
 // Explicit hit requirements: count phrases are translated into exact field hits.
 // Parse named single/double/triple targets and required count from the text.
 // Konkrete einfache Zahlenfelder explizit prüfen. Das Leerzeichen vor der Zahl
 // ist wichtig: Ohne dieses wurde z.B. „einfache Zahlenfeld 18“ nicht erkannt.
 final simpleFieldRe = RegExp(r'einfache\s+zahlenfeld\s+(\d+)');
 for (final m in simpleFieldRe.allMatches(t)) {
   final n = int.parse(m.group(1)!);
   if (!d.any((x) => x.single && x.number == n)) return false;
 }
 final hitRe=RegExp(r'(mindestens\s+(zweimal|dreimal|einmal|zwei|drei)|mindestens\s+einmal|einmal)?\s*(?:das\s+)?(?:einfache\s+zahlenfeld\s+|einfache\s+|single\s+|double\s+|triple\s+)(\d+)');
 final requiredHits=<String,int>{};
 for(final m in hitRe.allMatches(t)){final segment=m.group(0)!;final n=int.parse(m.group(3)!);final typ=segment.contains('triple')?'T':segment.contains('double')?'D':'S';var count=1;if(segment.contains('zweimal')||segment.contains('zwei '))count=2;if(segment.contains('dreimal')||segment.contains('drei '))count=3;final key='$typ$n';requiredHits[key]=(requiredHits[key]??0)+count;}
 for(final entry in requiredHits.entries){final typ=entry.key[0];final n=int.parse(entry.key.substring(1));if(d.where((x)=>x.number==n&&x.multiplier==typ).length<entry.value)return false;}
 // Generic bull and field requirements.
 if(t.contains('bullseye')&&bulls<1&&!(t.contains('mindestens zweimal bullseye')&&bulls>=2))return false;
 if(t.contains('mindestens zweimal bullseye')&&bulls<2)return false;
 if(t.contains('outer bull')&&outer<(t.contains('zweimal outer bull')||t.contains('mindestens zweimal outer bull')?2:1))return false;
 if(t.contains('mindestens einmal ein doppelfeld')||t.contains('mindestens ein doppelfeld')||t.contains('mindestens ein double'))if(doubles<1)return false;
 if(t.contains('mindestens einmal ein triple')||t.contains('mindestens ein triple'))if(triples<1)return false;
 if(t.contains('mindestens zweimal ein doppelfeld'))if(doubles<2)return false;
 if(t.contains('mindestens zweimal ein triple'))if(triples<2)return false;
 // Requirements for unnumbered categories and ranges.
 if(t.contains('zwei unterschiedliche doubles')&&d.where((x)=>x.doubleHit).map((x)=>x.number).toSet().length<2)return false;
 if(t.contains('zwei unterschiedliche trip')&&d.where((x)=>x.triple).map((x)=>x.number).toSet().length<2)return false;
 final range=RegExp(r'(?:bereich|zwischen)\s+(\d+)\s+bis\s+(\d+)').firstMatch(t); if(range!=null){final a=int.parse(range.group(1)!),b=int.parse(range.group(2)!); if(!d.any((x)=>x.number>=a&&x.number<=b))return false;}
 // If text contains explicit field targets, every extracted requirement above is checked.
 // Unsupported special clauses remain unfulfilled rather than being guessed.
 // Fail closed: generic words alone must never make a card successful.
 final recognizedCondition =
     minScore != null || exactScore != null || requiredHits.isNotEmpty || plainNumberRe.hasMatch(t) || range != null ||
     t.contains('shanghai') ||
     t.contains('mindestens drei unterschiedliche zahlenfelder') ||
     t.contains('mindestens zwei unterschiedliche zahlenfelder') ||
     t.contains('jeder dart ein anderes zahlenfeld') ||
     t.contains('ohne dreimal dasselbe feld') ||
     t.contains('ohne dreimal dasselbe zahlenfeld') ||
     distinctDoublesRequired || distinctTriplesRequired ||
     t.contains('bullseye') || t.contains('outer bull') ||
     t.contains('doppelfeld') || t.contains('double') ||
     t.contains('triple') || t.contains('zahlenfeld') || t.contains('single') ||
     oddNumberRequirement != null || evenNumberRequirement != null;
 if (!recognizedCondition) return false;
 return true;
}
int _wordNum(String s)=>switch(s){'ein'=>1,'einen'=>1,'eine'=>1,'zwei'=>2,'drei'=>3,'vier'=>4,_=>int.tryParse(s)??0};

class DartPartyCardSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const DartPartyCardSurface({super.key, required this.child, this.padding = const EdgeInsets.all(14)});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF202019), Color(0xFF121318), Color(0xFF191A1D)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: brandGold.withOpacity(.82), width: 1.25),
          boxShadow: [BoxShadow(color: brandGold.withOpacity(.07), blurRadius: 14, spreadRadius: 1)],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(17),
          child: Stack(children: [
            Positioned(right: -18, bottom: -24, width: 178, height: 142, child: IgnorePointer(child: Opacity(opacity: .085, child: Image.asset('assets/brand/dart_party_logo.png', fit: BoxFit.contain)))),
            Padding(padding: padding, child: child),
            Positioned.fill(child: IgnorePointer(child: Container(margin: const EdgeInsets.all(4), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: brandGold.withOpacity(.17), width: .7))))),
          ]),
        ),
      );

}

class DartPartyCardBack extends StatelessWidget {
  const DartPartyCardBack({super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 300, minHeight: 390),
          child: DartPartyCardSurface(
        padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 18),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 112, child: Image.asset('assets/brand/dart_party_logo.png', fit: BoxFit.contain)),
          const SizedBox(height: 10),
          const LocalizedText('DART PARTY', style: TextStyle(color: brandGold, fontWeight: FontWeight.w900, letterSpacing: 2)),
          const SizedBox(height: 3),
          const LocalizedText('KARTE ZIEHEN', style: TextStyle(color: Colors.white54, fontSize: 10, letterSpacing: 1.3)),
        ]),
          ),
        ),
      );
}

class ChallengeTile extends StatelessWidget {
  final PlayerCard item;
  final String? actionLabel;
  final VoidCallback? action;
  const ChallengeTile({super.key, required this.item, this.actionLabel, this.action});

  Color get color => switch (item.card.category) {
        'Easy' => const Color(0xFF9FC8A5),
        'Medium' => const Color(0xFF9FC4E2),
        'Hard' => const Color(0xFFE0B37D),
        'Legende' => const Color(0xFFC9AFE9),
        _ => const Color(0xFFE7A6A0),
      };

  @override
  Widget build(BuildContext context) {
    final done = item.state != CardState.open;
    final crossed = item.state == CardState.crossed;
    final completed = item.state == CardState.completed;
    final points = categoryPoints[item.card.category] ?? 0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AspectRatio(
        aspectRatio: .70,
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF28271F), Color(0xFF12141A), Color(0xFF1B1B1D)],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: brandGold.withOpacity(.92), width: 1.35),
            boxShadow: [BoxShadow(color: brandGold.withOpacity(.09), blurRadius: 12, spreadRadius: 1)],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(17),
            child: Stack(children: [
              Positioned.fill(
                child: IgnorePointer(
                  child: Opacity(
                    opacity: .105,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Image.asset('assets/brand/dart_party_logo.png', fit: BoxFit.contain),
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: Padding(
                  padding: const EdgeInsets.all(9),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(children: [
                        const Expanded(child: LocalizedText('DART PARTY', maxLines: 1, style: TextStyle(color: brandGold, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.0))),
                        LocalizedText('#${item.card.id}', style: const TextStyle(color: Colors.white54, fontSize: 8, fontWeight: FontWeight.bold)),
                      ]),
                      const SizedBox(height: 6),
                      Container(height: 1, color: brandGold.withOpacity(.52)),
                      const SizedBox(height: 6),
                      Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: color.withOpacity(.13),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: color.withOpacity(.58), width: .8),
                          ),
                          child: LocalizedText(item.card.category.toUpperCase(), maxLines: 1, style: TextStyle(color: color, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .65)),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Expanded(
                        child: Center(
                          child: LocalizedText(
                            item.card.text,
                            textAlign: TextAlign.center,
                            maxLines: 7,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 11.2,
                              height: 1.2,
                              fontWeight: FontWeight.w600,
                              color: done ? Colors.white38 : Colors.white,
                              decoration: crossed ? TextDecoration.lineThrough : TextDecoration.none,
                              decorationColor: Colors.white70,
                              decorationThickness: 2,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Container(height: 1, color: brandGold.withOpacity(.42)),
                      const SizedBox(height: 6),
                      Row(children: [
                        Expanded(child: LocalizedText('$points PUNKTE', maxLines: 1, style: const TextStyle(color: brandGold, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .45))),
                        if (done) Icon(completed ? Icons.check_circle : Icons.block, size: 14, color: completed ? Colors.greenAccent : Colors.orangeAccent),
                      ]),
                      if (actionLabel != null && action != null) ...[
                        const SizedBox(height: 7),
                        SizedBox(
                          height: 32,
                          child: FilledButton(
                            onPressed: action,
                            style: FilledButton.styleFrom(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              backgroundColor: brandGold,
                              foregroundColor: const Color(0xFF171711),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: FittedBox(fit: BoxFit.scaleDown, child: LocalizedText(actionLabel!, maxLines: 1, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800))),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: Container(
                    margin: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: brandGold.withOpacity(.22), width: .75),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}


class CardPairLayout extends StatelessWidget {
  final List<PlayerCard> cards;
  final Widget Function(PlayerCard card) itemBuilder;
  const CardPairLayout({super.key, required this.cards, required this.itemBuilder});

  @override
  Widget build(BuildContext context) {
    final visible = cards.take(2).toList(growable: false);
    if (visible.isEmpty) return const SizedBox.shrink();
    if (visible.length == 1) {
      return Align(
        alignment: Alignment.topCenter,
        child: FractionallySizedBox(widthFactor: .66, child: itemBuilder(visible.first)),
      );
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: itemBuilder(visible[0])),
        const SizedBox(width: 9),
        Expanded(child: itemBuilder(visible[1])),
      ],
    );
  }
}

class ResultsScreen extends StatefulWidget {
  final List<Player> players;
  final String? resultMessage;
  const ResultsScreen({super.key, required this.players, this.resultMessage});
  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _saveResults();
  }

  Future<void> _saveResults() async {
    if (_saved) return;
    _saved = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 1200), () {
        if (mounted) MonetizationService.instance.showInterstitialIfAvailable();
      });
    });
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('dart_party_local_stats');
    final Map<String, dynamic> stats = raw == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(jsonDecode(raw) as Map);
    final highest = widget.players.map((p) => p.score).reduce((a, b) => a > b ? a : b);
    for (final p in widget.players) {
      final key = p.name.trim();
      final old = Map<String, dynamic>.from(stats[key] as Map? ?? <String, dynamic>{});
      final games = (old['games'] as num? ?? 0).toInt();
      final wins = (old['wins'] as num? ?? 0).toInt();
      final points = (old['points'] as num? ?? 0).toInt();
      stats[key] = <String, dynamic>{
        'games': games + 1,
        'wins': wins + (p.score == highest ? 1 : 0),
        'points': points + p.score,
      };
    }
    await prefs.setString('dart_party_local_stats', jsonEncode(stats));
  }

  @override
  Widget build(BuildContext context) {
    final sorted = [...widget.players]..sort((a, b) => b.score.compareTo(a.score));
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Icon(Icons.emoji_events, size: 72, color: Color(0xFFFFD166)),
              const SizedBox(height: 12),
              const Center(child: LocalizedText('SPIEL BEENDET', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
              const SizedBox(height: 8),
              Center(child: LocalizedText(widget.resultMessage ?? 'Gewonnen hat ${sorted.first.name}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, color: brandGold))),
              const SizedBox(height: 24),
              ...sorted.map((p) => Card(child: ListTile(title: LocalizedText(p.name), trailing: LocalizedText('${p.score} Punkte', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))))),
              const Spacer(),
              FilledButton(
                onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false),
                child: const LocalizedText('Zurück zum Hauptmenü'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



enum DartsRule { straight, doubleRule, master }

String _ruleName(DartsRule rule) => switch (rule) {
  DartsRule.straight => 'Straight',
  DartsRule.doubleRule => 'Double',
  DartsRule.master => 'Master',
};

class DartsCounterPlayer {
  final String name;
  final bool isBot;
  final String botDifficulty;
  int remaining;
  bool hasStarted;
  int turns = 0;
  int? lastVisit;
  DartsCounterPlayer(this.name, int startScore, {this.isBot = false, this.botDifficulty = 'Leicht'})
      : remaining = startScore, hasStarted = true;
}

bool _isValidIn(DartThrow dart, DartsRule rule) => switch (rule) {
  DartsRule.straight => true,
  DartsRule.doubleRule => dart.doubleHit || dart.isBullseye,
  DartsRule.master => dart.doubleHit || dart.triple || dart.isBullseye,
};

bool _isValidOut(DartThrow dart, DartsRule rule) => switch (rule) {
  DartsRule.straight => true,
  DartsRule.doubleRule => dart.doubleHit || dart.isBullseye,
  DartsRule.master => dart.doubleHit || dart.triple || dart.isBullseye,
};

class DartsVisitEvaluation {
  final int scored;
  final int remaining;
  final bool started;
  final bool bust;
  final bool won;
  const DartsVisitEvaluation({required this.scored, required this.remaining, required this.started, this.bust = false, this.won = false});
}

DartsVisitEvaluation evaluateDartsVisit(DartsCounterPlayer player, List<DartThrow> darts, DartsRule inRule, DartsRule outRule) {
  var started = player.hasStarted;
  var scored = 0;
  for (final dart in darts) {
    if (!started) {
      if (!_isValidIn(dart, inRule)) continue;
      started = true;
    }
    scored += dart.score;
    final rest = player.remaining - scored;
    if (rest < 0) return DartsVisitEvaluation(scored: scored, remaining: player.remaining, started: started, bust: true);
    if (rest == 0) {
      if (_isValidOut(dart, outRule)) return DartsVisitEvaluation(scored: scored, remaining: 0, started: started, won: true);
      return DartsVisitEvaluation(scored: scored, remaining: player.remaining, started: started, bust: true);
    }
  }
  return DartsVisitEvaluation(scored: scored, remaining: player.remaining - scored, started: started);
}

List<DartThrow> _checkoutCandidates() {
  final result = <DartThrow>[];
  for (var n = 20; n >= 1; n--) result.add(DartThrow('T$n', n * 3, number: n, multiplier: 'T'));
  for (var n = 20; n >= 1; n--) result.add(DartThrow('D$n', n * 2, number: n, multiplier: 'D'));
  for (var n = 20; n >= 1; n--) result.add(DartThrow('S$n', n, number: n, multiplier: 'S'));
  result.add(const DartThrow('Bullseye', 50, bull: true));
  result.add(const DartThrow('Outer Bull', 25, outerBull: true));
  return result;
}

int _finishPreference(DartThrow dart, DartsRule outRule) {
  if (outRule == DartsRule.straight) {
    if (dart.triple) return 100 - dart.score;
    if (dart.doubleHit) return 200 - dart.score;
    if (dart.single) return 300 - dart.score;
    if (dart.isBullseye) return 400;
    if (dart.isOuterBull) return 401;
    return 999;
  }
  if (dart.doubleHit) {
    const preferred = [20, 16, 18, 12, 14, 10, 8, 4, 2, 19, 17, 15, 13, 11, 9, 7, 6, 5, 3, 1];
    final index = preferred.indexOf(dart.number);
    return index < 0 ? 50 : index;
  }
  if (dart.isBullseye) return 25;
  if (dart.triple && outRule == DartsRule.master) return 30 + (20 - dart.number);
  return 999;
}

List<DartThrow>? bestCheckout(int remaining, int dartsAvailable, DartsRule outRule) {
  final maxCheckout = outRule == DartsRule.doubleRule ? 170 : 180;
  if (remaining <= 0 || remaining > maxCheckout || dartsAvailable <= 0) return null;
  // Canonical route for 121 Double Out; after a missed T20 (S20), the
  // two-dart solver below immediately switches to T17 + Bullseye for 101.
  if (outRule == DartsRule.doubleRule && remaining == 121 && dartsAvailable >= 3) {
    return [
      DartThrow('T20', 60, number: 20, multiplier: 'T'),
      DartThrow('T11', 33, number: 11, multiplier: 'T'),
      DartThrow('D14', 28, number: 14, multiplier: 'D'),
    ];
  }
  final candidates = _checkoutCandidates();
  final candidateRank = <String, int>{for (var i = 0; i < candidates.length; i++) candidates[i].fieldKey: i};
  for (var used = 1; used <= dartsAvailable && used <= 3; used++) {
    final routes = <List<DartThrow>>[];
    void search(int slots, int pointsLeft, List<DartThrow> prefix) {
      if (slots == 1) {
        for (final finish in candidates) {
          if (finish.score == pointsLeft && _isValidOut(finish, outRule)) routes.add([...prefix, finish]);
        }
        return;
      }
      for (final dart in candidates) {
        if (dart.score <= 0 || dart.score >= pointsLeft) continue;
        prefix.add(dart);
        search(slots - 1, pointsLeft - dart.score, prefix);
        prefix.removeLast();
      }
    }
    search(used, remaining, <DartThrow>[]);
    if (routes.isNotEmpty) {
      routes.sort((a, b) {
        var c = _finishPreference(a.last, outRule).compareTo(_finishPreference(b.last, outRule));
        if (c != 0) return c;
        for (var i = 0; i < a.length - 1; i++) {
          c = (candidateRank[a[i].fieldKey] ?? 999).compareTo(candidateRank[b[i].fieldKey] ?? 999);
          if (c != 0) return c;
        }
        return 0;
      });
      return routes.first;
    }
  }
  return null;
}

class DartsCounterSetupScreen extends StatefulWidget {
  const DartsCounterSetupScreen({super.key});
  @override State<DartsCounterSetupScreen> createState() => _DartsCounterSetupScreenState();
}

class _DartsCounterSetupScreenState extends State<DartsCounterSetupScreen> {
  final names = [TextEditingController(text: 'Spieler 1'), TextEditingController(text: 'Spieler 2')];
  final List<bool> botPlayers = [false, false];
  final List<String> botLevels = ['Leicht', 'Leicht'];
  int startScore = 501;
  DartsRule inRule = DartsRule.straight;
  DartsRule outRule = DartsRule.doubleRule;
  bool checkoutHelp = true;
  bool loading = false;

  @override void initState() { super.initState(); _loadNames(); }
  Future<void> _loadNames() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dart_party_player_names');
    if (saved != null && saved.isNotEmpty) {
      for (var i = 0; i < saved.length && i < 8; i++) {
        if (i >= names.length) { names.add(TextEditingController(text: saved[i])); botPlayers.add(false); botLevels.add('Leicht'); }
        else if (saved[i].trim().isNotEmpty) names[i].text = saved[i];
      }
      if (mounted) setState(() {});
    }
  }
  @override void dispose() { for (final name in names) { name.dispose(); } super.dispose(); }
  void _addPlayer() => setState(() { names.add(TextEditingController(text: 'Spieler ${names.length + 1}')); botPlayers.add(false); botLevels.add('Leicht'); });
  void _removePlayer(int index) => setState(() { names.removeAt(index).dispose(); botPlayers.removeAt(index); botLevels.removeAt(index); });

  void _showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const LocalizedText('Spielregeln – Klassisches Spiel'),
    content: const SingleChildScrollView(child: LocalizedText(
      'Ziel ist es, von 301 oder 501 Punkten exakt auf 0 zu kommen. Jeder Spieler wirft pro Aufnahme bis zu drei Darts.\n\n'
      'Straight In: Jeder Dart zählt von Beginn an. Double In: Erst ein Double oder Bullseye startet das Spiel; dieser Dart zählt bereits. Master In: Ein Double, Triple oder Bullseye startet das Spiel.\n\n'
      'Straight Out: Zum Sieg muss exakt 0 erreicht werden. Double Out: Der letzte Dart muss ein Double oder Bullseye sein. Master Out: Der letzte Dart muss ein Double, Triple oder Bullseye sein.\n\n'
      'Überwerfen oder ein ungültiger Finish-Versuch bedeutet Bust: Die gesamte Aufnahme wird zurückgesetzt. Ein erfolgreicher Checkout beendet das Spiel sofort.'
    )), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))]));

  void _start() async {
    final valid = names.map((c) => c.text.trim()).toList();
    if (valid.length < 2 || valid.any((n) => n.isEmpty) || valid.toSet().length != valid.length) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: LocalizedText('Bitte mindestens zwei unterschiedliche Spielernamen eintragen.')));
      return;
    }
    setState(() => loading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('dart_party_player_names', valid);
      final players = List.generate(valid.length, (i) => DartsCounterPlayer(valid[i], startScore, isBot: botPlayers[i], botDifficulty: botLevels[i])
        ..hasStarted = inRule == DartsRule.straight);
      if (!mounted) return;
      final allowed = await MonetizationService.instance.authorizeGameStart(context);
      if (!allowed || !mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DartsCounterGameScreen(players: players, startScore: startScore, inRule: inRule, outRule: outRule, checkoutHelp: checkoutHelp)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: LocalizedText('Fehler: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const LocalizedText('Klassisches Spiel einstellen'), actions: [IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: _showRules)]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const LocalizedText('KLASSISCHES SPIEL', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6), const LocalizedText('Spieler, Startpunkte und Regeln festlegen.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      DropdownButtonFormField<int>(initialValue: startScore, decoration: const InputDecoration(label: LocalizedText('Startpunktzahl')), items: const [301, 501].map((n) => DropdownMenuItem(value: n, child: LocalizedText('$n Punkte'))).toList(), onChanged: loading ? null : (v) => setState(() => startScore = v ?? 501)),
      const SizedBox(height: 12),
      DropdownButtonFormField<DartsRule>(initialValue: inRule, decoration: const InputDecoration(label: LocalizedText('Spielbeginn (In)')), items: DartsRule.values.map((r) => DropdownMenuItem(value: r, child: LocalizedText('${_ruleName(r)} In'))).toList(), onChanged: loading ? null : (v) => setState(() => inRule = v ?? DartsRule.straight)),
      const SizedBox(height: 12),
      DropdownButtonFormField<DartsRule>(initialValue: outRule, decoration: const InputDecoration(label: LocalizedText('Spielende (Out)')), items: DartsRule.values.map((r) => DropdownMenuItem(value: r, child: LocalizedText('${_ruleName(r)} Out'))).toList(), onChanged: loading ? null : (v) => setState(() => outRule = v ?? DartsRule.doubleRule)),
      const SizedBox(height: 8),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: const LocalizedText('Checkouthilfe anzeigen'), subtitle: const LocalizedText('Berechnet nach jedem Dart den besten legalen Weg auf 0.'), value: checkoutHelp, onChanged: loading ? null : (v) => setState(() => checkoutHelp = v)),
      const Divider(height: 28),
      const LocalizedText('SPIELER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 10),
      ...List.generate(names.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: TextField(controller: names[i], decoration: InputDecoration(label: LocalizedText('Spieler ${i + 1}')))), if (names.length > 2) IconButton(onPressed: loading ? null : () => _removePlayer(i), icon: const Icon(Icons.close))]),
        const SizedBox(height: 7),
        Row(children: [
          Expanded(child: DropdownButtonFormField<bool>(initialValue: botPlayers[i], decoration: const InputDecoration(label: LocalizedText('Spielertyp')), items: const [DropdownMenuItem(value: false, child: LocalizedText('Mensch')), DropdownMenuItem(value: true, child: LocalizedText('Bot'))], onChanged: loading ? null : (v) => setState(() => botPlayers[i] = v ?? false))),
          if (botPlayers[i]) const SizedBox(width: 8),
          if (botPlayers[i]) Expanded(child: DropdownButtonFormField<String>(initialValue: botLevels[i], decoration: const InputDecoration(label: LocalizedText('Bot-Stärke')), items: const ['Ultra leicht', 'Leicht', 'Mittel', 'Hart', 'Experte'].map((v) => DropdownMenuItem(value: v, child: LocalizedText(v))).toList(), onChanged: loading ? null : (v) => setState(() => botLevels[i] = v ?? 'Leicht'))),
        ]),
      ]))),
      OutlinedButton.icon(onPressed: loading || names.length >= 8 ? null : _addPlayer, icon: const Icon(Icons.add), label: const LocalizedText('Spieler hinzufügen')),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: loading ? null : _start, icon: const Icon(Icons.play_arrow), label: const LocalizedText('Spiel starten')),
    ])),
  );
}

class DartsCounterGameScreen extends StatefulWidget {
  final List<DartsCounterPlayer> players;
  final int startScore;
  final DartsRule inRule;
  final DartsRule outRule;
  final bool checkoutHelp;
  const DartsCounterGameScreen({super.key, required this.players, required this.startScore, required this.inRule, required this.outRule, required this.checkoutHelp});
  @override State<DartsCounterGameScreen> createState() => _DartsCounterGameScreenState();
}

class _DartsCounterGameScreenState extends State<DartsCounterGameScreen> {
  int playerIndex = 0;
  final List<DartThrow> darts = [];
  String? message;
  bool gameOver = false;
  bool botBusy = false;
  String? winner;
  DartsCounterPlayer get player => widget.players[playerIndex];
  DartsVisitEvaluation get visit => evaluateDartsVisit(player, darts, widget.inRule, widget.outRule);

  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded()); }

  void _startBotIfNeeded() {
    if (!mounted || gameOver || botBusy || !player.isBot) return;
    botBusy = true;
    _playBotVisit();
  }

  Future<void> _playBotVisit() async {
    final bot = player;
    final expectedIndex = playerIndex;
    for (var i = 0; i < 3; i++) {
      await Future.delayed(const Duration(milliseconds: 520));
      if (!mounted || gameOver || playerIndex != expectedIndex || player != bot) break;
      _addDart(_botThrow(bot.botDifficulty));
      if (gameOver || playerIndex != expectedIndex || player != bot) break;
    }
    botBusy = false;
    if (mounted && !gameOver && player.isBot && player != bot) _startBotIfNeeded();
  }

  void _addDart(DartThrow dart) {
    if (gameOver || player.isBot && !botBusy || darts.length >= 3) return;
    final updated = [...darts, dart];
    final result = evaluateDartsVisit(player, updated, widget.inRule, widget.outRule);
    if (result.bust || result.won || updated.length == 3) {
      setState(() {
        player.hasStarted = result.started;
        player.turns++;
        if (result.bust) {
          player.lastVisit = null;
          message = '${player.name}: BUST – die Aufnahme zählt nicht. Rest bleibt bei ${player.remaining}.';
        } else {
          player.remaining = result.remaining;
          player.lastVisit = result.scored;
          message = result.won ? '${player.name} checkt aus und gewinnt!' : '${player.name}: ${result.scored} Punkte – neuer Rest: ${player.remaining}.';
        }
        darts.clear();
        if (result.won) { gameOver = true; winner = player.name; }
        else { playerIndex = (playerIndex + 1) % widget.players.length; }
      });
      if (result.won) _showWinner();
      else WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
    } else {
      setState(() => darts.add(dart));
    }
  }

  void _showWinner() {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      showDialog<void>(context: context, barrierDismissible: false, builder: (context) => AlertDialog(
        title: const LocalizedText('Spiel beendet'),
        content: LocalizedText('${winner ?? 'Ein Spieler'} gewinnt mit einem Checkout!'),
        actions: [TextButton(onPressed: () => Navigator.popUntil(context, (route) => route.isFirst), child: const LocalizedText('Zum Hauptmenü'))],
      )).then((_) => MonetizationService.instance.showInterstitialIfAvailable());
    });
  }

  Widget _checkoutCard() {
    if (!widget.checkoutHelp) return const SizedBox.shrink();
    final evaluation = visit;
    final remainingDarts = 3 - darts.length;
    String headline;
    String routeText = '';
    String detail = '';
    if (!evaluation.started) {
      headline = 'Zuerst einchecken';
      detail = '${_ruleName(widget.inRule)} In: Treffer mit den passenden Feldern startet das Spiel.';
    } else {
      final route = bestCheckout(evaluation.remaining, remainingDarts, widget.outRule);
      if (route == null) {
        headline = 'Kein Checkout möglich';
        detail = remainingDarts <= 0 ? 'Die Aufnahme ist beendet.' : 'Mit $remainingDarts verbleibenden Dart${remainingDarts == 1 ? '' : 's'} ist kein legaler Finish-Weg möglich.';
      } else {
        headline = route.map((d) => d.label).join(' – ');
        routeText = '${route.fold<int>(0, (sum, d) => sum + d.score)} Punkte';
        detail = '${route.length} Dart${route.length == 1 ? '' : 's'} · ${_ruleName(widget.outRule)} Out';
      }
    }
    return Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.alt_route, color: purple), const SizedBox(width: 8), const LocalizedText('BESTER CHECKOUT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8)), const Spacer(), LocalizedText('$remainingDarts/3 Darts übrig', style: const TextStyle(color: Colors.white54, fontSize: 11))]),
      const SizedBox(height: 10),
      LocalizedText(headline, style: TextStyle(fontSize: routeText.isEmpty ? 17 : 22, fontWeight: FontWeight.w900, color: routeText.isEmpty ? Colors.white70 : Colors.greenAccent)),
      if (routeText.isNotEmpty) LocalizedText(routeText, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      const SizedBox(height: 3), LocalizedText(detail, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    ])));
  }

  void _showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const LocalizedText('Spielregeln – Klassisches Spiel'),
    content: SingleChildScrollView(child: LocalizedText(
      '${widget.startScore} Punkte · ${_ruleName(widget.inRule)} In · ${_ruleName(widget.outRule)} Out.\n\n'
      'Jeder Spieler wirft bis zu drei Darts. Ein Bust setzt die gesamte Aufnahme zurück. Ein erfolgreicher Checkout beendet das Spiel sofort.\n\n'
      'Double In/Out zählt mit einem Double oder innerem Bullseye. Master In/Out zählt mit Double, Triple oder innerem Bullseye. Outer Bull ist 25 Punkte, aber kein Double-Finish.'
    )),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))]));

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: LocalizedText('${widget.startScore} – Klassisches Spiel'), actions: [IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: _showRules)]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: LocalizedText(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))), LocalizedText('Aufnahme ${player.turns + 1}', style: const TextStyle(color: Colors.white60))]),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        const LocalizedText('RESTPUNKTE', style: TextStyle(color: Colors.white60, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 5),
        LocalizedText('${visit.remaining}', style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w900, color: purple), key: ValueKey('${player.name}-${visit.remaining}-${darts.length}')),
        LocalizedText('${_ruleName(widget.inRule)} In  ·  ${_ruleName(widget.outRule)} Out', style: const TextStyle(color: Colors.white54, fontSize: 12)),
        if (!player.hasStarted && !visit.started) const Padding(padding: EdgeInsets.only(top: 8), child: LocalizedText('Noch nicht eingecheckt', style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold))),
      ]))),
      _checkoutCard(),
      const SizedBox(height: 8),
      if (player.isBot)
        Card(child: Padding(padding: const EdgeInsets.all(14), child: LocalizedText(botBusy ? 'Bot wirft automatisch … ${darts.length}/3 Darts' : 'Bot ist am Zug.', style: const TextStyle(color: Colors.white60))))
      else ...[
        _DartProgress(darts: darts, total: visit.scored, onUndo: darts.isEmpty ? null : () => setState(() => darts.removeLast()), onReset: darts.isEmpty ? null : () => setState(() => darts.clear()), completionText: 'Aufnahme wird nach dem dritten Dart automatisch gewertet.'),
        const SizedBox(height: 8),
        if (darts.length < 3) DartEntry(onChanged: _addDart),
      ],
      if (message != null) Card(child: Padding(padding: const EdgeInsets.all(12), child: LocalizedText(message!, style: const TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 8),
      const LocalizedText('SPIELERÜBERSICHT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      ...widget.players.map((p) => Card(child: ListTile(
        leading: Icon(p.isBot ? Icons.smart_toy : Icons.person, color: p.name == player.name && !gameOver ? purple : Colors.white54),
        title: LocalizedText(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: LocalizedText('${p.isBot ? 'Bot · ${p.botDifficulty}' : 'Mensch'}${p.hasStarted ? '' : ' · noch nicht eingecheckt'}${p.lastVisit == null ? '' : ' · letzte Aufnahme: ${p.lastVisit}'}'),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [LocalizedText('${p.remaining}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), if (p.name == player.name && !gameOver) const LocalizedText('AM ZUG', style: TextStyle(color: purple, fontSize: 9, fontWeight: FontWeight.bold))]),
      ))),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: _showRules, icon: const Icon(Icons.help_outline), label: const LocalizedText('Spielregeln anzeigen')),
    ])),
  );
}

class UnderOverPlayer {
  final String name;
  final bool isBot;
  final String botDifficulty;
  int? lastScore;
  bool eliminated = false;
  int turns = 0;
  UnderOverPlayer(this.name, {this.isBot = false, this.botDifficulty = 'Leicht'});
}

class UnderOverSetupScreen extends StatefulWidget {
  const UnderOverSetupScreen({super.key});
  @override State<UnderOverSetupScreen> createState() => _UnderOverSetupScreenState();
}
class _UnderOverSetupScreenState extends State<UnderOverSetupScreen> {
  final names = [TextEditingController(text: 'Spieler 1'), TextEditingController(text: 'Spieler 2')];
  final List<bool> botPlayers = [false, false];
  final List<String> botLevels = ['Leicht', 'Leicht'];
  bool loading = false;
  @override void initState() { super.initState(); _loadNames(); }
  Future<void> _loadNames() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dart_party_player_names');
    if (saved != null && saved.isNotEmpty) {
      for (var i = 0; i < saved.length && i < 8; i++) {
        if (i >= names.length) { names.add(TextEditingController(text: saved[i])); botPlayers.add(false); botLevels.add('Leicht'); }
        else if (saved[i].trim().isNotEmpty) names[i].text = saved[i];
      }
      if (mounted) setState(() {});
    }
  }
  @override void dispose() { for (final c in names) { c.dispose(); } super.dispose(); }
  void _addPlayer() => setState(() { names.add(TextEditingController(text: 'Spieler ${names.length + 1}')); botPlayers.add(false); botLevels.add('Leicht'); });
  void _removePlayer(int index) => setState(() { names.removeAt(index).dispose(); botPlayers.removeAt(index); botLevels.removeAt(index); });
  void showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const LocalizedText('Spielregeln – Unter / Über 40'),
    content: const SingleChildScrollView(child: LocalizedText(
      '1. Beide Grenzen starten bei 40. Jeder Spieler – Mensch oder Bot – wirft drei Darts.\n\n'
      '2. Liegt die Summe unter der Untergrenze, wird die Untergrenze auf diese Summe gesetzt.\n\n'
      '3. Liegt die Summe über der Obergrenze, wird die Obergrenze auf diese Summe gesetzt.\n\n'
      '4. Innerhalb des Bereichs oder genau auf einer Grenze scheidet der Spieler aus.\n\n'
      '5. Triple 1 zählt 0 Punkte. Der letzte verbleibende Spieler gewinnt.'
    )), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))]));
  Future<void> start() async {
    if (loading) return;
    final valid = names.map((c) => c.text.trim()).toList();
    if (valid.length < 2 || valid.any((n) => n.isEmpty) || valid.toSet().length != valid.length) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: LocalizedText('Bitte mindestens zwei unterschiedliche Spielernamen eintragen.')));
      return;
    }
    setState(() => loading = true);
    try {
      final players = List.generate(valid.length, (i) => UnderOverPlayer(valid[i], isBot: botPlayers[i], botDifficulty: botLevels[i]));
      final allowed = await MonetizationService.instance.authorizeGameStart(context);
      if (!allowed || !mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => UnderOverGameScreen(players: players)));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const LocalizedText('Spieler festlegen')),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [const Expanded(child: LocalizedText('UNTER / ÜBER 40', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900))), IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: showRules)]),
      const LocalizedText('Trage Menschen und Bots ein. Beide Grenzen starten bei 40.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      ...List.generate(names.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: TextField(controller: names[i], decoration: InputDecoration(label: LocalizedText('Spieler ${i + 1}')))), if (names.length > 2) IconButton(onPressed: loading ? null : () => _removePlayer(i), icon: const Icon(Icons.close))]),
        const SizedBox(height: 7),
        Row(children: [
          Expanded(child: DropdownButtonFormField<bool>(initialValue: botPlayers[i], decoration: const InputDecoration(label: LocalizedText('Spielertyp')), items: const [DropdownMenuItem(value: false, child: LocalizedText('Mensch')), DropdownMenuItem(value: true, child: LocalizedText('Bot'))], onChanged: loading ? null : (v) => setState(() => botPlayers[i] = v ?? false))),
          if (botPlayers[i]) const SizedBox(width: 8),
          if (botPlayers[i]) Expanded(child: DropdownButtonFormField<String>(initialValue: botLevels[i], decoration: const InputDecoration(label: LocalizedText('Bot-Stärke')), items: const ['Ultra leicht', 'Leicht', 'Mittel', 'Hart', 'Experte'].map((v) => DropdownMenuItem(value: v, child: LocalizedText(v))).toList(), onChanged: loading ? null : (v) => setState(() => botLevels[i] = v ?? 'Leicht'))),
        ]),
      ]))),
      OutlinedButton.icon(onPressed: names.length >= 8 ? null : _addPlayer, icon: const Icon(Icons.add), label: const LocalizedText('Spieler hinzufügen')),
      const SizedBox(height: 22),
      FilledButton.icon(onPressed: loading ? null : start, icon: const Icon(Icons.play_arrow), label: LocalizedText(loading ? 'Bitte warten …' : 'Spiel starten')),
    ])),
  );
}

class UnderOverGameScreen extends StatefulWidget {
  final List<UnderOverPlayer> players;
  const UnderOverGameScreen({super.key, required this.players});
  @override State<UnderOverGameScreen> createState() => _UnderOverGameScreenState();
}

class _UnderOverGameScreenState extends State<UnderOverGameScreen> {
  int lower = 40, upper = 40, playerIndex = 0;
  final List<DartThrow> darts = [];
  String? message;
  bool gameOver = false;
  bool botBusy = false;
  UnderOverPlayer get player => widget.players[playerIndex];
  List<UnderOverPlayer> get active => widget.players.where((p) => !p.eliminated).toList();
  int get total => darts.fold<int>(0, (sum, dart) => sum + dart.score);

  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded()); }
  void _startBotIfNeeded() {
    if (!mounted || gameOver || botBusy || !player.isBot) return;
    botBusy = true;
    _playBotTurn();
  }
  Future<void> _playBotTurn() async {
    final bot = player;
    final expectedIndex = playerIndex;
    for (var i = 0; i < 3; i++) {
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted || gameOver || playerIndex != expectedIndex || player != bot) break;
      _addDart(_botThrow(bot.botDifficulty));
    }
    if (!mounted) return;
    if (playerIndex == expectedIndex && identical(player, bot) && darts.length == 3 && !gameOver) _submit();
    botBusy = false;
    if (mounted && !gameOver && player.isBot && !identical(player, bot)) _startBotIfNeeded();
  }

  void showRules() => showDialog(context: context, builder: (context) => AlertDialog(
    title: const LocalizedText('Spielregeln – Unter / Über 40'),
    content: const SingleChildScrollView(child: LocalizedText(
      'Start: Untergrenze 40 und Obergrenze 40. Jeder Spieler – Mensch oder Bot – wirft drei Darts.\n\n'
      'Unter der Untergrenze: Die Untergrenze wird auf die Summe gesetzt.\n\n'
      'Über der Obergrenze: Die Obergrenze wird auf die Summe gesetzt.\n\n'
      'Innerhalb des Bereichs oder genau auf einer Grenze: Der Spieler scheidet aus.\n\n'
      'Triple 1 zählt 0 Punkte. Der letzte verbleibende Spieler gewinnt.'
    )), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))]));

  void _addDart(DartThrow dart) {
    if (gameOver || darts.length >= 3 || (player.isBot && !botBusy)) return;
    final accepted = dart.triple && dart.number == 1 ? const DartThrow('T 1', 0, number: 1, multiplier: 'T') : dart;
    setState(() => darts.add(accepted));
  }
  void _undoDart() { if (darts.isNotEmpty && !gameOver && !player.isBot) setState(() => darts.removeLast()); }
  void _resetDarts() { if (darts.isNotEmpty && !gameOver && !player.isBot) setState(() => darts.clear()); }

  void _submit() {
    if (darts.length != 3 || gameOver) return;
    final current = player;
    final value = total;
    setState(() {
      current.lastScore = value;
      current.turns++;
      if (value < lower) { lower = value; message = '${current.name}: $value Punkte – neue Untergrenze: $lower'; }
      else if (value > upper) { upper = value; message = '${current.name}: $value Punkte – neue Obergrenze: $upper'; }
      else { current.eliminated = true; message = '${current.name} scheidet mit $value Punkten aus.'; }
      darts.clear();
      if (active.length <= 1) gameOver = true;
      else {
        for (var i = 1; i <= widget.players.length; i++) {
          final next = (playerIndex + i) % widget.players.length;
          if (!widget.players[next].eliminated) { playerIndex = next; break; }
        }
      }
    });
    if (gameOver) {
      Future.delayed(const Duration(milliseconds: 350), () {
        if (!mounted) return;
        showDialog<void>(context: context, barrierDismissible: false, builder: (context) => AlertDialog(
          title: const LocalizedText('Spiel beendet'),
          content: LocalizedText(active.isEmpty ? 'Alle Spieler sind ausgeschieden.' : 'Gewonnen hat ${active.first.name}!'),
          actions: [TextButton(onPressed: () => Navigator.popUntil(context, (route) => route.isFirst), child: const LocalizedText('Zum Hauptmenü'))],
        )).then((_) => MonetizationService.instance.showInterstitialIfAvailable());
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const LocalizedText('Unter / Über 40'), actions: [IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: showRules)]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: LocalizedText(player.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800))), LocalizedText('Runde ${player.turns + 1}', style: const TextStyle(color: Colors.white60))]),
      if (player.isBot) const Padding(padding: EdgeInsets.only(top: 4), child: LocalizedText('BOT AM ZUG', style: TextStyle(color: purple, fontWeight: FontWeight.bold, fontSize: 11))),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        const LocalizedText('AKTUELLE GRENZEN', style: TextStyle(color: Colors.white60, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: Column(children: [const LocalizedText('UNTER', style: TextStyle(color: Colors.lightBlueAccent, fontWeight: FontWeight.bold)), LocalizedText('$lower', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Colors.lightBlueAccent))])),
          Container(width: 1, height: 48, color: Colors.white24),
          Expanded(child: Column(children: [const LocalizedText('ÜBER', style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold)), LocalizedText('$upper', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Colors.orangeAccent))])),
        ]),
      ]))),
      const SizedBox(height: 14),
      _DartProgress(darts: darts, total: total, onUndo: player.isBot ? null : _undoDart, onReset: player.isBot ? null : _resetDarts, completionText: 'Alle drei Darts eingegeben – Summe prüfen und bestätigen.'),
      const SizedBox(height: 10),
      if (player.isBot)
        Card(child: Padding(padding: const EdgeInsets.all(14), child: LocalizedText('Bot wirft automatisch … ${darts.length}/3 Darts', style: const TextStyle(color: Colors.white60))))
      else if (darts.length < 3)
        DartEntry(onChanged: _addDart)
      else
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const LocalizedText('DEINE DREI WÜRFE', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
          const SizedBox(height: 7),
          LocalizedText(darts.map((dart) => dart.label).join('   ·   '), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 5),
          LocalizedText('Gesamt: $total Punkte', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: purple)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.check), label: const LocalizedText('Wurf bestätigen'))),
        ]))),
      if (message != null) Card(child: Padding(padding: const EdgeInsets.all(12), child: LocalizedText(message!, style: const TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 10),
      const LocalizedText('SPIELERÜBERSICHT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 6),
      ...widget.players.map((p) => Card(child: ListTile(
        leading: Icon(p.eliminated ? Icons.cancel : (p.isBot ? Icons.smart_toy : Icons.person), color: p.eliminated ? Colors.redAccent : (p.name == player.name && !gameOver ? purple : Colors.greenAccent)),
        title: LocalizedText(p.name, style: TextStyle(decoration: p.eliminated ? TextDecoration.lineThrough : null, color: p.eliminated ? Colors.white38 : Colors.white)),
        subtitle: LocalizedText('${p.isBot ? 'Bot · ${p.botDifficulty}' : 'Mensch'} · ${p.eliminated ? 'Ausgeschieden · ${p.lastScore} Punkte' : 'Noch im Spiel${p.lastScore == null ? '' : ' · letzter Wurf: ${p.lastScore}'}'}'),
        trailing: p.name == player.name && !gameOver ? const LocalizedText('AM ZUG', style: TextStyle(color: purple, fontWeight: FontWeight.bold)) : null,
      ))),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: showRules, icon: const Icon(Icons.help_outline), label: const LocalizedText('Spielregeln anzeigen')),
    ])),
  );
}

class LocalStatsScreen extends StatefulWidget {
  const LocalStatsScreen({super.key});
  @override
  State<LocalStatsScreen> createState() => _LocalStatsScreenState();
}

class _LocalStatsScreenState extends State<LocalStatsScreen> {
  Map<String, dynamic> stats = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('dart_party_local_stats');
    if (raw != null) {
      try {
        stats = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      } catch (_) {
        stats = {};
      }
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final entries = stats.entries.toList()
      ..sort((a, b) => ((b.value['wins'] as num?) ?? 0).compareTo((a.value['wins'] as num?) ?? 0));
    return Scaffold(
      appBar: AppBar(title: const LocalizedText('Spieler-Statistik')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : entries.isEmpty
              ? const Center(child: LocalizedText('Noch keine abgeschlossenen Spiele.'))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: entries.map((entry) {
                    final value = Map<String, dynamic>.from(entry.value as Map);
                    final games = (value['games'] as num? ?? 0).toInt();
                    final wins = (value['wins'] as num? ?? 0).toInt();
                    final points = (value['points'] as num? ?? 0).toInt();
                    final average = games == 0 ? 0 : points / games;
                    return Card(
                      child: ListTile(
                        title: LocalizedText(entry.key, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: LocalizedText('$games Spiele · $wins Siege · Ø ${average.toStringAsFixed(1)} Punkte/Spiel'),
                        trailing: LocalizedText('$points P', style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
                      ),
                    );
                  }).toList(),
                ),
    );
  }
}

// -----------------------------------------------------------------------------
// PARTymodus – ein gemeinsamer, verdeckter Stapel aus Challenges und Bonuskarten
// -----------------------------------------------------------------------------

class PartyCard {
  final String id;
  final String kind;
  final String category;
  final String title;
  final String taskType;
  final Map<String, dynamic>? goal;
  final String consequenceA;
  final String consequenceB;
  final String description;
  final String effect;

  const PartyCard({
    required this.id,
    required this.kind,
    required this.category,
    required this.title,
    required this.taskType,
    required this.goal,
    required this.consequenceA,
    required this.consequenceB,
    required this.description,
    required this.effect,
  });

  bool get isBonus => kind == 'bonus';
  bool get isDartTask => taskType == 'darts';

  factory PartyCard.fromJson(Map<String, dynamic> json) => PartyCard(
        id: json['id'] as String? ?? '',
        kind: json['kind'] as String? ?? 'challenge',
        category: json['category'] as String? ?? 'Bonus',
        title: json['title'] as String? ?? '',
        taskType: json['taskType'] as String? ?? '',
        goal: json['goal'] == null ? null : Map<String, dynamic>.from(json['goal'] as Map),
        consequenceA: json['consequenceA'] as String? ?? '',
        consequenceB: json['consequenceB'] as String? ?? '',
        description: json['description'] as String? ?? '',
        effect: json['effect'] as String? ?? '',
      );
}

class PartyPlayer {
  final String name;
  final bool isBot;
  final String botDifficulty;
  int cardsDrawn = 0;
  int challengesPassed = 0;
  int challengesFailed = 0;
  int bonusesDrawn = 0;
  bool shielded = false;
  PartyPlayer(this.name, {this.isBot = false, this.botDifficulty = 'Leicht'});
}

const partyCategories = ['Dartsanfänger', 'Gelegenheitsspieler', 'Profis'];
const partyBotDifficulties = ['Ultra leicht', 'Leicht', 'Mittel', 'Hart', 'Experte'];

// Manuelle Party-Aufgaben werden für Bots simuliert. Die Kartenkategorie
// beeinflusst die Chance leicht, die Bot-Stärke deutlich.
double partyBotActionSuccessChance(String difficulty, String category) {
  final base = switch (difficulty) {
    'Ultra leicht' => 0.52,
    'Leicht' => 0.65,
    'Mittel' => 0.77,
    'Hart' => 0.88,
    'Experte' => 0.95,
    _ => 0.65,
  };
  final categoryAdjustment = switch (category) {
    'Dartsanfänger' => 0.10,
    'Gelegenheitsspieler' => 0.0,
    'Profis' => -0.10,
    _ => 0.0,
  };
  return (base + categoryAdjustment).clamp(0.10, 0.99).toDouble();
}

bool evaluatePartyBotAction(String difficulty, String category, Random random) =>
    random.nextDouble() < partyBotActionSuccessChance(difficulty, category);

int choosePartyBotConsequence(Random random) => random.nextInt(2);

Future<List<PartyCard>> loadPartyDeck(Set<String> selectedCategories) async {
  final raw = await rootBundle.loadString('assets/data/party_cards.json');
  final data = Map<String, dynamic>.from(jsonDecode(raw) as Map);
  final challenges = (data['challenges'] as List)
      .map((item) => PartyCard.fromJson(Map<String, dynamic>.from(item as Map)))
      .where((card) => selectedCategories.contains(card.category))
      .toList();
  // Alle Bonuskarten kommen in denselben Stapel. Vor dem Ziehen ist nicht sichtbar,
  // welcher Kartentyp als Nächstes kommt.
  final bonuses = (data['bonuses'] as List)
      .map((item) => PartyCard.fromJson(Map<String, dynamic>.from(item as Map)))
      .toList();
  final deck = <PartyCard>[...challenges, ...bonuses]..shuffle(Random());
  return deck;
}

bool evaluatePartyDartGoal(Map<String, dynamic> goal, List<DartThrow> darts) {
  if (darts.length != 3) return false;
  final type = goal['type'] as String? ?? '';
  final value = (goal['value'] as num?)?.toInt() ?? 0;
  final number = (goal['number'] as num?)?.toInt() ?? 0;
  final multiplier = goal['multiplier'] as String? ?? '';
  final total = darts.fold<int>(0, (sum, dart) => sum + dart.score);
  final doubles = darts.where((dart) => dart.doubleHit).toList();
  final triples = darts.where((dart) => dart.triple).toList();
  final hitNumbers = darts
      .where((dart) => !dart.isBullseye && !dart.isOuterBull && !dart.miss && dart.number >= 1 && dart.number <= 20)
      .map((dart) => dart.number)
      .toSet();

  switch (type) {
    case 'min_score':
      return total >= value;
    case 'max_score':
      return total <= value;
    case 'exact_score':
      return total == value;
    case 'score_range':
      final min = (goal['min'] as num?)?.toInt() ?? 0;
      final max = (goal['max'] as num?)?.toInt() ?? 180;
      return total >= min && total <= max;
    case 'hit_number':
      return darts.any((dart) => dart.number == number);
    case 'hit_segment':
      return darts.any((dart) => dart.number == number && dart.multiplier == multiplier);
    case 'hit_double':
      return doubles.isNotEmpty;
    case 'hit_triple':
      return triples.isNotEmpty;
    case 'hit_bull':
      return darts.any((dart) => dart.isBullseye);
    case 'hit_outer_bull':
      return darts.any((dart) => dart.isOuterBull);
    case 'at_least_doubles':
      return doubles.length >= value;
    case 'at_least_triples':
      return triples.length >= value;
    case 'count_darts_at_least':
      return darts.where((dart) => dart.score >= number).length >= value;
    case 'no_miss':
      return darts.every((dart) => !dart.miss);
    case 'two_different_numbers':
      return hitNumbers.length >= 2;
    case 'total_even':
      return total.isEven;
    case 'total_odd':
      return total.isOdd;
    case 'first_dart_at_least':
      return darts.first.score >= value;
    case 'all_darts_at_least':
      return darts.every((dart) => dart.score >= value);
    case 'two_different_triples':
      return triples.map((dart) => dart.number).toSet().length >= 2;
    case 'two_different_doubles':
      return doubles.map((dart) => dart.number).toSet().length >= 2;
    case 'all_different_numbers':
      return hitNumbers.length == 3;
    case 'double_then_triple':
      return darts[0].doubleHit && darts[1].triple;
    case 'triple_then_double':
      return darts[0].triple && darts[1].doubleHit;
    default:
      return false;
  }
}

class PartySetupScreen extends StatefulWidget {
  const PartySetupScreen({super.key});
  @override
  State<PartySetupScreen> createState() => _PartySetupScreenState();
}

class _PartySetupScreenState extends State<PartySetupScreen> {
  final List<TextEditingController> names = [
    TextEditingController(text: 'Spieler 1'),
    TextEditingController(text: 'Spieler 2'),
  ];
  final Set<String> selectedCategories = Set<String>.from(partyCategories);
  final List<bool> botPlayers = [false, false];
  final List<String> botLevels = ['Leicht', 'Leicht'];
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _loadNames();
  }

  Future<void> _loadNames() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('dart_party_player_names');
    if (saved != null && saved.isNotEmpty) {
      for (var i = 0; i < saved.length && i < 8; i++) {
        if (i >= names.length) {
          names.add(TextEditingController(text: saved[i]));
          botPlayers.add(false);
          botLevels.add('Leicht');
        } else if (saved[i].trim().isNotEmpty) {
          names[i].text = saved[i];
        }
      }
      if (mounted) setState(() {});
    }
  }

  @override
  void dispose() {
    for (final controller in names) {
      controller.dispose();
    }
    super.dispose();
  }

  void _addPlayer() => setState(() {
        names.add(TextEditingController(text: 'Spieler ${names.length + 1}'));
        botPlayers.add(false);
        botLevels.add('Leicht');
      });

  void _removePlayer(int index) => setState(() {
        names.removeAt(index).dispose();
        botPlayers.removeAt(index);
        botLevels.removeAt(index);
      });

  void _showRules() => showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const LocalizedText('Spielregeln – Partymodus'),
          content: const SingleChildScrollView(
            child: LocalizedText(
              '1. Vor Spielbeginn werden die gewünschten Schwierigkeitskategorien ausgewählt. Aus jeder aktiven Kategorie kommen alle 100 Challenges in den gemeinsamen Stapel. Dazu werden immer 30 Bonuskarten gemischt.\n\n'
              '2. Vor dem Ziehen ist nicht erkennbar, ob eine Challenge oder eine Bonuskarte kommt. Erst nach dem Aufdecken wird die Kartenart sichtbar.\n\n'
              '3. Bei einer Challenge muss der Spieler zuerst Konsequenz A oder B auswählen. Diese Wahl ist danach fest und kann nicht geändert werden. Erst dann startet die Aufgabe.\n\n'
              '4. Jede Challenge ist eine Dartsaufgabe und wird anhand der drei eingetragenen Darts automatisch geprüft. Eigenständige Aktionsaufgaben gibt es nicht mehr.\n\n'
              '5. Bei einer nicht geschafften Aufgabe gilt nur die vorher gewählte Konsequenz. Mit einem Bonus-Schutzschild entfällt die nächste Konsequenz einmalig.\n\n'
              '6. Bonuskarten werden sofort ausgeführt. Sie können die Reihenfolge verändern, einen Zug aussetzen lassen, einen Zusatz-Zug geben oder einen Schutzschild verleihen.\n\n'
              '7. Bots können wie normale Mitspieler hinzugefügt werden. Ihre Stärke ist frei wählbar: Ultra leicht, Leicht, Mittel, Hart oder Experte. Sie ziehen, wählen Konsequenzen und spielen Aufgaben sowie Bonuskarten automatisch.\n\n'
              '8. Jede Karte wird nur einmal gezogen. Das Spiel endet, wenn der gemeinsame Stapel aufgebraucht ist. Alkohol ist freiwillig; ein Wasser-Shot ist immer eine gleichwertige Alternative.',
            ),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))],
        ),
      );

  Future<void> _start() async {
    final playerNames = names.map((controller) => controller.text.trim()).toList();
    if (playerNames.length < 2 || playerNames.any((name) => name.isEmpty) || playerNames.toSet().length != playerNames.length) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: LocalizedText('Bitte mindestens zwei unterschiedliche Spielernamen eintragen.')));
      return;
    }
    if (selectedCategories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: LocalizedText('Bitte mindestens eine Kategorie auswählen.')));
      return;
    }
    setState(() => loading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('dart_party_player_names', playerNames);
      final deck = await loadPartyDeck(selectedCategories);
      final players = List.generate(
        playerNames.length,
        (index) => PartyPlayer(
          playerNames[index],
          isBot: botPlayers[index],
          botDifficulty: botLevels[index],
        ),
      );
      if (!mounted) return;
      final allowed = await MonetizationService.instance.authorizeGameStart(context);
      if (!allowed || !mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => PartyGameScreen(players: players, deck: deck)),
      );
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: LocalizedText('Partystapel konnte nicht geladen werden: $error')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const LocalizedText('Partymodus – Spieler')),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Row(children: [
                const Expanded(child: LocalizedText('PARTYMODUS', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900))),
                IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: _showRules),
              ]),
              const LocalizedText('Lege die Spieler fest und entscheide, welche Schwierigkeitsstufen in den geheim gemischten Stapel kommen.', style: TextStyle(color: Colors.white60)),
              const SizedBox(height: 18),
              const LocalizedText('KATEGORIEN – JE 100 CHALLENGES', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: .6)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                children: partyCategories.map((category) => FilterChip(
                  label: LocalizedText('$category · 100'),
                  selected: selectedCategories.contains(category),
                  onSelected: loading ? null : (selected) => setState(() {
                    if (selected) {
                      selectedCategories.add(category);
                    } else {
                      selectedCategories.remove(category);
                    }
                  }),
                )).toList(),
              ),
              const SizedBox(height: 8),
              LocalizedText('${selectedCategories.length * 100 + 30} Karten im gemischten Stapel inklusive 30 Bonuskarten.', style: const TextStyle(color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 18),
              ...List.generate(names.length, (index) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: TextField(controller: names[index], decoration: InputDecoration(label: LocalizedText('Spieler ${index + 1}')))),
                    if (names.length > 2) IconButton(onPressed: loading ? null : () => _removePlayer(index), icon: const Icon(Icons.close)),
                  ]),
                  const SizedBox(height: 6),
                  Row(children: [
                    Expanded(child: DropdownButtonFormField<bool>(
                      initialValue: botPlayers[index],
                      decoration: const InputDecoration(label: LocalizedText('Spielertyp')),
                      isExpanded: true,
                      items: const [
                        DropdownMenuItem(value: false, child: LocalizedText('Mensch')),
                        DropdownMenuItem(value: true, child: LocalizedText('Bot')),
                      ],
                      onChanged: loading ? null : (value) => setState(() => botPlayers[index] = value ?? false),
                    )),
                    if (botPlayers[index]) const SizedBox(width: 8),
                    if (botPlayers[index]) Expanded(child: DropdownButtonFormField<String>(
                      initialValue: botLevels[index],
                      decoration: const InputDecoration(label: LocalizedText('Bot-Stärke')),
                      isExpanded: true,
                      items: partyBotDifficulties.map((level) => DropdownMenuItem(value: level, child: LocalizedText(level))).toList(),
                      onChanged: loading ? null : (value) => setState(() => botLevels[index] = value ?? 'Leicht'),
                    )),
                  ]),
                ]),
              )),
              OutlinedButton.icon(onPressed: loading || names.length >= 8 ? null : _addPlayer, icon: const Icon(Icons.add), label: const LocalizedText('Spieler hinzufügen')),
              const SizedBox(height: 22),
              FilledButton.icon(onPressed: loading ? null : _start, icon: const Icon(Icons.play_arrow), label: LocalizedText(loading ? 'Stapel wird gemischt …' : 'Partie starten')),
            ],
          ),
        ),
      );
}

class PartyGameScreen extends StatefulWidget {
  final List<PartyPlayer> players;
  final List<PartyCard> deck;
  const PartyGameScreen({super.key, required this.players, required this.deck});
  @override
  State<PartyGameScreen> createState() => _PartyGameScreenState();
}

class _PartyGameScreenState extends State<PartyGameScreen> {
  late final List<PartyCard> deck;
  late List<int> turnOrder;
  int turnPosition = 0;
  PartyCard? currentCard;
  String phase = 'draw';
  int? selectedPenaltyIndex;
  int? selectedBonusTarget;
  final List<DartThrow> darts = [];
  final Map<int, int> skippedTurns = {};
  int extraTurnsPending = 0;
  bool gameOver = false;
  bool _finishAdScheduled = false;
  String? bonusMessage;
  String? turnMessage;
  bool botBusy = false;

  int get currentPlayerIndex => turnOrder[turnPosition];
  PartyPlayer get currentPlayer => widget.players[currentPlayerIndex];
  int get drawnCount => widget.deck.length - deck.length;
  String? get selectedConsequence {
    final card = currentCard;
    if (card == null || selectedPenaltyIndex == null) return null;
    return selectedPenaltyIndex == 0 ? card.consequenceA : card.consequenceB;
  }

  @override
  void initState() {
    super.initState();
    deck = List<PartyCard>.from(widget.deck);
    turnOrder = List<int>.generate(widget.players.length, (index) => index);
    WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
  }

  void _startBotIfNeeded() {
    if (!mounted || gameOver || botBusy || !currentPlayer.isBot) return;
    botBusy = true;
    _playBotTurn();
  }

  Future<void> _playBotTurn() async {
    final bot = currentPlayer;
    final expectedIndex = currentPlayerIndex;
    bool isSameBot() => mounted && !gameOver && currentPlayerIndex == expectedIndex && identical(currentPlayer, bot);

    try {
      await Future.delayed(const Duration(milliseconds: 650));
      var safetySteps = 0;
      while (isSameBot() && safetySteps < 24) {
        safetySteps++;
        switch (phase) {
          case 'draw':
            _drawCard();
            await Future.delayed(const Duration(milliseconds: 700));
            break;
          case 'choosePenalty':
            _choosePenalty(choosePartyBotConsequence(Random()));
            await Future.delayed(const Duration(milliseconds: 450));
            break;
          case 'ready':
            _startChallenge();
            await Future.delayed(const Duration(milliseconds: 350));
            break;
          case 'dartChallenge':
            final card = currentCard;
            if (card == null || card.goal == null) {
              setState(() => _resolveChallengeInsideSetState(false));
              break;
            }
            if (darts.length < 3) {
              _addPartyDart(_botThrow(bot.botDifficulty));
              await Future.delayed(const Duration(milliseconds: 420));
            } else {
              setState(() => _resolveChallengeInsideSetState(evaluatePartyDartGoal(card.goal!, darts)));
            }
            break;
          case 'manualChallenge':
            final card = currentCard;
            final success = card != null && evaluatePartyBotAction(
              bot.botDifficulty,
              card.category,
              Random(),
            );
            _resolveManualChallenge(success);
            await Future.delayed(const Duration(milliseconds: 650));
            break;
          case 'bonusChooseTarget':
            final candidates = List<int>.generate(widget.players.length, (index) => index)
                .where((index) => index != currentPlayerIndex)
                .toList();
            if (candidates.isNotEmpty) {
              selectedBonusTarget = candidates[Random().nextInt(candidates.length)];
              _applySelectedBonusTarget();
            } else {
              setState(() => phase = 'bonusReady');
            }
            await Future.delayed(const Duration(milliseconds: 550));
            break;
          case 'success':
          case 'failed':
          case 'protected':
          case 'bonusReady':
            await Future.delayed(const Duration(milliseconds: 700));
            _continueAfterCard();
            break;
          default:
            return;
        }
      }
    } finally {
      botBusy = false;
      if (mounted && !gameOver && currentPlayer.isBot) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
      }
    }
  }

  void _showRules() => showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const LocalizedText('Partymodus'),
          content: const SingleChildScrollView(child: LocalizedText(
            'Der Stapel enthält Challenges und Bonuskarten, die vor Spielbeginn gemeinsam gemischt werden. Du erkennst den Kartentyp erst nach dem Ziehen.\n\n'
            'Bei Challenges wählst du zuerst eine von zwei Konsequenzen. Danach ist die Wahl gesperrt und die Aufgabe startet. Alle Challenges sind Dartsaufgaben und werden automatisch anhand der drei Würfe ausgewertet.\n\n'
            'Bonuswirkungen werden direkt aktiviert. Schutzschilde retten vor der nächsten Konsequenz, Aussetzen betrifft einen kompletten Zug.\n\n'
            'Bots ziehen Karten, wählen vorab eine Konsequenz und absolvieren die Dartsaufgaben automatisch.\n\n'
            'Shots sind freiwillig; Wasser ist eine gleichwertige Alternative. Alle körperlichen Aufgaben können bei Bedarf ausgelassen oder angepasst werden.',
          )),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const LocalizedText('Schließen'))],
        ),
      );

  int _nextScheduledPlayer() => turnOrder[(turnPosition + 1) % turnOrder.length];

  void _rotateUpcoming({required bool reverse}) {
    final current = currentPlayerIndex;
    final upcoming = List<int>.generate(
      turnOrder.length - 1,
      (index) => turnOrder[(turnPosition + index + 1) % turnOrder.length],
    );
    if (reverse) {
      final reversed = upcoming.reversed.toList();
      turnOrder = [current, ...reversed];
    } else {
      upcoming.shuffle(Random());
      turnOrder = [current, ...upcoming];
    }
    turnPosition = 0;
  }

  void _applyBonus(PartyCard card) {
    setState(() {
      switch (card.effect) {
        case 'skip_next':
          final target = _nextScheduledPlayer();
          skippedTurns[target] = (skippedTurns[target] ?? 0) + 1;
          bonusMessage = '${widget.players[target].name} muss einmal aussetzen.';
          phase = 'bonusReady';
          break;
        case 'reverse_order':
          _rotateUpcoming(reverse: true);
          bonusMessage = 'Die Reihenfolge für die kommenden Züge wurde umgedreht.';
          phase = 'bonusReady';
          break;
        case 'shuffle_order':
          _rotateUpcoming(reverse: false);
          bonusMessage = 'Die Reihenfolge der kommenden Züge wurde neu gemischt.';
          phase = 'bonusReady';
          break;
        case 'extra_turn':
          extraTurnsPending++;
          bonusMessage = 'Du darfst direkt noch eine Karte ziehen.';
          phase = 'bonusReady';
          break;
        case 'shield':
          currentPlayer.shielded = true;
          bonusMessage = 'Dein Schutzschild bleibt aktiv, bis eine Challenge misslingt.';
          phase = 'bonusReady';
          break;
        case 'skip_chosen':
          selectedBonusTarget = null;
          bonusMessage = 'Wähle einen Mitspieler, der seinen nächsten Zug aussetzt.';
          phase = 'bonusChooseTarget';
          break;
        default:
          bonusMessage = 'Diese Bonuskarte hat keinen bekannten Effekt.';
          phase = 'bonusReady';
      }
      currentPlayer.bonusesDrawn++;
    });
  }

  void _drawCard() {
    if (gameOver || currentCard != null) return;
    turnMessage = null;
    if (deck.isEmpty) {
      setState(() => gameOver = true);
      return;
    }
    final card = deck.removeAt(0);
    setState(() {
      currentCard = card;
      currentPlayer.cardsDrawn++;
      selectedPenaltyIndex = null;
      selectedBonusTarget = null;
      darts.clear();
      bonusMessage = null;
      phase = card.isBonus ? 'bonusReady' : 'choosePenalty';
    });
    if (card.isBonus) _applyBonus(card);
  }

  void _choosePenalty(int index) {
    if (phase != 'choosePenalty' || selectedPenaltyIndex != null) return;
    setState(() {
      selectedPenaltyIndex = index;
      phase = 'ready';
    });
  }

  void _startChallenge() {
    final card = currentCard;
    if (card == null || card.isBonus || selectedPenaltyIndex == null || phase != 'ready') return;
    setState(() => phase = card.isDartTask ? 'dartChallenge' : 'manualChallenge');
  }

  void _resolveChallengeInsideSetState(bool success) {
    if (success) {
      currentPlayer.challengesPassed++;
      phase = 'success';
    } else {
      currentPlayer.challengesFailed++;
      if (currentPlayer.shielded) {
        currentPlayer.shielded = false;
        phase = 'protected';
      } else {
        phase = 'failed';
      }
    }
  }

  void _resolveManualChallenge(bool success) {
    if (phase != 'manualChallenge') return;
    setState(() => _resolveChallengeInsideSetState(success));
  }

  void _addPartyDart(DartThrow dart) {
    final card = currentCard;
    if (phase != 'dartChallenge' || card == null || card.goal == null || darts.length >= 3) return;
    final updated = [...darts, dart];
    setState(() {
      darts.add(dart);
      if (updated.length == 3) {
        _resolveChallengeInsideSetState(evaluatePartyDartGoal(card.goal!, updated));
      }
    });
  }

  void _undoPartyDart() {
    if (phase == 'dartChallenge' && darts.isNotEmpty) setState(() => darts.removeLast());
  }

  void _resetPartyDarts() {
    if (phase == 'dartChallenge' && darts.isNotEmpty) setState(() => darts.clear());
  }

  void _applySelectedBonusTarget() {
    final target = selectedBonusTarget;
    if (phase != 'bonusChooseTarget' || target == null || target == currentPlayerIndex) return;
    setState(() {
      skippedTurns[target] = (skippedTurns[target] ?? 0) + 1;
      bonusMessage = '${widget.players[target].name} setzt den nächsten Zug aus.';
      phase = 'bonusReady';
    });
  }

  void _advancePlayer() {
    for (var attempt = 0; attempt < turnOrder.length; attempt++) {
      turnPosition = (turnPosition + 1) % turnOrder.length;
      final candidate = turnOrder[turnPosition];
      final remainingSkips = skippedTurns[candidate] ?? 0;
      if (remainingSkips > 0) {
        if (remainingSkips == 1) {
          skippedTurns.remove(candidate);
        } else {
          skippedTurns[candidate] = remainingSkips - 1;
        }
        turnMessage = '${widget.players[candidate].name} setzt einen Zug aus.';
        continue;
      }
      return;
    }
  }

  void _continueAfterCard() {
    if (currentCard == null) return;
    setState(() {
      currentCard = null;
      selectedPenaltyIndex = null;
      selectedBonusTarget = null;
      darts.clear();
      bonusMessage = null;
      phase = 'draw';
      if (deck.isEmpty) {
        gameOver = true;
      } else if (extraTurnsPending > 0) {
        extraTurnsPending--;
        turnMessage = '${currentPlayer.name} ist durch die Bonuskarte direkt noch einmal dran.';
      } else {
        turnMessage = null;
        _advancePlayer();
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _startBotIfNeeded());
  }

  Widget _playerOverview() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const LocalizedText('SPIELERÜBERSICHT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8)),
          const SizedBox(height: 5),
          ...List.generate(widget.players.length, (index) {
            final p = widget.players[index];
            final active = index == currentPlayerIndex && !gameOver;
            return Card(
              child: ListTile(
                leading: Icon(active ? (p.isBot ? Icons.smart_toy : Icons.radio_button_checked) : (p.isBot ? Icons.smart_toy_outlined : Icons.person), color: active ? purple : Colors.white54),
                title: LocalizedText('${p.name}${p.isBot ? ' · BOT' : ''}', style: TextStyle(fontWeight: active ? FontWeight.w900 : FontWeight.normal)),
                subtitle: LocalizedText('${p.isBot ? '${p.botDifficulty} · ' : ''}${p.challengesPassed} geschafft · ${p.challengesFailed} nicht geschafft · ${p.bonusesDrawn} Bonus'),
                trailing: active ? const LocalizedText('AM ZUG', style: TextStyle(color: purple, fontWeight: FontWeight.bold, fontSize: 11)) : (p.shielded ? const Icon(Icons.shield, color: Colors.lightBlueAccent) : null),
              ),
            );
          }),
        ],
      );

  Widget _challengeCard(PartyCard card) {
    final selected = selectedConsequence;
    return DartPartyCardSurface(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const LocalizedText('DART PARTY', style: TextStyle(color: brandGold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
          const Spacer(),
          LocalizedText(card.category.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8, color: brandGold)),
          const SizedBox(width: 8),
          LocalizedText(card.isDartTask ? 'DARTS' : 'AKTION', style: const TextStyle(color: Colors.white60, fontSize: 10, fontWeight: FontWeight.bold)),
          const SizedBox(width: 8),
          LocalizedText('#${card.id}', style: const TextStyle(color: Colors.white38, fontSize: 11)),
        ]),
        const SizedBox(height: 9),
        Container(height: 1, color: brandGold.withOpacity(.35)),
        const SizedBox(height: 12),
        LocalizedText(card.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, height: 1.25)),
        const SizedBox(height: 16),
        if (phase == 'choosePenalty') ...[
          if (currentPlayer.isBot) ...[
            const LocalizedText('BOT WÄHLT VORHER SEINE KONSEQUENZ …', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white60, letterSpacing: .5)),
            const SizedBox(height: 8),
            const LinearProgressIndicator(),
          ] else ...[
            const LocalizedText('WÄHLE VOR DER AUFGABE DEINE KONSEQUENZ', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white60, letterSpacing: .5)),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: () => _choosePenalty(0), child: LocalizedText('A · ${card.consequenceA}', textAlign: TextAlign.center))),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: () => _choosePenalty(1), child: LocalizedText('B · ${card.consequenceB}', textAlign: TextAlign.center))),
            const SizedBox(height: 4),
            const LocalizedText('Mit deiner Auswahl legst du dich fest. Ein Wechsel ist danach nicht möglich.', style: TextStyle(fontSize: 11, color: Colors.white54)),
          ],
        ] else if (phase == 'ready') ...[
          const LocalizedText('AUSWAHL – FEST', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.greenAccent)),
          const SizedBox(height: 6),
          LocalizedText(selected ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          if (currentPlayer.isBot)
            const LocalizedText('Bot startet die Challenge automatisch …', style: TextStyle(color: Colors.white60))
          else
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _startChallenge, icon: const Icon(Icons.play_arrow), label: const LocalizedText('Challenge starten'))),
        ] else if (phase == 'dartChallenge') ...[
          LocalizedText(currentPlayer.isBot ? 'BOT WIRFT AUTOMATISCH' : 'DREI DARTS EINGEBEN – DIE APP PRÜFT DAS ERGEBNIS', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white60)),
          const SizedBox(height: 8),
          _DartProgress(darts: darts, total: darts.fold<int>(0, (sum, dart) => sum + dart.score), onUndo: currentPlayer.isBot || darts.isEmpty ? null : _undoPartyDart, onReset: currentPlayer.isBot || darts.isEmpty ? null : _resetPartyDarts, completionText: 'Die Challenge wird nach Dart 3 automatisch ausgewertet.'),
          if (darts.length < 3 && currentPlayer.isBot)
            const Card(child: Padding(padding: EdgeInsets.all(12), child: LocalizedText('Bot wirft seine drei Darts …', style: TextStyle(color: Colors.white60))))
          else if (darts.length < 3)
            DartEntry(onChanged: _addPartyDart),
        ] else if (phase == 'manualChallenge') ...[
          LocalizedText(currentPlayer.isBot ? 'BOT VERSUCHT DIE AUFGABE …' : 'FÜHRE DIE AUFGABE AUS UND BESTÄTIGE DAS ERGEBNIS', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white60)),
          const SizedBox(height: 12),
          if (currentPlayer.isBot)
            const LinearProgressIndicator()
          else ...[
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _resolveManualChallenge(true), icon: const Icon(Icons.check), label: const LocalizedText('Geschafft!'))),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () => _resolveManualChallenge(false), icon: const Icon(Icons.close), label: const LocalizedText('Nicht geschafft'))),
          ],
        ] else if (phase == 'success') ...[
          const Row(children: [Icon(Icons.check_circle, color: Colors.greenAccent), SizedBox(width: 8), LocalizedText('CHALLENGE GESCHAFFT', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.greenAccent))]),
          if (card.isDartTask) Padding(padding: const EdgeInsets.only(top: 6), child: LocalizedText('Ergebnis: ${darts.fold<int>(0, (sum, dart) => sum + dart.score)} Punkte')),
          const SizedBox(height: 12),
          if (currentPlayer.isBot)
            const LocalizedText('Bot macht automatisch weiter …', style: TextStyle(color: Colors.white60))
          else
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _continueAfterCard, child: const LocalizedText('Weiter zum nächsten Spieler'))),
        ] else if (phase == 'failed') ...[
          const Row(children: [Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent), SizedBox(width: 8), LocalizedText('CHALLENGE NICHT GESCHAFFT', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.orangeAccent))]),
          const SizedBox(height: 8),
          const LocalizedText('Jetzt gilt die vorher ausgewählte Konsequenz:', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          LocalizedText(selected ?? '', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          if (currentPlayer.isBot)
            const LocalizedText('Bot erledigt die Konsequenz und macht weiter …', style: TextStyle(color: Colors.white60))
          else
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _continueAfterCard, child: const LocalizedText('Konsequenz erledigt – weiter'))),
        ] else if (phase == 'protected') ...[
          const Row(children: [Icon(Icons.shield, color: Colors.lightBlueAccent), SizedBox(width: 8), LocalizedText('SCHUTZSCHILD AKTIVIERT', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.lightBlueAccent))]),
          const SizedBox(height: 6),
          const LocalizedText('Die Aufgabe ist misslungen, aber dein Schutzschild übernimmt die Konsequenz. Du musst keine der beiden Optionen ausführen.'),
          const SizedBox(height: 12),
          if (currentPlayer.isBot)
            const LocalizedText('Bot macht automatisch weiter …', style: TextStyle(color: Colors.white60))
          else
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _continueAfterCard, child: const LocalizedText('Weiter'))),
        ],
      ]),
    );
  }

  Widget _bonusCard(PartyCard card) => DartPartyCardSurface(
        padding: const EdgeInsets.all(17),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [LocalizedText('DART PARTY', style: TextStyle(color: brandGold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.4)), Spacer(), Icon(Icons.card_giftcard, color: brandGold), SizedBox(width: 8), LocalizedText('BONUSKARTE', style: TextStyle(fontWeight: FontWeight.w900, color: brandGold, letterSpacing: .8))]),
          const SizedBox(height: 9),
          Container(height: 1, color: brandGold.withOpacity(.35)),
          const SizedBox(height: 12),
          LocalizedText(card.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7),
          LocalizedText(card.description, style: const TextStyle(fontSize: 15, height: 1.3)),
          if (bonusMessage != null) ...[
            const SizedBox(height: 12),
            Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: brandGold.withOpacity(.12), borderRadius: BorderRadius.circular(12)), child: LocalizedText(bonusMessage!, style: const TextStyle(fontWeight: FontWeight.bold))),
          ],
          if (phase == 'bonusChooseTarget') ...[
            const SizedBox(height: 10),
            if (currentPlayer.isBot)
              const LocalizedText('Bot wählt automatisch einen Mitspieler …', style: TextStyle(color: Colors.white60))
            else ...[
              DropdownButtonFormField<int>(
                initialValue: selectedBonusTarget,
                decoration: const InputDecoration(label: LocalizedText('Mitspieler auswählen')),
                items: List.generate(widget.players.length, (index) => index).where((index) => index != currentPlayerIndex).map((index) => DropdownMenuItem(value: index, child: LocalizedText(widget.players[index].name))).toList(),
                onChanged: (value) => setState(() => selectedBonusTarget = value),
              ),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: FilledButton(onPressed: selectedBonusTarget == null ? null : _applySelectedBonusTarget, child: const LocalizedText('Aussetzen festlegen'))),
            ],
          ] else if (phase == 'bonusReady') ...[
            const SizedBox(height: 12),
            if (currentPlayer.isBot)
              const LocalizedText('Bot übernimmt den Bonus und macht automatisch weiter …', style: TextStyle(color: Colors.white60))
            else
              SizedBox(width: double.infinity, child: FilledButton(onPressed: _continueAfterCard, child: const LocalizedText('Bonus übernehmen – weiter'))),
          ],
        ]),
      );


  Widget _finishedView() {
    if (!_finishAdScheduled) {
      _finishAdScheduled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future.delayed(const Duration(milliseconds: 1200), () {
          if (mounted) MonetizationService.instance.showInterstitialIfAvailable();
        });
      });
    }
    final sorted = List<PartyPlayer>.from(widget.players);
    return Scaffold(
      appBar: AppBar(title: const LocalizedText('Partymodus – Ergebnis')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        const Icon(Icons.celebration, size: 64, color: Colors.amberAccent),
        const SizedBox(height: 12),
        const LocalizedText('DER STAPEL IST LEER', textAlign: TextAlign.center, style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        LocalizedText('${drawnCount} von ${widget.deck.length} Karten wurden gezogen.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
        const SizedBox(height: 18),
        const LocalizedText('PARTY-ÜBERSICHT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8)),
        ...sorted.map((p) => Card(child: ListTile(
          leading: Icon(p.isBot ? Icons.smart_toy : Icons.person, color: Colors.white54),
          title: LocalizedText('${p.name}${p.isBot ? ' · Bot (${p.botDifficulty})' : ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: LocalizedText('${p.challengesPassed} Challenges geschafft · ${p.challengesFailed} nicht geschafft · ${p.bonusesDrawn} Bonuskarten'),
          trailing: LocalizedText('${p.cardsDrawn} Karten', style: const TextStyle(fontWeight: FontWeight.bold, color: purple)),
        ))),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false), icon: const Icon(Icons.home), label: const LocalizedText('Zurück zum Hauptmenü')),
      ])),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (gameOver) return _finishedView();
    final card = currentCard;
    return Scaffold(
      appBar: AppBar(title: const LocalizedText('Partymodus'), actions: [IconButton(tooltip: AppLocalization.immediate('Spielregeln'), icon: const Icon(Icons.help_outline), onPressed: _showRules)]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: LocalizedText(currentPlayer.isBot ? '${currentPlayer.name} · BOT' : currentPlayer.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
            if (currentPlayer.isBot) const Padding(padding: EdgeInsets.only(right: 8), child: Icon(Icons.smart_toy, color: purple, size: 19)),
            LocalizedText('${drawnCount}/${widget.deck.length}', style: const TextStyle(color: Colors.white60, fontWeight: FontWeight.bold)),
          ]),
          if (currentPlayer.isBot) Padding(padding: const EdgeInsets.only(top: 4), child: LocalizedText('BOT AM ZUG · ${currentPlayer.botDifficulty}', style: const TextStyle(color: purple, fontWeight: FontWeight.bold, fontSize: 11))),
          const SizedBox(height: 4),
          LocalizedText('Karte ${currentPlayer.cardsDrawn} · Noch ${deck.length} verdeckte Karten im Stapel', style: const TextStyle(color: Colors.white60, fontSize: 12)),
          if (currentPlayer.shielded) const Padding(padding: EdgeInsets.only(top: 6), child: Row(children: [Icon(Icons.shield, color: Colors.lightBlueAccent, size: 16), SizedBox(width: 5), LocalizedText('Schutzschild bereit', style: TextStyle(color: Colors.lightBlueAccent, fontWeight: FontWeight.bold, fontSize: 12))])),
        ]))),
        if (turnMessage != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: LocalizedText(turnMessage!, style: const TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold))),
        if (card == null) Column(children: [
          const DartPartyCardBack(),
          const SizedBox(height: 10),
          const LocalizedText('Die nächste Karte ist verdeckt. Erst beim Ziehen erkennst du die Kartenart.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 14),
          if (currentPlayer.isBot)
            const Card(child: Padding(padding: EdgeInsets.all(12), child: LocalizedText('Bot zieht automatisch eine verdeckte Karte …', style: TextStyle(color: Colors.white60))))
          else
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _drawCard, icon: const Icon(Icons.touch_app), label: const LocalizedText('Karte ziehen'))),
        ])
        else if (card.isBonus) _bonusCard(card)
        else _challengeCard(card),
        const SizedBox(height: 14),
        _playerOverview(),
      ])),
    );
  }
}
