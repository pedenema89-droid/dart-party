import 'package:flutter_test/flutter_test.dart';
import 'package:dart_party/main.dart';

void main() {
  group('Kartenrally', () {
    test('das Ziel gilt auch bei Überschreitung als erreicht', () {
      expect(rallyTargetReached(49, 50), isFalse);
      expect(rallyTargetReached(50, 50), isTrue);
      expect(rallyTargetReached(53, 50), isTrue);
    });

    test('es bleiben immer höchstens zwei offene Karten sichtbar', () {
      final deck = [
        const ChallengeCard('1', 'Aufgabe 1', 'Easy'),
        const ChallengeCard('2', 'Aufgabe 2', 'Medium'),
        const ChallengeCard('3', 'Aufgabe 3', 'Hard'),
      ];
      final player = Player('Testspieler', deck);

      expect(player.openCards.map((entry) => entry.card.id).toList(), ['1', '2']);

      player.openCards.first.state = CardState.completed;
      expect(player.openCards.map((entry) => entry.card.id).toList(), ['2', '3']);

      player.openCards.first.state = CardState.crossed;
      expect(player.openCards.map((entry) => entry.card.id).toList(), ['3']);
    });
  });
}
