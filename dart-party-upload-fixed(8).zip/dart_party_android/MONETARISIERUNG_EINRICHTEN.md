# Dart Party – Werbung und In-App-Käufe einrichten

Hinweis zur Reparaturversion 1.3.2: Die AdMob-SDK ist vorübergehend aus dem Projekt entfernt, weil der bisher tatsächlich ausgeführte GitHub-Workflow die erforderliche AdMob-App-ID nicht in das Android-Manifest geschrieben hat. Die folgenden Schritte beschreiben die spätere erneute Einrichtung; Anzeigen sind in 1.3.2 nicht aktiv. In-App-Käufe bleiben separat enthalten.

## 1. AdMob-Konto und Anzeigen einrichten

1. Öffne [Google AdMob](https://admob.google.com/) und melde dich mit deinem Google-Konto an.
2. Füge eine Android-App hinzu. Falls Dart Party noch nicht bei Google Play veröffentlicht ist, wähle zunächst die Option, dass die App noch nicht im Store gelistet ist.
3. Lege unter **Anzeigenblöcke** genau diese zwei Formate an:
   - **App-Start-Anzeige (App Open):** erscheint beim Starten der App über der Startansicht.
   - **Interstitial (Interstitial):** wird an den natürlichen Übergängen vor einem Spiel und nach einem Ergebnis angezeigt.
4. Öffne `lib/monetization.dart` und ersetze die beiden Testwerte durch deine eigenen Anzeigenblock-IDs:

   ```dart
   static const String appOpenTestAdUnitId = 'DEINE_APP_OPEN_ANZEIGENBLOCK_ID';
   static const String interstitialTestAdUnitId = 'DEINE_INTERSTITIAL_ANZEIGENBLOCK_ID';
   ```

5. Öffne `.github/workflows/android.yml`. Ersetze im Schritt **AdMob und Android-Mindestversion konfigurieren** die Variable `app_id` durch deine AdMob-App-ID. Das ist die App-ID, nicht eine Anzeigenblock-ID.
6. Richte in AdMob unter **Datenschutz und Mitteilungen** eine passende Einwilligungsnachricht für den Europäischen Wirtschaftsraum ein. Die App fragt die Einwilligungsinformationen bei jedem Start erneut ab und fordert Anzeigen nur an, wenn UMP dies erlaubt.

**Wichtig beim Testen:** Lass zunächst alle Google-Test-IDs unverändert. Verwende niemals deine echten Anzeigenblöcke beim eigenen Testen oder beim wiederholten Anklicken. Google weist darauf hin, dass Tests mit echten Anzeigen zu einer Kontosperre führen können. Erst wenn alles funktioniert, tauschst du die IDs vor dem Release aus.

## 2. Drei Kaufprodukte in Google Play anlegen

Öffne die [Google Play Console](https://play.google.com/console/), wähle Dart Party und gehe zu **Monetarisieren**. Lege dort die Produkte mit exakt diesen IDs an:

| Produkt-ID | Produkttyp | Preis | Was wird freigeschaltet? |
|---|---|---:|---|
| `dart_party_monthly_unlimited` | Abo, monatlich automatisch verlängernd | 1,49 € / Monat | Unbegrenzt spielen; Werbung bleibt |
| `dart_party_lifetime_unlimited` | Einmaliger Kauf, nicht verbrauchbar | 14,99 € | Dauerhaft unbegrenzt spielen; Werbung bleibt |
| `dart_party_remove_ads` | Einmaliger Kauf, nicht verbrauchbar | 6,99 € | Werbung dauerhaft entfernen; zwei Spiele pro Tag bleiben |

Beim Abo muss der Basisplan auf monatliche automatische Verlängerung eingestellt sein. In der App steht, dass das Abo automatisch verlängert wird und über Google Play gekündigt werden kann. Google verlangt, dass Kosten, Abrechnungsrhythmus und automatische Verlängerung für den Nutzer klar erkennbar sind.

Die App liest die tatsächlichen Produktpreise von Google Play. Die Euro-Beträge im Quellcode dienen nur als Fallback, solange Google Play die Produkte noch nicht liefert.

## 3. Mit Google Play testen

1. Lade die App über den GitHub-Actions-Workflow und lade das erzeugte APK/AAB in einen **internen Testtrack** deiner Play Console hoch.
2. Füge deine Google-Konten unter **Lizenztester** hinzu.
3. Aktiviere und veröffentliche die drei Produkte für den Test.
4. Installiere die Testversion über den Link des internen Play-Tests auf dem Android-Gerät. Ein manuell installiertes APK zeigt nicht zuverlässig die im Play Store angelegten Produkte.
5. Prüfe diese Fälle:
   - Ohne Kauf sind zwei Spielstarts möglich; beim dritten Start öffnet sich die Premium-Seite.
   - Das Monatsabo und der Einmalkauf für 14,99 € heben das Tageslimit auf.
   - Der Einmalkauf für 6,99 € unterdrückt Anzeigen, hebt das Tageslimit aber nicht auf.
   - Käufe lassen sich über **Käufe wiederherstellen** erneut abrufen.
   - Ohne Einwilligung oder ohne geladenes Werbemittel läuft das Spiel ohne Anzeigenunterbrechung weiter.

## 4. Was vor dem öffentlichen Release noch wichtig ist

- **Eigene Anzeigen-IDs einsetzen:** Die mitgelieferten IDs sind ausschließlich Google-Test-IDs.
- **Käufe sicher prüfen:** Der aktuelle Stand verarbeitet Kaufmeldungen lokal auf dem Gerät und speichert die Freischaltungen in den App-Daten. Das ist zum Einrichten und Testen geeignet, aber kein manipulationssicherer Zahlungsnachweis. Für einen belastbaren Produktivbetrieb müssen Kauf-Tokens auf einem eigenen Server über die Google Play Developer API geprüft und Abo-Status, Verlängerungen, Kündigungen und Erstattungen dort aktuell gehalten werden.
- **Tageslimit:** Die zwei kostenlosen Spiele werden aktuell lokal gezählt. Das lässt sich durch Löschen der App-Daten oder Verstellen der Gerätezeit umgehen. Ein geräteübergreifend und manipulationssicher durchgesetztes Limit würde ein Nutzerkonto und einen Backend-Dienst benötigen.
- **Datenschutz und Store-Angaben:** Hinterlege eine Datenschutzerklärung und vervollständige die Anzeigen-, Datenschutz- und Daten-Sicherheitsangaben in Play Console und AdMob.
- **Paket-ID:** Vor dem ersten Play-Store-Upload muss die endgültige, weltweit eindeutige Android-Paket-ID feststehen. Sie darf später nicht beliebig geändert werden. Die Android-Plattformdateien werden im GitHub-Workflow neu erzeugt; deshalb müssen spätere Änderungen an der Paket-ID auch dort berücksichtigt werden.

## 5. Technischer Stand dieser Version

- Version: `1.3.0+15`
- Werbe-SDK: `google_mobile_ads`
- Einwilligung: Google UMP über `google_mobile_ads`
- Käufe: `in_app_purchase`
- Lokaler Spielzähler: `shared_preferences`
- Android-Mindestversion: API 24
- Der GitHub-Workflow führt `flutter pub get`, `flutter test` und `flutter build apk --release` aus.

Die Paketdatei kann hier vorbereitet und strukturell geprüft werden. Ein vollständiger Flutter-Build wurde in dieser Arbeitsumgebung nicht ausgeführt, da dort kein Flutter-SDK verfügbar ist. Der GitHub-Workflow soll diesen Build übernehmen.


## Firebase Google-Anmeldung (Version 1.3.1)

Die Firebase-Konfigurationsdatei `google-services.json` liegt im Projektstamm.
Der GitHub-Workflow kopiert sie beim Build nach `android/app/`, aktiviert das
Google-Services-Gradle-Plugin und setzt die Android applicationId auf
`de.dartsparty.app`.

Beim App-Start wird Firebase initialisiert. Ohne erfolgreiche Google-Anmeldung
wird ausschließlich die Anmeldeseite angezeigt; die Startseite und Spielmodi
bleiben gesperrt. Die Anmeldung bleibt über Firebase Authentication gespeichert.

Vor dem ersten echten Test müssen in Firebase Authentication Google aktiviert
sein und die SHA-1-/SHA-256-Fingerprints des verwendeten Signaturschlüssels
hinterlegt werden. Die Cloud-Funktion für das serverseitige Tageslimit ist
noch nicht Bestandteil dieses Schritts.
