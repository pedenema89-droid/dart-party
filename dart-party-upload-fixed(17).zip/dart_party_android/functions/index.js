const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue, Timestamp } = require('firebase-admin/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const { google } = require('googleapis');
const { createHash } = require('node:crypto');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const {
  berlinDateKey,
  initialWallet,
  normalizeWallet,
  refreshDailyTokens,
  isUnlimited,
  consumeOneToken,
  publicWallet,
} = require('./wallet_logic');

initializeApp();
setGlobalOptions({
  region: 'europe-west3',
  maxInstances: 10,
});

const db = getFirestore();

function requireUid(request) {
  const uid = request.auth && request.auth.uid;
  if (!uid) {
    throw new HttpsError('unauthenticated', 'Bitte melde dich mit Google an.');
  }
  return uid;
}

function validateMatchId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{12,100}$/.test(value);
}

function walletDocument(uid) {
  return db.collection('users').doc(uid);
}

exports.getWallet = onCall(async (request) => {
  const uid = requireUid(request);
  const userRef = walletDocument(uid);
  const today = berlinDateKey();

  const wallet = await db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(userRef);
    const current = snapshot.exists
      ? normalizeWallet(snapshot.data(), today)
      : initialWallet(today);
    const refreshed = refreshDailyTokens(current, today);
    const needsWrite = !snapshot.exists || current.dailyDate !== today;
    if (needsWrite) {
      const writeData = {
        ...refreshed,
        updatedAt: FieldValue.serverTimestamp(),
      };
      if (!snapshot.exists) writeData.createdAt = FieldValue.serverTimestamp();
      transaction.set(userRef, writeData, { merge: true });
    }
    return refreshed;
  });

  return publicWallet(wallet);
});

exports.startMatch = onCall(async (request) => {
  const uid = requireUid(request);
  const matchId = request.data && request.data.matchId;
  if (!validateMatchId(matchId)) {
    throw new HttpsError('invalid-argument', 'Ungültige Spielkennung.');
  }

  const userRef = walletDocument(uid);
  const matchRef = userRef.collection('matchRequests').doc(matchId);
  const today = berlinDateKey();

  const result = await db.runTransaction(async (transaction) => {
    const [userSnapshot, matchSnapshot] = await Promise.all([
      transaction.get(userRef),
      transaction.get(matchRef),
    ]);

    const current = userSnapshot.exists
      ? normalizeWallet(userSnapshot.data(), today)
      : initialWallet(today);
    let wallet = refreshDailyTokens(current, today);

    if (matchSnapshot.exists) {
      // Idempotency: lost responses/retries for the same attempted game do not
      // consume a second token.
      return {
        allowed: true,
        alreadyStarted: true,
        ...publicWallet(wallet),
      };
    }

    let tokenCharged = false;
    let tokenSource = 'unlimited';
    if (!isUnlimited(wallet)) {
      const spend = consumeOneToken(wallet);
      wallet = spend.wallet;
      if (!spend.consumed) {
        const noTokensWrite = {
          ...wallet,
          updatedAt: FieldValue.serverTimestamp(),
        };
        if (!userSnapshot.exists) noTokensWrite.createdAt = FieldValue.serverTimestamp();
        transaction.set(userRef, noTokensWrite, { merge: true });
        return {
          allowed: false,
          reason: 'NO_TOKENS',
          ...publicWallet(wallet),
        };
      }
      tokenCharged = true;
      tokenSource = spend.source;
    }

    const walletWrite = {
      ...wallet,
      updatedAt: FieldValue.serverTimestamp(),
    };
    if (!userSnapshot.exists) walletWrite.createdAt = FieldValue.serverTimestamp();
    transaction.set(userRef, walletWrite, { merge: true });
    transaction.create(matchRef, {
      matchId,
      uid,
      status: 'started',
      tokenCharged,
      tokenSource,
      startedAt: FieldValue.serverTimestamp(),
    });

    return {
      allowed: true,
      alreadyStarted: false,
      ...publicWallet(wallet),
    };
  });

  return result;
});

const PLAY_PACKAGE_NAME = 'de.dartsparty.app';
const PLAY_ANDROID_PUBLISHER_SCOPE = 'https://www.googleapis.com/auth/androidpublisher';
const { PLAY_PRODUCTS } = require('./purchase_catalog');

async function getAndroidPublisher() {
  const auth = new google.auth.GoogleAuth({
    scopes: [PLAY_ANDROID_PUBLISHER_SCOPE],
  });
  return google.androidpublisher({ version: 'v3', auth });
}

function purchaseTokenHash(token) {
  return createHash('sha256').update(token).digest('hex');
}

function toMillis(value) {
  if (!value) return null;
  if (typeof value.toMillis === 'function') return value.toMillis();
  if (value instanceof Date) return value.getTime();
  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : null;
}

exports.verifyPlayPurchase = onCall(async (request) => {
  const uid = requireUid(request);
  const productId = request.data && request.data.productId;
  const purchaseToken = request.data && request.data.purchaseToken;
  const product = Object.prototype.hasOwnProperty.call(PLAY_PRODUCTS, productId)
    ? PLAY_PRODUCTS[productId]
    : null;

  if (!product || typeof purchaseToken !== 'string' ||
      purchaseToken.length < 10 || purchaseToken.length > 4096) {
    throw new HttpsError('invalid-argument', 'Ungültige Kaufdaten.');
  }

  let verifiedSubscription = null;
  let verifiedPurchaseQuantity = 1;
  let verifiedAccountId = null;
  const expectedAccountId = purchaseTokenHash(uid);
  const publisher = await getAndroidPublisher();
  try {
    if (product.kind === 'subscription') {
      const response = await publisher.purchases.subscriptionsv2.get({
        packageName: PLAY_PACKAGE_NAME,
        token: purchaseToken,
      });
      const subscription = response.data;
      const lineItem = (subscription.lineItems || []).find(
        (item) => item.productId === productId,
      );
      if (!lineItem) {
        throw new HttpsError('failed-precondition', 'Das Google-Play-Abo passt nicht zum Produkt.');
      }
      const expiryMillis = toMillis(lineItem.expiryTime);
      const validStates = new Set([
        'SUBSCRIPTION_STATE_ACTIVE',
        'SUBSCRIPTION_STATE_IN_GRACE_PERIOD',
        'SUBSCRIPTION_STATE_CANCELED',
      ]);
      const entitled = validStates.has(subscription.subscriptionState) &&
        expiryMillis !== null && expiryMillis > Date.now();
      verifiedAccountId = subscription.obfuscatedExternalAccountId || null;
      verifiedSubscription = {
        entitled,
        expiryMillis,
        state: subscription.subscriptionState || 'UNKNOWN',
      };
      if (!entitled && subscription.subscriptionState === 'SUBSCRIPTION_STATE_PENDING') {
        throw new HttpsError('failed-precondition', 'Die Abo-Zahlung ist noch nicht abgeschlossen.');
      }
    } else {
      const response = await publisher.purchases.productsv2.getproductpurchasev2({
        packageName: PLAY_PACKAGE_NAME,
        token: purchaseToken,
      });
      const purchase = response.data;
      const lineItem = (purchase.productLineItem || []).find(
        (item) => item.productId === productId,
      );
      if (!lineItem || purchase.purchaseStateContext?.purchaseState !== 'PURCHASED') {
        throw new HttpsError('failed-precondition', 'Google Play bestätigt diesen Kauf nicht als bezahlt.');
      }
      verifiedAccountId = purchase.obfuscatedExternalAccountId || null;
      if (product.kind === 'consumable') {
        const quantity = lineItem.productOfferDetails?.quantity ?? 1;
        if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 100) {
          throw new HttpsError('failed-precondition', 'Ungültige Kaufmenge.');
        }
        verifiedPurchaseQuantity = quantity;
      }
    }
  } catch (error) {
    if (error instanceof HttpsError) throw error;
    console.error('Google Play purchase lookup failed:', error);
    throw new HttpsError('failed-precondition', 'Google Play konnte den Kauf nicht bestätigen.');
  }

  if (verifiedAccountId !== expectedAccountId) {
    throw new HttpsError('permission-denied', 'Dieser Kauf gehört nicht zum angemeldeten Dart-Party-Konto.');
  }

  const today = berlinDateKey();
  const receiptId = purchaseTokenHash(purchaseToken);
  const receiptRef = db.collection('playPurchaseReceipts').doc(receiptId);
  const userRef = walletDocument(uid);

  const wallet = await db.runTransaction(async (transaction) => {
    const [receiptSnapshot, userSnapshot] = await Promise.all([
      transaction.get(receiptRef),
      transaction.get(userRef),
    ]);

    if (receiptSnapshot.exists) {
      const receipt = receiptSnapshot.data();
      if (receipt.uid !== uid || receipt.productId !== productId) {
        throw new HttpsError('already-exists', 'Dieser Google-Play-Kauf ist bereits einem anderen Konto zugeordnet.');
      }
    }

    let current = userSnapshot.exists
      ? normalizeWallet(userSnapshot.data(), today)
      : initialWallet(today);
    current = refreshDailyTokens(current, today);

    if (product.kind === 'subscription') {
      if (!receiptSnapshot.exists && !verifiedSubscription.entitled) {
        throw new HttpsError('failed-precondition', 'Das Google-Play-Abo ist nicht aktiv.');
      }
      // Bei jeder erneuten Prüfung wird die tatsächliche Play-Laufzeit übernommen.
      // So werden Verlängerungen und abgelaufene/pausierte Abos korrekt abgebildet.
      if (verifiedSubscription.entitled) {
        const currentExpiry = toMillis(current.monthlyUntil);
        if (current.monthlyPurchaseHash === receiptId || currentExpiry === null ||
            verifiedSubscription.expiryMillis > currentExpiry) {
          current.monthlyUntil = Timestamp.fromMillis(verifiedSubscription.expiryMillis);
          current.monthlyPurchaseHash = receiptId;
        }
      } else if (current.monthlyPurchaseHash === receiptId) {
        current.monthlyUntil = null;
        current.monthlyPurchaseHash = null;
      }
    } else if (!receiptSnapshot.exists) {
      if (product.kind === 'consumable') {
        current.purchasedTokens += product.tokens * verifiedPurchaseQuantity;
      } else if (product.kind === 'lifetime') {
        current.lifetimeUnlimited = true;
      } else if (product.kind === 'adFree') {
        current.adFree = true;
      }
    }

    const walletWrite = {
      ...current,
      updatedAt: FieldValue.serverTimestamp(),
    };
    if (!userSnapshot.exists) walletWrite.createdAt = FieldValue.serverTimestamp();
    transaction.set(userRef, walletWrite, { merge: true });

    const receiptWrite = {
      uid,
      productId,
      kind: product.kind,
      tokensGranted: product.kind === 'consumable' && !receiptSnapshot.exists
        ? product.tokens * verifiedPurchaseQuantity
        : 0,
      tokenHash: receiptId,
      lastVerifiedAt: FieldValue.serverTimestamp(),
    };
    if (!receiptSnapshot.exists) receiptWrite.createdAt = FieldValue.serverTimestamp();
    if (product.kind === 'subscription') {
      receiptWrite.subscriptionState = verifiedSubscription.state;
      receiptWrite.expiryTime = verifiedSubscription.expiryMillis === null
        ? null
        : new Date(verifiedSubscription.expiryMillis).toISOString();
    }
    transaction.set(receiptRef, receiptWrite, { merge: true });
    return current;
  });

  return {
    verified: true,
    ...publicWallet(wallet),
  };
});

